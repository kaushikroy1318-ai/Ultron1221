# Mimi: AI voice assistant (website + Android app)

Mimi is a voice assistant that can use several AI models together. This version adds:

- **Real multi-model engine.** Gemini, Claude, ChatGPT and Kimi (plus Grok, DeepSeek, Mistral, Qwen) are called through their real APIs. Before, only Gemini ran and the others were role-play prompts.
- **Fusion mode.** Mimi asks every ready model at the same time, one model merges the best parts, and Mimi speaks one answer.
- **AI keys & server screen** in Settings: add, test and remove keys, change model names, pick which models join the fusion.
- **Android app** built in the cloud by GitHub, so no computer is needed.
- **Security fixes** for running the server on the internet (access token, link-fetch protection, bigger photo uploads, port handling).

## How the pieces fit

```
Android app  ──(access token)──►  Your Mimi server  ──►  Gemini / Claude / ChatGPT / Kimi
 (screens only)                   (holds the AI keys)
```

The AI keys live on the server, never on the phone. The app only knows the server address and the access token.

## Setup from a phone

**1. Put the project on GitHub.** Upload the files of this zip to your repository (replace the old ones).

**2. Start the server (Render, free plan works).**
Render dashboard → New → Blueprint → choose your repository. `render.yaml` does the rest.
Then open the service → Environment and add the keys you have (`GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `KIMI_API_KEY`). Copy the generated `MIMI_ACCESS_TOKEN`, and the service address (like `https://mimi-server.onrender.com`).

**3. Build the app.**
GitHub → your repository → Actions → *Build Android APK* → Run workflow. Optionally paste your server address so the app already knows it. When the run finishes (about 10 minutes), open it and download **Mimi-APK**, unzip it, and install `app-debug.apk` on your phone (allow installing from this source when asked).

**4. First launch.** Enter the server address and the access token, then tap Connect.

**5. Add models.** Settings → *AI keys & server* → open a model, paste its key, Save, Test. Then switch on **Fusion mode**.

## How the models are used

| You choose | What happens |
|---|---|
| Core = Gemini, Fusion off | The original Gemini path (with Google Search for news questions). |
| Core = ChatGPT, Claude, Kimi, Grok, DeepSeek | That real model answers, as Mimi. If its key is missing or it fails, Mimi falls back to Gemini. |
| Fusion on | Every model with a key answers in parallel (30 s limit each). Gemini merges them, or Claude/ChatGPT if Gemini is down. A model that fails is skipped. |

Live voice (the real-time streaming call) talks to Gemini directly. Fusion and the real ChatGPT/Claude/Kimi cores apply when Mimi answers through the normal text path, including spoken replies read out with the voice you chose.

**Changing the voice:** Settings → Personality → voice.

Model names change often. Defaults are only a starting point: open a model in Settings and type a new name in *Model name* (or set `CLAUDE_MODEL`, `CHATGPT_MODEL`, `KIMI_MODEL` on the server). If a test fails with "model not found", that is the fix.

## Server settings

See `.env.example`. The important ones:

| Name | What it does |
|---|---|
| `MIMI_ACCESS_TOKEN` | Your secret password. **Required in production**: without it every `/api` route is blocked. |
| `GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `KIMI_API_KEY` … | Model keys. Optional ones are skipped. |
| `PORT` | Set by the host. Defaults to 3000. |
| `ALLOWED_ORIGINS` | Extra website addresses allowed to call the server. |
| `ALLOW_PRIVATE_FETCH` | `true` lets Mimi open links on your home network. Leave off on a public server. |

Keys saved from the app are stored encrypted in `data/`. Free hosts often wipe files on restart, so for permanent keys use environment variables.

## Run on a computer

```
npm install
cp .env.example .env     # fill in GEMINI_API_KEY (and others)
npm run dev              # http://localhost:3000
```

In development with no `MIMI_ACCESS_TOKEN` the server is open, which is fine for local testing.

Build the app yourself instead of GitHub:

```
npm run build:app
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
npx cap open android      # then Build > Build APK in Android Studio
```

## Troubleshooting

- **"Wrong or missing access token" (401):** the token in the app differs from `MIMI_ACCESS_TOKEN` on the server.
- **"Server is not secured" (503):** set `MIMI_ACCESS_TOKEN` on the server.
- **"Could not reach that address":** check the spelling, use `https://`, and wait about a minute if the free server was asleep.
- **A model test fails:** read the message. Usually a wrong key, no credit on that account, or an old model name.
- **Build fails on GitHub:** open the failed step, copy the last 30 lines of the log, and ask for help with it.

## Known limits

- Google sign-in (Gmail, Drive and similar workspace features) uses a pop-up that does not work inside the Android app. Everything else works without signing in.
- The app needs internet. Fonts and AI calls are loaded online.
- The APK is a *debug* build, fine for installing on your own phone. A Play Store release needs signing.
