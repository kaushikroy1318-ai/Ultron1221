// server/ensembleRoutes.ts
// Real multi-model engine for Mimi.
//
//  - Calls the real APIs of Gemini, Claude, ChatGPT, Kimi (and Grok, DeepSeek, Mistral, Qwen)
//  - "fusion" mode: asks every ready model at once, then one model merges the best parts
//    into a single answer that still sounds like Mimi
//  - "single" mode: asks just one model (used when you pick ChatGPT, Claude, Kimi... as the core)
//
// API keys live only on the server: either in environment variables, or saved from the
// app's Settings screen into an AES-256-GCM encrypted file (needs MIMI_ACCESS_TOKEN or
// KEYSTORE_SECRET on the server). Keys are never sent back to the app.

import type { Express, Request, Response } from "express";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { assertPublicUrl } from "./security";

export type ProviderId = "gemini" | "claude" | "chatgpt" | "kimi" | "grok" | "deepseek" | "mistral" | "qwen";
type Kind = "gemini" | "anthropic" | "openai";

interface ProviderDef {
  id: ProviderId;
  label: string;
  kind: Kind;
  envKeys: string[];
  defaultModel: string;
  defaultBaseUrl?: string;
}

interface StoredSettings {
  apiKey?: string;
  model?: string;
  baseUrl?: string;
}
type Store = Partial<Record<ProviderId, StoredSettings>>;

interface Turn {
  role: "user" | "assistant";
  text: string;
}
interface Img {
  mimeType: string;
  data: string;
}
interface CallInput {
  system: string;
  turns: Turn[];
  images: Img[];
  needsWeb: boolean;
}
interface Resolved {
  apiKey: string;
  model: string;
  baseUrl: string;
  source: "app" | "server" | "none";
}
interface ProviderResult {
  provider: ProviderId;
  ok: boolean;
  text?: string;
  error?: string;
  ms: number;
}

// Model names change often. These are only defaults: every one can be changed from
// Settings > AI keys & server without touching code (or with <PROVIDER>_MODEL env vars).
const PROVIDERS: ProviderDef[] = [
  { id: "gemini", label: "Gemini", kind: "gemini", envKeys: ["GEMINI_API_KEY"], defaultModel: "" },
  { id: "claude", label: "Claude", kind: "anthropic", envKeys: ["ANTHROPIC_API_KEY"], defaultModel: "claude-sonnet-5-5" },
  { id: "chatgpt", label: "ChatGPT", kind: "openai", envKeys: ["OPENAI_API_KEY"], defaultModel: "chat-latest", defaultBaseUrl: "https://api.openai.com/v1" },
  { id: "kimi", label: "Kimi", kind: "openai", envKeys: ["KIMI_API_KEY", "MOONSHOT_API_KEY"], defaultModel: "kimi-k2.6", defaultBaseUrl: "https://api.moonshot.ai/v1" },
  { id: "grok", label: "Grok", kind: "openai", envKeys: ["GROK_API_KEY", "XAI_API_KEY"], defaultModel: "grok-4", defaultBaseUrl: "https://api.x.ai/v1" },
  { id: "deepseek", label: "DeepSeek", kind: "openai", envKeys: ["DEEPSEEK_API_KEY"], defaultModel: "deepseek-chat", defaultBaseUrl: "https://api.deepseek.com/v1" },
  { id: "mistral", label: "Mistral", kind: "openai", envKeys: ["MISTRAL_API_KEY"], defaultModel: "mistral-large-latest", defaultBaseUrl: "https://api.mistral.ai/v1" },
  { id: "qwen", label: "Qwen", kind: "openai", envKeys: ["QWEN_API_KEY", "DASHSCOPE_API_KEY"], defaultModel: "qwen-plus", defaultBaseUrl: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1" },
];
const BY_ID = new Map(PROVIDERS.map((p) => [p.id, p]));

const CALL_TIMEOUT_MS = 30000;
const MAX_HISTORY_TURNS = 20;
const MAX_IMAGES = 4;

// ------------------------------------------------------------------ key store
const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const STORE_FILE = path.join(DATA_DIR, "provider-settings.enc");

function keystoreSecret(): string {
  const s = process.env.KEYSTORE_SECRET || process.env.MIMI_ACCESS_TOKEN || "";
  if (s) return s;
  // Development only, so the Settings screen works locally. Never used in production.
  return process.env.NODE_ENV === "production" ? "" : "mimi-local-dev-secret";
}

let storeCache: Store | null = null;

function readStore(): Store {
  if (storeCache) return storeCache;
  try {
    const secret = keystoreSecret();
    if (!secret || !fs.existsSync(STORE_FILE)) return (storeCache = {});
    const raw = Buffer.from(fs.readFileSync(STORE_FILE, "utf8"), "base64");
    const salt = raw.subarray(0, 16);
    const iv = raw.subarray(16, 28);
    const tag = raw.subarray(28, 44);
    const body = raw.subarray(44);
    const key = crypto.scryptSync(secret, salt, 32);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    const json = Buffer.concat([decipher.update(body), decipher.final()]).toString("utf8");
    return (storeCache = JSON.parse(json));
  } catch (e: any) {
    console.warn("[Ensemble] Could not read saved keys (wrong secret or damaged file). Using server env keys only.", e?.message);
    return (storeCache = {});
  }
}

function writeStore(next: Store) {
  const secret = keystoreSecret();
  if (!secret) throw new Error("KEYSTORE_DISABLED");
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = crypto.scryptSync(secret, salt, 32);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const body = Buffer.concat([cipher.update(JSON.stringify(next), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  fs.writeFileSync(STORE_FILE, Buffer.concat([salt, iv, tag, body]).toString("base64"), { mode: 0o600 });
  storeCache = next;
}

const canSaveKeys = () => Boolean(keystoreSecret());

function resolve(id: ProviderId, geminiDefaultModel: string): Resolved {
  const def = BY_ID.get(id)!;
  const saved = readStore()[id] || {};
  const envKey = def.envKeys.map((n) => (process.env[n] || "").trim()).find(Boolean) || "";
  const apiKey = (saved.apiKey || envKey || "").trim();
  const source: Resolved["source"] = saved.apiKey ? "app" : envKey ? "server" : "none";
  const defaultModel = id === "gemini" ? geminiDefaultModel : def.defaultModel;
  const envModel = (process.env[`${id.toUpperCase()}_MODEL`] || "").trim();
  return {
    apiKey: apiKey === "GEMINI_PLACEHOLDER_KEY" ? "" : apiKey,
    model: saved.model || envModel || defaultModel,
    baseUrl: (saved.baseUrl || def.defaultBaseUrl || "").replace(/\/+$/, ""),
    source: apiKey && apiKey !== "GEMINI_PLACEHOLDER_KEY" ? source : "none",
  };
}

// -------------------------------------------------------------------- helpers
async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let t: NodeJS.Timeout;
  const timeout = new Promise<never>((_, rej) => {
    t = setTimeout(() => rej(new Error("timed out")), ms);
  });
  try {
    return await Promise.race([p, timeout]);
  } finally {
    clearTimeout(t!);
  }
}

async function httpError(label: string, res: globalThis.Response): Promise<Error> {
  let msg = `HTTP ${res.status}`;
  try {
    const body: any = await res.json();
    const detail = body?.error?.message || body?.message || body?.error;
    if (detail) msg += `: ${String(detail).slice(0, 220)}`;
  } catch {
    /* body was not JSON */
  }
  return new Error(`${label} ${msg}`);
}

function normalizeTurns(turns: Turn[]): Turn[] {
  const out: Turn[] = [];
  for (const t of turns) {
    const text = String(t.text || "").trim();
    if (!text) continue;
    if (!out.length && t.role === "assistant") continue; // every provider wants a user turn first
    const last = out[out.length - 1];
    if (last && last.role === t.role) last.text += `\n\n${text}`;
    else out.push({ role: t.role, text });
  }
  return out;
}

// ------------------------------------------------------------ provider callers
async function callGemini(cfg: Resolved, input: CallInput): Promise<string> {
  const ai = new GoogleGenAI({ apiKey: cfg.apiKey, apiVersion: "v1beta" } as any);
  const contents: any[] = input.turns.map((t) => ({
    role: t.role === "user" ? "user" : "model",
    parts: [{ text: t.text }],
  }));
  const last = contents[contents.length - 1];
  for (const im of input.images) last.parts.unshift({ inlineData: { mimeType: im.mimeType, data: im.data } });

  const run = (withSearch: boolean) =>
    ai.models.generateContent({
      model: cfg.model,
      contents,
      config: { systemInstruction: input.system, ...(withSearch ? { tools: [{ googleSearch: {} }] } : {}) },
    });

  if (input.needsWeb && !input.images.length) {
    try {
      return (await run(true)).text || "";
    } catch {
      /* search grounding unavailable or over quota: answer without it */
    }
  }
  return (await run(false)).text || "";
}

async function callClaude(cfg: Resolved, input: CallInput): Promise<string> {
  const okTypes = new Set(["image/jpeg", "image/png", "image/gif", "image/webp"]);
  const messages = input.turns.map((t, i) => {
    const isLast = i === input.turns.length - 1;
    if (isLast && input.images.length) {
      const imgs = input.images
        .filter((im) => okTypes.has(im.mimeType))
        .map((im) => ({ type: "image", source: { type: "base64", media_type: im.mimeType, data: im.data } }));
      return { role: t.role, content: [...imgs, { type: "text", text: t.text }] };
    }
    return { role: t.role, content: t.text };
  });
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": cfg.apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: cfg.model, max_tokens: 2048, system: input.system, messages }),
  });
  if (!res.ok) throw await httpError("Claude", res);
  const data: any = await res.json();
  return (data.content || []).map((c: any) => c.text || "").join("");
}

async function callOpenAICompatible(def: ProviderDef, cfg: Resolved, input: CallInput): Promise<string> {
  if (!cfg.baseUrl) throw new Error(`${def.label}: no endpoint set`);
  const withImages = def.id === "chatgpt"; // other OpenAI-style providers get text only
  const messages: any[] = [{ role: "system", content: input.system }];
  input.turns.forEach((t, i) => {
    const isLast = i === input.turns.length - 1;
    if (isLast && withImages && input.images.length) {
      messages.push({
        role: t.role,
        content: [
          { type: "text", text: t.text },
          ...input.images.map((im) => ({ type: "image_url", image_url: { url: `data:${im.mimeType};base64,${im.data}` } })),
        ],
      });
    } else {
      messages.push({ role: t.role, content: t.text });
    }
  });
  const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${cfg.apiKey}` },
    body: JSON.stringify({ model: cfg.model, messages }),
  });
  if (!res.ok) throw await httpError(def.label, res);
  const data: any = await res.json();
  const content = data.choices?.[0]?.message?.content;
  return Array.isArray(content) ? content.map((c: any) => c.text || "").join("") : String(content || "");
}

async function runProvider(id: ProviderId, input: CallInput, geminiDefaultModel: string): Promise<ProviderResult> {
  const def = BY_ID.get(id)!;
  const cfg = resolve(id, geminiDefaultModel);
  const start = Date.now();
  if (!cfg.apiKey) return { provider: id, ok: false, error: "No API key set", ms: 0 };
  try {
    const call =
      def.kind === "gemini" ? callGemini(cfg, input) : def.kind === "anthropic" ? callClaude(cfg, input) : callOpenAICompatible(def, cfg, input);
    const text = (await withTimeout(call, CALL_TIMEOUT_MS)).trim();
    if (!text) return { provider: id, ok: false, error: "Empty answer", ms: Date.now() - start };
    return { provider: id, ok: true, text, ms: Date.now() - start };
  } catch (e: any) {
    return { provider: id, ok: false, error: String(e?.message || e).slice(0, 260), ms: Date.now() - start };
  }
}

// ---------------------------------------------------------------- fusion merge
async function mergeAnswers(
  question: string,
  good: ProviderResult[],
  system: string,
  geminiDefaultModel: string
): Promise<{ text: string; merger: ProviderId }> {
  const block = good.map((r) => `### Answer ${BY_ID.get(r.provider)!.label}\n${r.text}`).join("\n\n");
  const prompt =
    `The user asked:\n"""${question.slice(0, 4000)}"""\n\n` +
    `Several assistants answered it. Write ONE final reply that:\n` +
    `- keeps the most accurate, complete and useful points from all answers\n` +
    `- settles disagreements by preferring the best-supported claim, and says so honestly if it is unclear\n` +
    `- drops repetition and stays short enough to be spoken aloud\n` +
    `- is in the same language and tone the user used\n` +
    `- speaks as Mimi, and never mentions the other assistants, models or that answers were combined\n\n` +
    block;

  // Prefer Gemini, then Claude, then ChatGPT, then whoever answered first.
  const order: ProviderId[] = ["gemini", "claude", "chatgpt", ...good.map((g) => g.provider)];
  const candidates = order.filter((id, i) => order.indexOf(id) === i && resolve(id, geminiDefaultModel).apiKey);
  for (const id of candidates) {
    const r = await runProvider(id, { system, turns: [{ role: "user", text: prompt }], images: [], needsWeb: false }, geminiDefaultModel);
    if (r.ok && r.text) return { text: r.text, merger: id };
  }
  // Merge failed everywhere: fall back to the first good answer rather than erroring.
  return { text: good[0].text!, merger: good[0].provider };
}

// ---------------------------------------------------------------------- routes
const WEB_QUESTION =
  /\b(latest|news|weather|today|tonight|current|currently|price|stock|score|match|search|look up|find online|who won|what happened|2025|2026|2027|aaj|khabar|taaza|live update)\b/i;

export function registerEnsembleRoutes(
  app: Express,
  opts: { getSystemInstruction: (userName?: string, prefs?: Record<string, any>) => string; geminiDefaultModel: string }
) {
  const gModel = opts.geminiDefaultModel;

  const statusOf = (id: ProviderId) => {
    const def = BY_ID.get(id)!;
    const r = resolve(id, gModel);
    return {
      id,
      label: def.label,
      kind: def.kind,
      configured: Boolean(r.apiKey),
      source: r.source,
      keyHint: r.apiKey ? `••••${r.apiKey.slice(-4)}` : "",
      model: r.model,
      defaultModel: id === "gemini" ? gModel : def.defaultModel,
      baseUrl: def.kind === "openai" ? r.baseUrl : "",
      defaultBaseUrl: def.defaultBaseUrl || "",
    };
  };

  // Which models are ready? (never returns the keys themselves)
  app.get("/api/ensemble/status", (_req: Request, res: Response) => {
    res.json({ canSaveKeys: canSaveKeys(), providers: PROVIDERS.map((p) => statusOf(p.id)) });
  });

  // Save or remove a key / model / endpoint from the Settings screen
  app.post("/api/ensemble/keys", async (req: Request, res: Response) => {
    try {
      const { provider, apiKey, model, baseUrl, remove } = req.body || {};
      const def = BY_ID.get(provider as ProviderId);
      if (!def) return res.status(400).json({ error: "Unknown model provider" });
      if (!canSaveKeys()) {
        return res.status(400).json({
          error: "Saving keys from the app needs MIMI_ACCESS_TOKEN (or KEYSTORE_SECRET) set on the server. You can also put the key in the server's environment variables.",
          code: "KEYSTORE_DISABLED",
        });
      }

      const store = { ...readStore() };
      if (remove) {
        delete store[def.id];
      } else {
        const entry: StoredSettings = { ...(store[def.id] || {}) };
        if (typeof apiKey === "string" && apiKey.trim()) {
          const k = apiKey.trim();
          if (!/^[\x21-\x7E]{8,400}$/.test(k)) return res.status(400).json({ error: "That key looks wrong. Paste it again without spaces." });
          entry.apiKey = k;
        }
        if (typeof model === "string") {
          const m = model.trim().slice(0, 100);
          if (m && !/^[\w.\-:/]+$/.test(m)) return res.status(400).json({ error: "Model name has characters that are not allowed." });
          if (m) entry.model = m;
          else delete entry.model;
        }
        if (def.kind === "openai" && typeof baseUrl === "string") {
          const b = baseUrl.trim().replace(/\/+$/, "");
          if (b) {
            if (!b.startsWith("https://")) return res.status(400).json({ error: "Endpoint must start with https://" });
            await assertPublicUrl(b);
            entry.baseUrl = b;
          } else {
            delete entry.baseUrl;
          }
        }
        store[def.id] = entry;
      }
      writeStore(store);
      res.json({ ok: true, provider: statusOf(def.id) });
    } catch (e: any) {
      res.status(400).json({ error: e?.message || "Could not save" });
    }
  });

  // One quick call to check a key works
  app.post("/api/ensemble/test", async (req: Request, res: Response) => {
    const id = req.body?.provider as ProviderId;
    if (!BY_ID.has(id)) return res.status(400).json({ error: "Unknown model provider" });
    const r = await runProvider(
      id,
      { system: "You are a connection test. Answer in as few words as possible.", turns: [{ role: "user", text: "Reply with the single word: OK" }], images: [], needsWeb: false },
      gModel
    );
    res.json({ ok: r.ok, ms: r.ms, reply: r.ok ? String(r.text).slice(0, 80) : undefined, error: r.error });
  });

  // Ask one model ("single") or every ready model at once and merge ("fusion")
  app.post("/api/ensemble/ask", async (req: Request, res: Response) => {
    try {
      const { prompt, history, userName, preferences, attachments, models, mode, includeAnswers } = req.body || {};
      if (typeof prompt !== "string" || !prompt.trim()) return res.status(400).json({ error: "prompt is required" });
      if (prompt.length > 60000) return res.status(413).json({ error: "prompt is too long" });

      // Real models should answer as Mimi, not "simulate" another model, so drop the core override.
      const prefs = { ...(preferences || {}) };
      delete prefs.neuralCore;
      const system = opts.getSystemInstruction(userName, prefs);

      let fullPrompt = prompt;
      const images: Img[] = [];
      if (Array.isArray(attachments)) {
        for (const a of attachments) {
          if (a?.data && typeof a.mimeType === "string" && a.mimeType.startsWith("image/") && images.length < MAX_IMAGES) {
            images.push({ mimeType: a.mimeType, data: String(a.data) });
          } else if (a?.textContent) {
            fullPrompt += `\n\n[Attached file: ${a.name || "document"}]\n${String(a.textContent).slice(0, 12000)}`;
          } else if (a?.name) {
            fullPrompt += `\n\n[Attached file: ${a.name} (${a.mimeType || "binary"})]`;
          }
        }
      }

      const past: Turn[] = (Array.isArray(history) ? history : [])
        .slice(-MAX_HISTORY_TURNS)
        .map((m: any) => ({ role: m?.sender === "user" ? "user" : "assistant", text: String(m?.text || "") }) as Turn);
      const input: CallInput = {
        system,
        turns: normalizeTurns([...past, { role: "user", text: fullPrompt }]),
        images,
        needsWeb: WEB_QUESTION.test(prompt),
      };

      const asked: ProviderId[] = (Array.isArray(models) ? models : []).filter((m: any): m is ProviderId => BY_ID.has(m));
      const readyAll = PROVIDERS.map((p) => p.id).filter((id) => resolve(id, gModel).apiKey);
      const targets = (asked.length ? asked : readyAll).filter((id, i, a) => a.indexOf(id) === i && resolve(id, gModel).apiKey);

      if (!targets.length) {
        return res.status(400).json({
          error: asked.length ? "No API key is set for the model you picked. Add it in Settings > AI keys & server." : "No AI model keys are set. Add at least one in Settings > AI keys & server.",
          code: "NO_MODELS",
        });
      }

      const single = mode === "single" || targets.length === 1;
      const results = await Promise.all(targets.map((id) => runProvider(id, input, gModel)));
      const good = results.filter((r) => r.ok && r.text);
      const failed = results.filter((r) => !r.ok).map((r) => ({ provider: r.provider, error: r.error }));
      const timings = Object.fromEntries(results.map((r) => [r.provider, r.ms]));

      if (!good.length) {
        return res.status(502).json({ error: failed.map((f) => `${BY_ID.get(f.provider)!.label}: ${f.error}`).join(" | ").slice(0, 400), code: "ALL_FAILED", failed });
      }

      let text = good[0].text!;
      let merger: ProviderId | undefined;
      if (!single && good.length > 1) {
        const merged = await mergeAnswers(prompt, good, system, gModel);
        text = merged.text;
        merger = merged.merger;
      }

      res.json({
        text,
        mode: !single && good.length > 1 ? "fusion" : "single",
        used: good.map((r) => r.provider),
        failed,
        timings,
        merger,
        ...(includeAnswers ? { answers: Object.fromEntries(good.map((r) => [r.provider, r.text])) } : {}),
      });
    } catch (e: any) {
      console.error("[Ensemble] ask failed:", e?.message || e);
      res.status(500).json({ error: e?.message || "Ensemble request failed" });
    }
  });
}
