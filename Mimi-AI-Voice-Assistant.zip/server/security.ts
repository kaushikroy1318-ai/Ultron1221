// server/security.ts
// Access token, CORS and "safe fetch" helpers.
//
// Why this exists: once Mimi runs on a public server (needed for the Android app),
// anyone who finds the address could spend your AI quota or make your server fetch
// private addresses. These helpers close that door.

import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import dns from "dns";
import net from "net";

const isProduction = () => process.env.NODE_ENV === "production";

// ---------------------------------------------------------------- access token
function configuredToken(): string {
  return (process.env.MIMI_ACCESS_TOKEN || "").trim();
}

function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

export function tokenFromRequest(req: Request): string {
  const header = req.headers["x-mimi-token"];
  if (typeof header === "string" && header) return header;
  const auth = req.headers.authorization;
  if (typeof auth === "string" && auth.toLowerCase().startsWith("bearer ")) return auth.slice(7).trim();
  return "";
}

export function isAuthorized(provided: string): boolean {
  const token = configuredToken();
  if (!token) {
    // No token set: allowed only while developing, or if you opt in explicitly.
    return !isProduction() || process.env.MIMI_ALLOW_OPEN === "true";
  }
  return Boolean(provided) && safeEqual(provided, token);
}

export function isAuthRequired(): boolean {
  return Boolean(configuredToken()) || (isProduction() && process.env.MIMI_ALLOW_OPEN !== "true");
}

export function requestIsAuthorized(req: Request): boolean {
  return isAuthorized(tokenFromRequest(req));
}

/** Protects every /api route. */
export function authMiddleware(req: Request, res: Response, next: NextFunction) {
  if (req.method === "OPTIONS") return next();

  if (isProduction() && !configuredToken() && process.env.MIMI_ALLOW_OPEN !== "true") {
    return res.status(503).json({
      error: "Server is not secured. Set MIMI_ACCESS_TOKEN on the server, then enter the same token in the app.",
      code: "SERVER_NOT_SECURED",
    });
  }
  if (!requestIsAuthorized(req)) {
    return res.status(401).json({
      error: "Wrong or missing access token. Open Settings > AI keys & server and enter your token.",
      code: "UNAUTHORIZED",
    });
  }
  next();
}

/** WebSocket check: browsers cannot set headers on a WebSocket, so the token rides in ?token= */
export function wsIsAuthorized(rawUrl: string | undefined): boolean {
  try {
    const u = new URL(rawUrl || "", "http://localhost");
    return isAuthorized(u.searchParams.get("token") || "");
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------- CORS
const DEFAULT_ORIGINS = [
  "https://localhost", // Android app (Capacitor, androidScheme: https)
  "capacitor://localhost", // iOS app
  "http://localhost",
  "http://localhost:3000",
  "http://localhost:5173",
];

export function corsMiddleware(req: Request, res: Response, next: NextFunction) {
  const origin = req.headers.origin;
  const extra = (process.env.ALLOWED_ORIGINS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const allowed = new Set([...DEFAULT_ORIGINS, ...extra]);

  if (origin && allowed.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-mimi-token");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Max-Age", "600");
  }
  if (req.method === "OPTIONS") return res.status(204).end();
  next();
}

// ------------------------------------------------------------ safe outbound fetch
function isPrivateIPv4(ip: string): boolean {
  const p = ip.split(".").map(Number);
  if (p.length !== 4 || p.some((n) => Number.isNaN(n))) return true;
  const [a, b] = p;
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) || // includes cloud metadata 169.254.169.254
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    a >= 224
  );
}

function isPrivateAddress(ip: string): boolean {
  if (net.isIPv4(ip)) return isPrivateIPv4(ip);
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    if (l === "::1" || l === "::") return true;
    if (l.startsWith("fc") || l.startsWith("fd") || l.startsWith("fe8") || l.startsWith("fe9") || l.startsWith("fea") || l.startsWith("feb")) return true;
    const mapped = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateIPv4(mapped[1]);
    return false;
  }
  return true;
}

/** Throws if the address points at localhost, a home network or cloud metadata. */
export async function assertPublicUrl(urlStr: string): Promise<URL> {
  let u: URL;
  try {
    u = new URL(urlStr);
  } catch {
    throw new Error("Invalid URL");
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") throw new Error("Only http(s) links are allowed");
  if (process.env.ALLOW_PRIVATE_FETCH === "true") return u;

  const host = u.hostname.replace(/^\[|\]$/g, "");
  if (net.isIP(host)) {
    if (isPrivateAddress(host)) throw new Error("Private network addresses are blocked on this server");
    return u;
  }
  const records = await dns.promises.lookup(host, { all: true });
  if (!records.length || records.some((r) => isPrivateAddress(r.address))) {
    throw new Error("Private network addresses are blocked on this server");
  }
  return u;
}

/** fetch() that re-checks every redirect, so a public site cannot bounce us to a private one. */
export async function safeFetch(urlStr: string, init: RequestInit = {}, maxRedirects = 3): Promise<Response> {
  let current = urlStr;
  for (let i = 0; i <= maxRedirects; i++) {
    const u = await assertPublicUrl(current);
    const res = await fetch(u.toString(), { ...init, redirect: "manual" });
    if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
      current = new URL(res.headers.get("location")!, u).toString();
      continue;
    }
    return res;
  }
  throw new Error("Too many redirects");
}
