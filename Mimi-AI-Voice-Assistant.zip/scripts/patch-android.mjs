// Adds the permissions Mimi needs (microphone for voice, camera for vision) to the
// Android project that `npx cap add android` generates. Safe to run more than once.
import fs from "node:fs";

const manifestPath = "android/app/src/main/AndroidManifest.xml";
if (!fs.existsSync(manifestPath)) {
  console.error("android/ project not found. Run: npx cap add android");
  process.exit(1);
}

let xml = fs.readFileSync(manifestPath, "utf8");
const wanted = [
  ["uses-permission", "android.permission.INTERNET", ""],
  ["uses-permission", "android.permission.RECORD_AUDIO", ""],
  ["uses-permission", "android.permission.MODIFY_AUDIO_SETTINGS", ""],
  ["uses-permission", "android.permission.CAMERA", ""],
  ["uses-feature", "android.hardware.microphone", ' android:required="false"'],
  ["uses-feature", "android.hardware.camera", ' android:required="false"'],
];

const lines = wanted
  .filter(([, name]) => !xml.includes(`android:name="${name}"`))
  .map(([tag, name, extra]) => `    <${tag} android:name="${name}"${extra} />`);

if (lines.length) {
  xml = xml.replace("</manifest>", `${lines.join("\n")}\n</manifest>`);
  fs.writeFileSync(manifestPath, xml);
  console.log(`Added ${lines.length} entries to AndroidManifest.xml`);
} else {
  console.log("AndroidManifest.xml already has the permissions Mimi needs");
}
