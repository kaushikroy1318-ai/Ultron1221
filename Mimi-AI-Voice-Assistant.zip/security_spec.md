# Firebase Security Specification - Mimi AI Voice Assistant

## Data Invariants
1. **User Isolation**: A user can only read, create, or update their own profile document at `/users/{userId}`.
2. **Relational Integrity**: All conversations and messages must belong to the authenticated user.
3. **Immutability**: `userId` and `createdAt` fields are immutable once set.
4. **Valid IDs**: All document IDs must be alphanumeric strings with size <= 128.
5. **Timestamp Integrity**: All timestamps (`updatedAt`, `createdAt`, `timestamp`) must match `request.time`.
6. **Message Finality**: Messages can only be created, never updated or deleted by the user.
7. **Strict Schema**: Documents must strictly follow the schema defined in `firebase-blueprint.json`.

## The "Dirty Dozen" Payloads (Red Team Test Cases)

| ID | Case | Payload / Operation | Expected Result |
|----|------|----------------------|-----------------|
| 1 | Identity Spoofing | `create /users/attacker_id` with `auth.uid = victim_id` | PERMISSION_DENIED |
| 2 | Field Injection | `update /users/uid` set `{ role: 'admin' }` | PERMISSION_DENIED |
| 3 | Immutable Breach | `update /users/uid` change `{ userId: 'new_id' }` | PERMISSION_DENIED |
| 4 | Orphaned Record | `create /users/uid/conversations/conv1` with `userId: 'other_uid'` | PERMISSION_DENIED |
| 5 | Cross-User Write | `create /users/victim_uid/conversations/conv1/messages/msg1` | PERMISSION_DENIED |
| 6 | Ghost Field | `create /users/uid` with `{ extra_field: 'poison' }` | PERMISSION_DENIED |
| 7 | Resource Exhaustion | `create message` with `text` size > 5000 | PERMISSION_DENIED |
| 8 | ID Poisoning | `create /users/UID_WITH_DOT.txt` | PERMISSION_DENIED |
| 9 | State Shortcut | `update conversation` change `createdAt` | PERMISSION_DENIED |
| 10 | Unauthenticated Read| `get /users/uid` without `auth` | PERMISSION_DENIED |
| 11 | Partial Update Gap | `update /users/uid` without `updatedAt` field | PERMISSION_DENIED |
| 12 | Message Tampering | `update /users/uid/conversations/c1/messages/m1` | PERMISSION_DENIED |

## Hardened Evaluation Table

| Collection | Identity Spoofing | State Shortcutting | Resource Poisoning |
|------------|-------------------|--------------------|--------------------|
| users | BLOCKED (isOwner) | BLOCKED (hasOnly) | BLOCKED (isValidId) |
| conversations | BLOCKED (isOwner) | BLOCKED (hasOnly) | BLOCKED (isValidId) |
| messages | BLOCKED (isOwner) | BLOCKED (create only) | BLOCKED (text size check) |
