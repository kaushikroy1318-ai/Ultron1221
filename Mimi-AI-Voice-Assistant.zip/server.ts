import express from "express";
import path from "path";
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, LiveServerMessage, Modality, Type } from "@google/genai";
import { getSystemInstruction } from "./src/constants";
import dotenv from "dotenv";
import { authMiddleware, corsMiddleware, isAuthRequired, safeFetch, wsIsAuthorized } from "./server/security";
import { registerEnsembleRoutes } from "./server/ensembleRoutes";

dotenv.config();

// When this file runs as the built bundle (dist/server.cjs), always behave as production,
// even if the host forgot to set NODE_ENV.
if (typeof __filename !== "undefined" && __filename.endsWith("server.cjs")) {
  process.env.NODE_ENV = "production";
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ server, path: "/api/live" });
  const PORT = Number(process.env.PORT) || 3000; // hosts such as Render/Railway/Cloud Run set PORT

  app.set("trust proxy", 1);
  app.use(corsMiddleware); // lets the Android app (https://localhost) talk to this server
  app.use(express.json({ limit: "25mb" })); // photos sent to the assistant are base64, the old 100kb limit rejected them
  app.use("/api", authMiddleware); // every /api route needs the access token (see MIMI_ACCESS_TOKEN)

  // Logging middleware
  app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
  });

  // Initialization of Gemini AI
  const getApiKey = () => process.env.GEMINI_API_KEY;
  const DEFAULT_TEXT_MODEL = "gemini-4-hydrogen";
  const LITE_TEXT_MODEL = "gemini-3.1-flash-lite";
  const envLiveModel = process.env.LIVE_MODEL?.trim();
  const LIVE_MODEL = envLiveModel && /^gemini-[\w.-]+$/i.test(envLiveModel) ? envLiveModel : "gemini-3.8-live";
  const VALID_VOICES = new Set(["Puck", "Charon", "Kore", "Fenrir", "Zephyr"]);

  function sanitizeVoiceId(voiceId?: string): string {
    if (voiceId && VALID_VOICES.has(voiceId)) return voiceId;
    if (voiceId === "Aoede") return "Zephyr";
    return "Kore";
  }

  function normalizeTextModel(modelName?: string): string {
    if (!modelName) return DEFAULT_TEXT_MODEL;
    const m = modelName.trim();
    if (
      m.includes("1.5") ||
      m.includes("2.0") ||
      m.includes("2.5") ||
      m.includes("3.5-flash") ||
      m === "gemini-3.8-flash" ||
      m === "gemini-pro"
    ) {
      return DEFAULT_TEXT_MODEL;
    }
    if (m.includes("3.1") && m.includes("pro")) {
      return "gemini-4-neon";
    }
    if (m.includes("3.1")) {
      return LITE_TEXT_MODEL;
    }
    return m;
  }

  if (!getApiKey()) {
    console.warn("GEMINI_API_KEY is not set. Live voice and Gemini API calls will return setup errors until configured in Settings > Secrets.");
  }

  function isApiKeyError(error: any): boolean {
    if (!error) return false;
    const str = (
      typeof error === "string"
        ? error
        : (error?.message || "") + " " + (error?.statusText || "") + " " + JSON.stringify(error)
    ).toLowerCase();
    const code = error?.status || error?.code || error?.error?.code;
    return (
      code === 403 ||
      code === "403" ||
      code === 401 ||
      str.includes("leaked") ||
      str.includes("permission_denied") ||
      str.includes("api_key_invalid") ||
      str.includes("api key not valid") ||
      str.includes("invalid api key") ||
      str.includes("unauthenticated")
    );
  }

  function formatApiError(error: any): { status: number; code: string; message: string } {
    const rawMsg = error?.message || String(error || "Unknown Gemini API error");
    const errCode = Number(error?.status || error?.code || error?.error?.code || 500);
    const lower = rawMsg.toLowerCase();

    if (!getApiKey() || getApiKey() === "GEMINI_PLACEHOLDER_KEY") {
      return {
        status: 503,
        code: "MISSING_API_KEY",
        message: "GEMINI_API_KEY is not configured. Please add a valid key in Settings > Secrets.",
      };
    }
    if (isApiKeyError(error)) {
      return {
        status: 403,
        code: "PERMISSION_DENIED",
        message: "Gemini API key was rejected or reported invalid (403 PERMISSION_DENIED). Please check or replace your API key in Settings > Secrets.",
      };
    }
    if (errCode === 429 || lower.includes("resource_exhausted") || lower.includes("quota")) {
      return {
        status: 429,
        code: "RESOURCE_EXHAUSTED",
        message: "Gemini API quota or rate limit exceeded (429). Please wait a moment or check your billing tier in Settings > Secrets.",
      };
    }
    if (errCode === 404 || lower.includes("not_found") || lower.includes("not found")) {
      return {
        status: 404,
        code: "MODEL_NOT_FOUND",
        message: `Requested Gemini model is unavailable (${rawMsg}). Try switching back to ${DEFAULT_TEXT_MODEL}.`,
      };
    }
    return {
      status: errCode >= 400 && errCode < 600 ? errCode : 500,
      code: "GEMINI_API_ERROR",
      message: rawMsg,
    };
  }

  const ai = new GoogleGenAI({
    apiKey: getApiKey() || "GEMINI_PLACEHOLDER_KEY",
    apiVersion: "v1beta",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  // Helper to retry content generation with exponential backoff and safe free-tier fallback models
  async function generateContentWithRetry(
    params: {
      model: string;
      contents: any;
      config?: any;
    },
    maxRetries = 3
  ): Promise<any> {
    if (!getApiKey() || getApiKey() === "GEMINI_PLACEHOLDER_KEY") {
      throw Object.assign(new Error("GEMINI_API_KEY is not configured."), { status: 503 });
    }

    const requestedModel = normalizeTextModel(params.model);
    const isTtsModel = requestedModel.includes("tts");

    const modelsToTry = isTtsModel
      ? ["gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts"]
      : Array.from(new Set([requestedModel, DEFAULT_TEXT_MODEL, LITE_TEXT_MODEL]));

    let lastError: any = null;
    const effectiveMaxAttempts = Math.min(maxRetries, Math.max(modelsToTry.length, 2));

    for (let attempt = 1; attempt <= effectiveMaxAttempts; attempt++) {
      const currentIndex = Math.min(attempt - 1, modelsToTry.length - 1);
      const currentModel = modelsToTry[currentIndex];
      const hasNextDistinctModel = attempt < modelsToTry.length && modelsToTry[attempt] !== currentModel;

      try {
        console.log(`[Gemini Service] Attempt ${attempt}/${effectiveMaxAttempts} using model: ${currentModel}`);
        const response = await ai.models.generateContent({
          ...params,
          model: currentModel,
        });

        if (currentModel.includes("tts")) {
          const parts = response?.candidates?.[0]?.content?.parts || [];
          const hasAudio = parts.some((part: any) => Boolean(part?.inlineData?.data));
          if (!hasAudio) {
            throw new Error(`Model ${currentModel} returned no audio payload.`);
          }
        }

        return response;
      } catch (err: any) {
        lastError = err;
        const errMsg = err?.message || String(err);
        const errCode = err?.status || err?.code || err?.error?.code || 500;
        console.log(`[Gemini Service] Attempt ${attempt} (${currentModel}) failed with code: ${errCode} — ${errMsg}`);

        if (isApiKeyError(err)) {
          break;
        }

        const isQuotaError =
          errCode === 429 ||
          errMsg.includes("quota") ||
          errMsg.includes("RESOURCE_EXHAUSTED");

        // On 429 quota/rate-limit, allow switching once to an untried fallback model,
        // but never hammer the same exhausted model repeatedly.
        if (isQuotaError) {
          if (!hasNextDistinctModel) {
            break;
          }
          await new Promise((resolve) => setTimeout(resolve, 250));
          continue;
        }

        const isTransient =
          errCode === 503 ||
          errCode === 502 ||
          errCode === 504 ||
          errMsg.includes("UNAVAILABLE") ||
          errMsg.includes("high demand") ||
          errMsg.includes("overloaded");

        const isNotFoundError =
          errCode === 404 ||
          errMsg.includes("NOT_FOUND") ||
          errMsg.includes("not found");

        if (!isTransient && !isNotFoundError && !hasNextDistinctModel) {
          break;
        }

        const delay = hasNextDistinctModel || isNotFoundError ? 200 : Math.min(Math.pow(2, attempt) * 400, 1600);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }

    throw lastError;
  }

  // Real multi-model engine: Gemini + Claude + ChatGPT + Kimi (+ more) with fusion
  registerEnsembleRoutes(app, { getSystemInstruction, geminiDefaultModel: DEFAULT_TEXT_MODEL });

  // REST API for non-live interactions
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { prompt, history, userName, preferences, attachments } = req.body;
      const systemInstruction = getSystemInstruction(userName, preferences);
      const requestedModel = normalizeTextModel(preferences?.studioConfig?.activeModel || DEFAULT_TEXT_MODEL);

      const userParts: any[] = [];
      let combinedPrompt = String(prompt || "");
      if (Array.isArray(attachments) && attachments.length > 0) {
        for (const att of attachments) {
          if (att?.data && att?.mimeType?.startsWith("image/")) {
            userParts.push({
              inlineData: {
                mimeType: att.mimeType,
                data: att.data,
              },
            });
          } else if (att?.textContent) {
            combinedPrompt += `\n\n[Attached File: ${att.name || "document"}]\n${String(att.textContent).slice(0, 12000)}`;
          } else if (att?.name) {
            combinedPrompt += `\n\n[Attached File: ${att.name} (${att.mimeType || "binary"})]`;
          }
        }
      }
      userParts.push({ text: combinedPrompt || "Please inspect the attached item." });

      const contentsPayload = (history || [])
        .map((m: any) => ({
          role: m.sender === "user" ? "user" : "model",
          parts: [{ text: m.text }],
        }))
        .concat([{ role: "user", parts: userParts }]);

      const needsWebGrounding =
        /\b(latest|news|weather|today|tonight|current|currently|price|stock|score|match|search|look up|find online|who won|what happened|2025|2026|aaj|khabar|taaza|live update)\b/i.test(
          combinedPrompt
        ) && !attachments?.length;

      let response: any;
      if (needsWebGrounding) {
        try {
          response = await generateContentWithRetry(
            {
              model: requestedModel,
              contents: contentsPayload,
              config: {
                systemInstruction,
                tools: [{ googleSearch: {} }],
              },
            },
            2
          );
        } catch (groundingErr: any) {
          const gCode = groundingErr?.status || groundingErr?.code || groundingErr?.error?.code;
          const gMsg = String(groundingErr?.message || "");
          if (gCode === 429 || gMsg.includes("RESOURCE_EXHAUSTED") || gMsg.includes("quota")) {
            console.warn("[Gemini Chat] Search grounding hit 429 quota, retrying standard chat without googleSearch tool.");
            response = await generateContentWithRetry({
              model: requestedModel,
              contents: contentsPayload,
              config: { systemInstruction },
            });
          } else {
            throw groundingErr;
          }
        }
      } else {
        response = await generateContentWithRetry({
          model: requestedModel,
          contents: contentsPayload,
          config: { systemInstruction },
        });
      }

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = chunks
        ? chunks.map((c: any) => ({ uri: c.web?.uri, title: c.web?.title })).filter((s: any) => s.uri)
        : [];

      res.json({ text: response.text, sources, model: requestedModel });
    } catch (error: any) {
      const formatted = formatApiError(error);
      console.error("[Gemini Chat Error]:", formatted.code, formatted.message);
      res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  app.post("/api/gemini/agent", async (req, res) => {
    try {
      const { prompt, agent } = req.body;
      if (!getApiKey() || getApiKey() === "GEMINI_PLACEHOLDER_KEY") {
        return res.status(503).json({
          error: "GEMINI_API_KEY is not configured. Please add a valid key in Settings > Secrets.",
          code: "MISSING_API_KEY",
        });
      }

      const interaction: any = await (ai.interactions.create as any)(
        {
          agent: agent === "DeepResearch" ? "deep-research-preview-04-2026" : "antigravity-preview-05-2026",
          input: prompt,
          environment: "remote",
        },
        { timeout: 300000 }
      );

      let outputText = interaction.output_text || "";
      if (!outputText) {
        for (const step of interaction.steps || []) {
          if (step.type === "model_output") {
            const textContent = step.content?.find((c: any) => c.type === "text");
            if (textContent && textContent.text) outputText += textContent.text;
          }
        }
      }

      res.json({ text: outputText || "Agent operation complete.", steps: interaction.steps });
    } catch (error: any) {
      const formatted = formatApiError(error);
      console.error("[Gemini Agent Error]:", formatted.code, formatted.message);
      res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  app.post("/api/gemini/generate", async (req, res) => {
    try {
      const { prompt, model: modelName } = req.body;
      const resolvedModel = normalizeTextModel(modelName);
      const response = await generateContentWithRetry({
        model: resolvedModel,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
      });
      res.json({ text: response.text, model: resolvedModel });
    } catch (error: any) {
      const formatted = formatApiError(error);
      console.error("[Gemini Generate Error]:", formatted.code, formatted.message);
      res.status(formatted.status).json({ error: formatted.message, code: formatted.code });
    }
  });

  app.post("/api/gemini/tts", async (req, res) => {
    try {
      const { text, voiceId, voiceProfile } = req.body;
      const safeVoice = sanitizeVoiceId(voiceId);

      let style = "Clear, warm, natural conversational companion";
      if (voiceProfile === "Sassy Mimi") {
        style = "Sassy, playful, witty, slightly teasing conversational companion";
      } else if (voiceProfile === "Formal Manager") {
        style = "Formal, professional, structured, clear and authoritative";
      } else if (voiceProfile === "Playful Friend") {
        style = "Warm, cheerful, friendly, and enthusiastic";
      }

      const response = await generateContentWithRetry({
        model: "gemini-3.8-flash-lite-tts",
        contents: [
          {
            role: "user",
            parts: [
              {
                text: String(text || "").slice(0, 1800),
                speechMetadata: { style },
              } as any,
            ],
          },
        ],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: safeVoice },
            },
          },
        },
      });

      const parts = response.candidates?.[0]?.content?.parts || [];
      let base64Audio: string | null = null;
      for (const part of parts) {
        if (part?.inlineData?.data) {
          base64Audio = part.inlineData.data;
          break;
        }
      }

      if (base64Audio) {
        res.json({ audio: base64Audio, mimeType: "audio/wav", voice: safeVoice });
      } else {
        res.status(502).json({ error: "TTS returned no audio data.", audio: null });
      }
    } catch (error: any) {
      const formatted = formatApiError(error);
      console.warn("[Gemini TTS Warning]:", formatted.code, formatted.message);
      res.status(formatted.status).json({ audio: null, error: formatted.message, code: formatted.code });
    }
  });

  app.post("/api/scrape", async (req, res) => {
    try {
      let { url } = req.body;
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      // Format URL properly
      if (!url.startsWith("http://") && !url.startsWith("https://")) {
        url = "https://" + url;
      }

      console.log(`[Scraper] Scraping content from: ${url}`);
      
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);

      const response = await safeFetch(url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        },
        signal: controller.signal
      }).finally(() => clearTimeout(timeout));

      if (!response.ok) {
        throw new Error(`HTTP Error ${response.status}`);
      }

      const html = await response.text();
      
      // Clean up tags to extract plain text
      let cleanedText = html
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      if (cleanedText.length > 15000) {
        cleanedText = cleanedText.substring(0, 15000) + "... [content truncated]";
      }

      res.json({ text: cleanedText });
    } catch (err: any) {
      console.error(`[Scraper Error] Failed to scrape ${req.body.url}:`, err);
      res.status(500).json({ error: `Could not load page contents: ${err.message}` });
    }
  });

  app.post("/api/search", async (req, res) => {
    try {
      const { query } = req.body;
      if (!query) {
        return res.status(400).json({ error: "Query is required" });
      }
      
      console.log(`[Search] Performing server search for: ${query}`);
      
      const ddhUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
      
      const response = await fetch(ddhUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
      });
      
      if (!response.ok) {
        throw new Error(`Search engine returned HTTP ${response.status}`);
      }
      
      const html = await response.text();
      const results: { title: string; url: string; snippet: string }[] = [];
      
      const resultBlockRegex = /<div class="result__body">([\s\S]*?)<\/div>\s*<\/div>/g;
      const titleRegex = /<a class="result__snip"[\s\S]*?>([\s\S]*?)<\/a>|<a class="result__a"[\s\S]*?>([\s\S]*?)<\/a>/;
      const urlRegex = /<a class="result__url"[\s\S]*?>([\s\S]*?)<\/a>/;
      const snippetRegex = /<a class="result__snippet"[\s\S]*?>([\s\S]*?)<\/a>/;
      
      let blockMatch;
      let count = 0;
      while ((blockMatch = resultBlockRegex.exec(html)) !== null && count < 8) {
        const block = blockMatch[1];
        
        const tMatch = block.match(titleRegex);
        const uMatch = block.match(urlRegex);
        const sMatch = block.match(snippetRegex);
        
        if (tMatch || sMatch) {
          const titleStr = (tMatch ? (tMatch[1] || tMatch[2]) : "Result").replace(/<[^>]+>/g, "").trim();
          const urlStr = (uMatch ? uMatch[1] : "").replace(/<[^>]+>/g, "").trim();
          const snippetStr = (sMatch ? sMatch[1] : "").replace(/<[^>]+>/g, "").trim();
          
          if (titleStr || snippetStr) {
            results.push({
              title: titleStr,
              url: urlStr ? "https://" + urlStr.trim() : "",
              snippet: snippetStr
            });
            count++;
          }
        }
      }
      
      if (results.length === 0) {
        let text = html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
        if (text.length > 2000) text = text.substring(0, 2000);
        return res.json({ results: [], rawText: text });
      }
      
      res.json({ results });
    } catch (err: any) {
      console.error("[Search Error] Failed to search:", err);
      res.status(500).json({ error: `Searching failed: ${err.message}` });
    }
  });

  app.post("/api/server-link/ping", async (req, res) => {
    try {
      const { url, type } = req.body;
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      console.log(`[Server Link Integration] Testing connection to type [${type}]: ${url}`);

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);

      let targetUrl = url;
      if (type === "websocket" || url.startsWith("ws://") || url.startsWith("wss://")) {
        targetUrl = url.replace(/^ws/, "http");
      }

      if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
        targetUrl = "http://" + targetUrl;
      }

      try {
        const pingStart = Date.now();
        const response = await safeFetch(targetUrl, {
          method: "GET",
          signal: controller.signal,
          headers: {
            "User-Agent": "Mimi AI Assistant (Server Link Controller)",
            "Accept": "*/*"
          }
        });
        clearTimeout(timeout);
        
        const latency = Date.now() - pingStart;
        return res.json({ 
          status: "connected", 
          statusCode: response.status,
          latency: `${latency}ms`,
          message: `Reached custom server with status ${response.status}.`
        });
      } catch (e: any) {
        clearTimeout(timeout);
        if (e.name === "AbortError" || e.message?.toLowerCase().includes("timeout")) {
          return res.json({ 
            status: "failed", 
            error: "Connection timeout after 5000ms"
          });
        }
        return res.json({ 
          status: "failed", 
          error: e.message || "Failed to connect" 
        });
      }
    } catch (err: any) {
      console.error("[Server Link Ping Error] Failed:", err);
      res.status(500).json({ error: err.message || "Ping process failed" });
    }
  });

  app.post("/api/server-link/dispatch", async (req, res) => {
    try {
      const { url, type, command } = req.body;
      if (!url) {
        return res.status(400).json({ error: "URL is required" });
      }

      console.log(`[Server Link Dispatch] Routing command to [${type}] server ${url}: ${command}`);

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);

      let targetUrl = url;
      if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
        targetUrl = "http://" + targetUrl;
      }

      try {
        const response = await safeFetch(targetUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "User-Agent": "Mimi AI Assistant (Server Link Dispatcher)"
          },
          body: JSON.stringify({
            event: "command",
            command: command,
            timestamp: Date.now(),
            source: "Mimi Assistant Voice Command"
          }),
          signal: controller.signal
        });
        clearTimeout(timeout);

        try {
          const json = await response.json();
          return res.json({ response: json, status: response.status });
        } catch {
          const text = await response.text();
          return res.json({ response: text.substring(0, 1000), status: response.status });
        }
      } catch (e: any) {
        clearTimeout(timeout);
        
        try {
          const fallbackController = new AbortController();
          const fallbackTimeout = setTimeout(() => fallbackController.abort(), 4000);
          
          let fallbackUrl = targetUrl;
          if (targetUrl.includes("?")) {
            fallbackUrl += `&cmd=${encodeURIComponent(command)}`;
          } else {
            fallbackUrl += `?cmd=${encodeURIComponent(command)}`;
          }

          const fallbackRes = await safeFetch(fallbackUrl, {
            method: "GET",
            headers: {
              "User-Agent": "Mimi AI Assistant (Server Link Dispatcher)"
            },
            signal: fallbackController.signal
          });
          clearTimeout(fallbackTimeout);

          try {
            const json = await fallbackRes.json();
            return res.json({ response: json, status: fallbackRes.status });
          } catch {
            const text = await fallbackRes.text();
            return res.json({ response: text.substring(0, 1000), status: fallbackRes.status });
          }
        } catch (fallbackErr: any) {
          return res.status(502).json({ 
            error: `Failed in POST & GET dispatch: ${fallbackErr.message || "Service Unreachable"}` 
          });
        }
      }
    } catch (err: any) {
      console.error("[Server Link Dispatch Error] Failed:", err);
      res.status(500).json({ error: err.message || "Dispatch task failed" });
    }
  });

  app.post("/api/youtube/search", async (req, res) => {
    try {
      const { query } = req.body;
      if (!query) {
        return res.status(400).json({ error: "Query is required" });
      }
      
      console.log(`[YouTube Search] Sourcing video for query: ${query}`);
      const ytUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
      
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);
      
      const response = await fetch(ytUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "en-US,en;q=0.9"
        },
        signal: controller.signal
      }).finally(() => clearTimeout(timeout));

      if (!response.ok) {
        throw new Error(`YouTube search returned HTTP ${response.status}`);
      }

      const html = await response.text();
      
      // Extract video IDs using two regex methods to be highly resilient
      const videoIdMatches = [...html.matchAll(/"videoId"\s*:\s*"([a-zA-Z0-9_-]{11})"/g)];
      const idsFromJson = videoIdMatches.map(m => m[1]);
      
      const watchMatches = [...html.matchAll(/\/watch\?v=([a-zA-Z0-9_-]{11})/g)];
      const idsFromWatch = watchMatches.map(m => m[1]);
      
      const allIds = [...idsFromJson, ...idsFromWatch].filter(id => id && id.length === 11);
      const uniqueIds = Array.from(new Set(allIds));
      
      if (uniqueIds.length === 0) {
        console.warn("[YouTube Search Warning] No video IDs could be extracted.");
        return res.status(404).json({ error: "Could not find any video on YouTube" });
      }
      
      const firstVideoId = uniqueIds[0];
      console.log(`[YouTube Search Success] Extracted top video ID: ${firstVideoId}`);
      
      res.json({
        videoId: firstVideoId,
        embedUrl: `https://www.youtube.com/embed/${firstVideoId}?autoplay=1`,
        watchUrl: `https://www.youtube.com/watch?v=${firstVideoId}`,
        allVideoIds: uniqueIds
      });
    } catch (err: any) {
      console.error("[YouTube Scrape Error] Failed to search YouTube:", err);
      res.status(500).json({ error: `YouTube search failed: ${err.message}` });
    }
  });

  app.get("/api/gemini/call/status", (req, res) => {
    res.json({
      status: getApiKey() ? "operational" : "missing_key",
      protocol: "Gemini Live BiDi v4.0",
      activeModel: LIVE_MODEL,
      textModel: DEFAULT_TEXT_MODEL,
      models: [
        { id: "gemini-3.8-live", name: "Gemini 3.8 Live (Audio BiDi)", type: "realtime", ready: true },
        { id: "gemini-4-hydrogen", name: "Gemini 4 Hydrogen (Fast Reasoning)", type: "reasoning", ready: true },
        { id: "gemini-3.8-flash-lite-tts", name: "Gemini 3.8 Studio TTS (High-Fidelity)", type: "speech", ready: true },
        { id: "gemini-4-neon", name: "Gemini 4 Neon (Deep Coding & STEM)", type: "pro", ready: true },
        { id: "gemini-3.1-flash-lite", name: "Gemini 3.1 Flash Lite (Ultra-Light)", type: "lite", ready: true }
      ],
      sampleRate: "24000Hz PCM16",
      audioChannels: 1,
      latencyEstimateMs: 8,
      grounding: { googleSearch: true, maps: true, whatsappAutopilot: true }
    });
  });

  app.post("/api/gemini/call/protocol", (req, res) => {
    const { model, voiceProfile, sampleRate } = req.body;
    console.log(`[Gemini Call Protocol Config] Updated to model: ${model}, voice: ${voiceProfile}`);
    res.json({
      success: true,
      appliedProtocol: {
        model: model || LIVE_MODEL,
        voiceProfile: voiceProfile || "Sassy Mimi",
        sampleRate: sampleRate || 24000,
        timestamp: Date.now()
      }
    });
  });

  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      authRequired: isAuthRequired(),
      apiKeySet: Boolean(getApiKey() && getApiKey() !== "GEMINI_PLACEHOLDER_KEY"),
      models: {
        text: DEFAULT_TEXT_MODEL,
        live: LIVE_MODEL,
        tts: "gemini-3.8-flash-lite-tts",
      },
    });
  });

  // Catch-all for API routes to prevent HTML fallback
  app.all("/api/*", (req, res) => {
    res.status(404).json({ error: `Route ${req.method} ${req.url} not found` });
  });

  // Global Error Handler
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error("Express Error Handler:", err);
    if (res.headersSent) {
      return next(err);
    }
    res.status(err.status || 500).json({ 
      error: err.message || "Internal Server Error",
      stack: process.env.NODE_ENV === "production" ? undefined : err.stack
    });
  });

  // WebSocket for Live API Bridge
  wss.on("connection", async (ws, req) => {
    if (!wsIsAuthorized(req.url)) {
      try {
        ws.send(JSON.stringify({ type: "error", fatal: true, code: "UNAUTHORIZED", message: "Wrong or missing access token. Check Settings > AI keys & server." }));
      } catch {}
      ws.close(1008, "Unauthorized");
      return;
    }
    console.log("Client connected to Live Bridge");
    let session: any = null;
    let isConnecting = false;
    let isClientClosed = false;

    const safeSend = (payload: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(JSON.stringify(payload), (err) => {
            if (err) {
              console.warn("WebSocket safeSend ignored:", err.message);
            }
          });
        } catch (e: any) {
          console.warn("WebSocket safeSend caught:", e.message);
        }
      }
    };

    ws.on("message", async (data) => {
      try {
        const message = JSON.parse(data.toString());

        // Initial setup message
        if (message.type === "setup") {
          if (session || isConnecting) return;
          isConnecting = true;

          const { userName, preferences, model: requestedLiveModel } = message;
          const baseInstruction = getSystemInstruction(userName, preferences);
          const systemInstruction = `${baseInstruction}\n\n[CRITICAL LIVE VOICE LANGUAGE RULE]\nThe user speaks Hindi, Hinglish, Bengali, and English. Always reply naturally in the same language the user just spoke. Keep spoken replies concise, warm, and conversational unless asked for detail.`;
          const voiceId = sanitizeVoiceId(preferences?.voiceId);
          const targetLiveModel =
            requestedLiveModel === "gemini-3.8-live-extended-thinking"
              ? "gemini-3.8-live-extended-thinking"
              : LIVE_MODEL;

          const key = getApiKey();
          if (!key || key === "GEMINI_PLACEHOLDER_KEY") {
            isConnecting = false;
            safeSend({
              type: "error",
              fatal: true,
              code: "MISSING_API_KEY",
              message: "GEMINI_API_KEY is missing on the server. Add a valid Gemini API key in Settings > Secrets.",
            });
            ws.close(1008, "Missing API key");
            return;
          }

          try {
            safeSend({ type: "state", state: "connecting" });
            const liveSession = await ai.live.connect({
              model: targetLiveModel,
              config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                  voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceId } },
                },
                systemInstruction,
                inputAudioTranscription: {},
                outputAudioTranscription: {},
                tools: [
                  {
                    functionDeclarations: [
                      {
                        name: "executeBrowserAction",
                        description: "Triggers a browser search action or YouTube/Google/web search command dynamically.",
                        parameters: {
                          type: Type.OBJECT,
                          properties: {
                            query: {
                              type: Type.STRING,
                              description: "The term, music query, singing artist or detail to search/play on YouTube or search on Google."
                            },
                            actionType: {
                              type: Type.STRING,
                              description: "The action to perform, e.g. 'youtube', 'google', 'spotify', or 'whatsapp'."
                            }
                          },
                          required: ["query", "actionType"]
                        }
                      },
                      {
                        name: "get_device_time",
                        description: "Gets the current date and time of the user's local device in IST timezone.",
                        parameters: {
                          type: Type.OBJECT,
                          properties: {}
                        }
                      }
                    ]
                  }
                ]
              },
              callbacks: {
                onmessage: (msg: LiveServerMessage) => {
                  safeSend({ type: "live", data: msg });
                },
                onclose: (closeEvent: any) => {
                  const reason = closeEvent?.reason ? String(closeEvent.reason) : "";
                  const code = closeEvent?.code;
                  console.log(`Gemini Live session closed (code=${code ?? "n/a"}${reason ? `, reason=${reason}` : ""})`);
                  session = null;
                  isConnecting = false;

                  if (!isClientClosed && ws.readyState === WebSocket.OPEN) {
                    const lowerReason = reason.toLowerCase();
                    const isAuthOrConfigFatal =
                      code === 1008 ||
                      lowerReason.includes("api key") ||
                      lowerReason.includes("permission") ||
                      lowerReason.includes("not found") ||
                      lowerReason.includes("leaked");
                    if (isAuthOrConfigFatal) {
                      safeSend({
                        type: "error",
                        fatal: true,
                        code: "LIVE_SESSION_REJECTED",
                        message: `Gemini Live session rejected (${reason || code}). Check your API key in Settings > Secrets.`,
                      });
                    }
                    try {
                      ws.close(code && code >= 1000 && code <= 4999 ? code : 1000, reason || "Upstream Live closed");
                    } catch {}
                  }
                },
                onerror: (err: any) => {
                  const formatted = formatApiError(err);
                  const isFatal =
                    formatted.code === "PERMISSION_DENIED" ||
                    formatted.code === "MISSING_API_KEY" ||
                    formatted.code === "MODEL_NOT_FOUND";
                  console.error("[Gemini Live Error]:", formatted.code, formatted.message);
                  safeSend({
                    type: "error",
                    fatal: isFatal,
                    code: formatted.code,
                    message: formatted.message,
                  });
                }
              }
            });

            if (isClientClosed || ws.readyState !== WebSocket.OPEN) {
              try { liveSession.close(); } catch {}
              return;
            }

            session = liveSession;
            isConnecting = false;
            safeSend({ type: "state", state: "listening" });
          } catch (e: any) {
            isConnecting = false;
            const formatted = formatApiError(e);
            const isFatal =
              formatted.code === "PERMISSION_DENIED" ||
              formatted.code === "MISSING_API_KEY" ||
              formatted.code === "MODEL_NOT_FOUND";
            console.error("[Live Connect Error]:", formatted.code, formatted.message);
            safeSend({
              type: "error",
              fatal: isFatal,
              code: formatted.code,
              message: formatted.message,
            });
            if (ws.readyState === WebSocket.OPEN) {
              ws.close(isFatal ? 1008 : 1011, "Live connect failed");
            }
          }
          return;
        }

        // Forward realtime audio/video input
        if (session && message.type === "input" && message.input) {
          try {
            session.sendRealtimeInput(message.input);
          } catch (e: any) {
            console.error("Error sending realtime input to Gemini Live:", e);
            safeSend({
              type: "error",
              fatal: false,
              code: "LIVE_INPUT_ERROR",
              message: `Failed to stream input to Gemini Live: ${e?.message || String(e)}`,
            });
          }
        }

        // Support simplified { audio } payload as well
        if (session && message.audio) {
          try {
            session.sendRealtimeInput({
              audio: { data: message.audio, mimeType: "audio/pcm;rate=16000" },
            });
          } catch (e: any) {
            console.error("Error forwarding raw audio chunk:", e);
          }
        }

        // Forward text message turns to Live session
        if (session && message.type === "text" && message.text) {
          try {
            session.sendClientContent({
              turns: [{ role: "user", parts: [{ text: message.text }] }],
              turnComplete: true,
            });
          } catch (e: any) {
            console.error("Error sending text turn to Gemini Live:", e);
            safeSend({
              type: "error",
              fatal: false,
              code: "LIVE_TEXT_ERROR",
              message: `Failed to send text to Gemini Live: ${e?.message || String(e)}`,
            });
          }
        }

        // Forward tool response
        if (session && message.type === "tool_response") {
          try {
            session.sendToolResponse(message.response);
          } catch (e) {
            console.error("Error sending tool response to Gemini:", e);
          }
        }
      } catch (err) {
        console.error("Bridge Message Error:", err);
      }
    });

    ws.on("close", () => {
      isClientClosed = true;
      isConnecting = false;
      console.log("Client disconnected from Live Bridge");
      if (session) {
        try {
          session.close();
        } catch (e) {
          console.warn("Session closing exception ignored:", e);
        }
        session = null;
      }
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
    if (!process.env.MIMI_ACCESS_TOKEN) {
      console.warn(
        process.env.NODE_ENV === "production" && process.env.MIMI_ALLOW_OPEN !== "true"
          ? "[Security] MIMI_ACCESS_TOKEN is not set: all /api routes are blocked. Set it, then enter the same token in the app."
          : "[Security] MIMI_ACCESS_TOKEN is not set: /api is open. Fine for local testing, set it before putting this server online."
      );
    }
  });
}

startServer().catch((err) => {
  console.error("FATAL: Failed to start server:", err);
});
