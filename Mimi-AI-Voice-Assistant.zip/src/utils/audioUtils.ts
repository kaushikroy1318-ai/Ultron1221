import { audioStreamer } from "../services/audioStreamer";

let audioCtx: AudioContext | null = null;
let currentSource: AudioBufferSourceNode | null = null;

function getAudioContext(): AudioContext | null {
  if (!audioCtx || audioCtx.state === "closed") {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return null;
    audioCtx = new AudioContextClass({ sampleRate: 24000 });
  }
  return audioCtx;
}

export function stopPlayPCM(): void {
  if (currentSource) {
    try {
      currentSource.onended = null;
      currentSource.stop();
      currentSource.disconnect();
    } catch {
      // ignore if already stopped
    }
    currentSource = null;
  }
}

export async function playPCM(base64Data: string): Promise<void> {
  try {
    const ctx = getAudioContext();
    if (!ctx) {
      console.warn("AudioContext not supported");
      return;
    }

    if (ctx.state === "suspended") {
      await ctx.resume();
    }

    stopPlayPCM();

    const binaryString = atob(base64Data);
    const len = binaryString.length;
    if (len < 2) return;

    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    // Gemini 3.8 TTS unary generateContent returns a complete WAV container ("RIFF").
    const isWav =
      bytes.length >= 44 &&
      bytes[0] === 0x52 && // R
      bytes[1] === 0x49 && // I
      bytes[2] === 0x46 && // F
      bytes[3] === 0x46;   // F

    let audioBuffer: AudioBuffer;
    if (isWav) {
      const arrayBuf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
      audioBuffer = await ctx.decodeAudioData(arrayBuf);
    } else {
      const numSamples = Math.floor(bytes.length / 2);
      const view = new DataView(bytes.buffer, bytes.byteOffset, numSamples * 2);
      audioBuffer = ctx.createBuffer(1, numSamples, 24000);
      const channelData = audioBuffer.getChannelData(0);
      for (let i = 0; i < numSamples; i++) {
        channelData[i] = view.getInt16(i * 2, true) / 32768.0;
      }
    }

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    currentSource = source;
    audioStreamer.connectSource(ctx, source);
    source.start();

    return new Promise<void>((resolve) => {
      source.onended = () => {
        if (currentSource === source) {
          currentSource = null;
        }
        try {
          source.disconnect();
        } catch {
          // ignore
        }
        resolve();
      };
    });
  } catch (error) {
    console.error("Error playing audio:", error);
  }
}

export function getMergedFrequencyData(targetLength = 16): Uint8Array {
  return audioStreamer.getFrequencyData(targetLength);
}
