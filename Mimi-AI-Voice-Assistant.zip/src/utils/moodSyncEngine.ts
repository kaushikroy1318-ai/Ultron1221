/**
 * Web Audio API Procedural Synthesizer for Mood Soundscapes
 * Generates beautiful, real-time focus waves and chimes matching Mimi's current mood.
 */

class MoodSoundscapeEngine {
  private ctx: AudioContext | null = null;
  private volumeNode: GainNode | null = null;
  private primaryOsc: OscillatorNode | null = null;
  private secondaryOsc: OscillatorNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private chimeTimer: any = null;
  private activeMood: "cheerful" | "sassy" | "serious" | null = null;
  private isRunning: boolean = false;
  private baseVolume: number = 0.08;
  public isHumSuppressed: boolean = true;

  private initContext() {
    if (this.isHumSuppressed) return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public start(mood: "cheerful" | "sassy" | "serious") {
    if (this.isHumSuppressed) {
      this.stop();
      return;
    }
    try {
      this.initContext();
      if (!this.ctx) return;

      // If already running with same mood, do nothing
      if (this.isRunning && this.activeMood === mood) {
        return;
      }

      // Stop any active oscillators/timers first
      this.stop();

      this.isRunning = true;
      this.activeMood = mood;

      // 1. Create main volume node
      this.volumeNode = this.ctx.createGain();
      this.volumeNode.gain.setValueAtTime(0, this.ctx.currentTime);
      this.volumeNode.gain.linearRampToValueAtTime(this.baseVolume, this.ctx.currentTime + 1.5);
      this.volumeNode.connect(this.ctx.destination);

      // 2. Create filter for warm, analog feel
      this.filterNode = this.ctx.createBiquadFilter();
      this.filterNode.type = "lowpass";
      this.filterNode.Q.setValueAtTime(1, this.ctx.currentTime);
      this.filterNode.connect(this.volumeNode);

      if (mood === "cheerful") {
        // --- CHEERFUL SOUNDSCAPE (🌟 Optimistic Triad Drone + Golden Ratio Chimes) ---
        this.filterNode.frequency.setValueAtTime(600, this.ctx.currentTime);

        // Root drone G3 (196 Hz)
        this.primaryOsc = this.ctx.createOscillator();
        this.primaryOsc.type = "sine";
        this.primaryOsc.frequency.setValueAtTime(196, this.ctx.currentTime);
        this.primaryOsc.connect(this.filterNode);
        this.primaryOsc.start();

        // Major Third drone B3 (246.94 Hz)
        this.secondaryOsc = this.ctx.createOscillator();
        this.secondaryOsc.type = "sine";
        this.secondaryOsc.frequency.setValueAtTime(246.94, this.ctx.currentTime);
        
        const oscGain = this.ctx.createGain();
        oscGain.gain.setValueAtTime(0.4, this.ctx.currentTime);
        this.secondaryOsc.connect(oscGain);
        oscGain.connect(this.filterNode);
        this.secondaryOsc.start();

        // Start random chimes (Golden Ratio intervals in G major pentatonic)
        this.startCheerfulChimes();

      } else if (mood === "sassy") {
        // --- SASSY SOUNDSCAPE (💅 Retro Lounge Triangle Pad + Slow Filter Sweep) ---
        this.filterNode.frequency.setValueAtTime(350, this.ctx.currentTime);

        // Warm Root drone F3 (174.61 Hz)
        this.primaryOsc = this.ctx.createOscillator();
        this.primaryOsc.type = "triangle";
        this.primaryOsc.frequency.setValueAtTime(174.61, this.ctx.currentTime);
        this.primaryOsc.connect(this.filterNode);
        this.primaryOsc.start();

        // Slow vibrato LFO for analog detuning/warmth
        const lfo = this.ctx.createOscillator();
        lfo.frequency.setValueAtTime(0.35, this.ctx.currentTime); // very slow
        const lfoGain = this.ctx.createGain();
        lfoGain.gain.setValueAtTime(2.5, this.ctx.currentTime); // detune slightly
        lfo.connect(lfoGain);
        lfoGain.connect(this.primaryOsc.frequency);
        lfo.start();

        // Secondary Minor 7th drone Eb4 (311.13 Hz)
        this.secondaryOsc = this.ctx.createOscillator();
        this.secondaryOsc.type = "sine";
        this.secondaryOsc.frequency.setValueAtTime(311.13, this.ctx.currentTime);
        
        const oscGain = this.ctx.createGain();
        oscGain.gain.setValueAtTime(0.25, this.ctx.currentTime);
        this.secondaryOsc.connect(oscGain);
        oscGain.connect(this.filterNode);
        this.secondaryOsc.start();

        // Periodic slow Filter Sweep for "attitude"
        this.sweepFilter(250, 650, 6.0);

      } else if (mood === "serious") {
        // --- SERIOUS SOUNDSCAPE (🧠 Deep Binaural Focus Beta - detuned Sawtooths + 40Hz) ---
        this.filterNode.type = "lowpass";
        this.filterNode.frequency.setValueAtTime(150, this.ctx.currentTime); // Filter high frequencies

        // Root C2 detuned sawtooth node (65.41 Hz)
        this.primaryOsc = this.ctx.createOscillator();
        this.primaryOsc.type = "sawtooth";
        this.primaryOsc.frequency.setValueAtTime(65.41, this.ctx.currentTime);
        this.primaryOsc.connect(this.filterNode);
        this.primaryOsc.start();

        // Slightly detuned C2 (+0.5 Hz for binaural pulse effect)
        this.secondaryOsc = this.ctx.createOscillator();
        this.secondaryOsc.type = "sawtooth";
        this.secondaryOsc.frequency.setValueAtTime(65.91, this.ctx.currentTime);
        
        const oscGain = this.ctx.createGain();
        oscGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
        this.secondaryOsc.connect(oscGain);
        oscGain.connect(this.filterNode);
        this.secondaryOsc.start();
        
        // Dynamic sub focus hum at 40Hz (gamma brain stimulation)
        const subOsc = this.ctx.createOscillator();
        subOsc.type = "sine";
        subOsc.frequency.setValueAtTime(40, this.ctx.currentTime);
        const subGain = this.ctx.createGain();
        subGain.gain.setValueAtTime(0.5, this.ctx.currentTime);
        subOsc.connect(subGain);
        subGain.connect(this.volumeNode); // Bypass filter for deep sub representation
        subOsc.start();

        // Save reference to stop later
        const originalStop = this.stop.bind(this);
        this.stop = () => {
          originalStop();
          try { subOsc.stop(); } catch(e) {}
        };
      }
    } catch (e) {
      console.error("Failed to start soundscape synthesizer:", e);
    }
  }

  private sweepFilter(low: number, high: number, duration: number) {
    if (!this.ctx || !this.filterNode || !this.isRunning || this.activeMood !== "sassy") return;
    
    const curr = this.ctx.currentTime;
    this.filterNode.frequency.cancelScheduledValues(curr);
    this.filterNode.frequency.setValueAtTime(low, curr);
    this.filterNode.frequency.exponentialRampToValueAtTime(high, curr + duration / 2);
    this.filterNode.frequency.exponentialRampToValueAtTime(low, curr + duration);

    // Schedule next sweep
    this.chimeTimer = setTimeout(() => {
      this.sweepFilter(low, high, duration);
    }, duration * 1000 + 1000);
  }

  private startCheerfulChimes() {
    const scale = [392.00, 440.00, 493.88, 587.33, 659.25, 783.99, 880.00]; // G major pentatonic frequencies
    
    const triggerChime = () => {
      if (!this.ctx || !this.isRunning || this.activeMood !== "cheerful" || !this.volumeNode) return;
      
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        
        osc.type = "sine";
        const freq = scale[Math.floor(Math.random() * scale.length)];
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        
        gain.gain.setValueAtTime(0, this.ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.12, this.ctx.currentTime + 0.1); // rapid attack
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 3.0); // long gentle decay
        
        // Add low feedback delay effect purely via Web Audio routing
        const delay = this.ctx.createDelay();
        delay.delayTime.setValueAtTime(0.3, this.ctx.currentTime);
        const feedback = this.ctx.createGain();
        feedback.gain.setValueAtTime(0.3, this.ctx.currentTime);
        
        osc.connect(gain);
        gain.connect(this.volumeNode);
        
        // Feed into delay
        gain.connect(delay);
        delay.connect(feedback);
        feedback.connect(delay);
        delay.connect(this.volumeNode);
        
        osc.start();
        osc.stop(this.ctx.currentTime + 3.5);
      } catch (e) {}

      // Schedule next chime randomly between 2s and 6s
      const delayTime = 2000 + Math.random() * 4000;
      this.chimeTimer = setTimeout(triggerChime, delayTime);
    };

    triggerChime();
  }

  public setVolume(vol: number) {
    this.baseVolume = Math.min(0.4, Math.max(0, vol));
    if (this.ctx && this.volumeNode && this.isRunning) {
      this.volumeNode.gain.linearRampToValueAtTime(this.baseVolume, this.ctx.currentTime + 0.3);
    }
  }

  public stop() {
    this.isRunning = false;
    this.activeMood = null;

    if (this.chimeTimer) {
      clearTimeout(this.chimeTimer);
      this.chimeTimer = null;
    }

    try {
      if (this.primaryOsc) {
        this.primaryOsc.stop();
        this.primaryOsc.disconnect();
        this.primaryOsc = null;
      }
      if (this.secondaryOsc) {
        this.secondaryOsc.stop();
        this.secondaryOsc.disconnect();
        this.secondaryOsc = null;
      }
      if (this.volumeNode) {
        this.volumeNode.disconnect();
        this.volumeNode = null;
      }
      if (this.filterNode) {
        this.filterNode.disconnect();
        this.filterNode = null;
      }
    } catch (e) {}
  }
}

export const moodSoundscapeEngine = new MoodSoundscapeEngine();
