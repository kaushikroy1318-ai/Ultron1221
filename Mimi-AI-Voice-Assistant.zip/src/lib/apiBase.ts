// src/lib/apiBase.ts
// Where is the Mimi server, and how do we prove it is really us?
//
// On the website the server is the same address that served the page, so nothing is needed.
// In the Android app the page is bundled inside the app, so the app must be told the server
// address (and the access token). Both are saved on the phone and can be changed in
// Settings > AI keys & server.

const URL_KEY = "mimi.serverUrl";
const TOKEN_KEY = "mimi.accessToken";

const env: any = (import.meta as any).env || {};

function read(key: string): string {
  try {
    return localStorage.getItem(key) || "";
  } catch {
    return "";
  }
}

export function isNativeApp(): boolean {
  try {
    return Boolean((window as any).Capacitor?.isNativePlatform?.());
  } catch {
    return false;
  }
}

export function normalizeServerUrl(input: string): string {
  let v = (input || "").trim();
  if (!v) return "";
  if (!/^https?:\/\//i.test(v)) v = `https://${v}`;
  return v.replace(/\/+$/, "");
}

export function getServerUrl(): string {
  return normalizeServerUrl(read(URL_KEY) || env.VITE_SERVER_URL || "");
}

export function getAccessToken(): string {
  return read(TOKEN_KEY) || env.VITE_ACCESS_TOKEN || "";
}

export function saveServerConnection(url: string, token: string) {
  try {
    localStorage.setItem(URL_KEY, normalizeServerUrl(url));
    localStorage.setItem(TOKEN_KEY, token.trim());
  } catch {
    /* storage blocked: connection will not persist */
  }
}

export function clearServerConnection() {
  try {
    localStorage.removeItem(URL_KEY);
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* ignore */
  }
}

/** The installed app has no server of its own, so it must be pointed at one first. */
export function needsServerSetup(): boolean {
  return isNativeApp() && !getServerUrl();
}

export function apiUrl(path: string): string {
  return `${getServerUrl()}${path}`;
}

/** ws:// or wss:// address for a server path, with the access token attached. */
export function wsUrl(path: string): string {
  const base = getServerUrl();
  const token = getAccessToken();
  let origin: string;
  if (base) {
    origin = base.replace(/^http/i, "ws");
  } else {
    origin = `${window.location.protocol === "https:" ? "wss:" : "ws:"}//${window.location.host}`;
  }
  return `${origin}${path}${token ? `?token=${encodeURIComponent(token)}` : ""}`;
}

let shimInstalled = false;

/**
 * Every part of the app calls fetch("/api/..."). Instead of editing each call, this one
 * wrapper points them at the right server and adds the access token. Only addresses that
 * start with /api/ are touched, so Firebase, Google and other requests are left alone.
 */
export function installApiFetchShim() {
  if (shimInstalled || typeof window === "undefined") return;
  shimInstalled = true;
  const original = window.fetch.bind(window);

  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    if (typeof input === "string" && input.startsWith("/api/")) {
      const headers = new Headers(init?.headers || {});
      const token = getAccessToken();
      if (token && !headers.has("x-mimi-token")) headers.set("x-mimi-token", token);
      return original(apiUrl(input), { ...init, headers });
    }
    return original(input as any, init);
  };
}

export interface ConnectionTest {
  ok: boolean;
  status: "connected" | "wrong_token" | "not_secured" | "unreachable" | "bad_response";
  message: string;
}

/** Checks an address + token pair against the server's health route. */
export async function testServerConnection(url: string, token: string): Promise<ConnectionTest> {
  const base = normalizeServerUrl(url);
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 12000);
    const headers: Record<string, string> = {};
    if (token.trim()) headers["x-mimi-token"] = token.trim();
    const res = await fetch(`${base}/api/health`, { headers, signal: controller.signal, cache: "no-store" });
    clearTimeout(timer);
    if (res.status === 401) return { ok: false, status: "wrong_token", message: "The server answered, but the access token is wrong." };
    if (res.status === 503) return { ok: false, status: "not_secured", message: "The server is running but has no MIMI_ACCESS_TOKEN set yet. Add it on the server first." };
    if (!res.ok) return { ok: false, status: "bad_response", message: `The server answered with an error (${res.status}).` };
    const data = await res.json().catch(() => null);
    if (!data || data.status !== "ok") return { ok: false, status: "bad_response", message: "That address answered, but it does not look like a Mimi server." };
    return { ok: true, status: "connected", message: data.apiKeySet ? "Connected. Gemini is ready." : "Connected. No Gemini key is set on the server yet." };
  } catch {
    return { ok: false, status: "unreachable", message: "Could not reach that address. Check the spelling and that the server is running." };
  }
}
