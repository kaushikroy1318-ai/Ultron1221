/**
 * YouTube integration service for Mimi AI Voice Assistant
 */

export interface YouTubeSearchResult {
  videoId: string;
  embedUrl: string;
  watchUrl: string;
  allVideoIds: string[];
}

/**
 * Searches for a video on YouTube via the server-side scraper endpoint.
 * Returns a YouTubeSearchResult or throws an error.
 */
export async function searchVideo(query: string): Promise<YouTubeSearchResult> {
  try {
    const response = await fetch("/api/youtube/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ query })
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `Server error: ${response.status}`);
    }

    const data: YouTubeSearchResult = await response.json();
    return data;
  } catch (error: any) {
    console.error("[YouTubeService] Error searching video:", error);
    throw error;
  }
}

/**
 * Directly returns the embed URL for a given video ID
 */
export function playVideo(videoId: string): string {
  return `https://www.youtube.com/embed/${videoId}?autoplay=1`;
}

/**
 * Standard watch link fallback
 */
export function getWatchUrl(videoId: string): string {
  return `https://www.youtube.com/watch?v=${videoId}`;
}
