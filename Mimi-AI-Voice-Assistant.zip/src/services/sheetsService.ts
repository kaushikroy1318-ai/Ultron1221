export interface SheetInfo {
  id: string;
  name: string;
  modifiedTime: string;
  webViewLink?: string;
}

export interface SheetTab {
  title: string;
  index: number;
  gridProperties?: {
    rowCount: number;
    columnCount: number;
  };
}

export interface SpreadsheetDetail {
  id: string;
  title: string;
  sheets: SheetTab[];
}

export async function listSpreadsheets(accessToken: string, queryText?: string): Promise<SheetInfo[]> {
  let url = "https://www.googleapis.com/drive/v3/files?fields=files(id, name, modifiedTime, webViewLink)&pageSize=40&orderBy=modifiedTime desc";
  const queryParts = [
    "mimeType = 'application/vnd.google-apps.spreadsheet'",
    "trashed = false"
  ];
  if (queryText) {
    const escapedQuery = queryText.replace(/'/g, "\\'");
    queryParts.push(`name contains '${escapedQuery}'`);
  }
  url += `&q=${encodeURIComponent(queryParts.join(" and "))}`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to search spreadsheets: ${res.statusText}`);
  }
  const data = await res.json();
  return data.files || [];
}

export async function createSpreadsheet(accessToken: string, title: string): Promise<SheetInfo> {
  const res = await fetch("https://sheets.googleapis.com/v4/spreadsheets", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      properties: {
        title
      }
    })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to create spreadsheet: ${res.statusText}`);
  }
  const data = await res.json();
  return {
    id: data.spreadsheetId,
    name: data.properties.title,
    modifiedTime: new Date().toISOString(),
    webViewLink: data.spreadsheetUrl
  };
}

export async function getSpreadsheetDetails(accessToken: string, spreadsheetId: string): Promise<SpreadsheetDetail> {
  const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch spreadsheet details: ${res.statusText}`);
  }
  const data = await res.json();
  return {
    id: data.spreadsheetId,
    title: data.properties.title,
    sheets: (data.sheets || []).map((sh: any) => ({
      title: sh.properties.title,
      index: sh.properties.index,
      gridProperties: sh.properties.gridProperties
    }))
  };
}

export async function getSheetValues(
  accessToken: string,
  spreadsheetId: string,
  range: string
): Promise<string[][]> {
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` }
    }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch sheet values: ${res.statusText}`);
  }
  const data = await res.json();
  return data.values || [];
}

export async function updateSheetValues(
  accessToken: string,
  spreadsheetId: string,
  range: string,
  values: string[][]
): Promise<any> {
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`,
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ values })
    }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to update sheet values: ${res.statusText}`);
  }
  return await res.json();
}

export async function appendSheetRow(
  accessToken: string,
  spreadsheetId: string,
  range: string,
  values: string[][]
): Promise<any> {
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ values })
    }
  );
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to append row to sheet: ${res.statusText}`);
  }
  return await res.json();
}
