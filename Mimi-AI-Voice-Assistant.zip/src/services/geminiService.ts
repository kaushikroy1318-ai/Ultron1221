export function resetMimiSession() {
  // Session reset is now handled server-side or by changing the conversation context
}

export interface ChatAttachment {
  name: string;
  mimeType: string;
  data?: string; // base64 without data: prefix for images
  textContent?: string;
}

export async function getMimiResponse(
  prompt: string,
  history: { sender: "user" | "mimi"; text: string }[] = [],
  userName?: string,
  preferences?: Record<string, any>,
  attachments?: ChatAttachment[]
): Promise<string> {
  try {
    const response = await fetch("/api/gemini/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, history, userName, preferences, attachments }),
    });

    if (!response.ok) {
      if (response.status === 502 || response.status === 504) {
        return "Core server is temporarily unavailable. Please try again in a moment.";
      }
      let errorMsg = `Server returned ${response.status}`;
      let errorCode = "";
      try {
        const err = await response.json();
        errorMsg = err.error || errorMsg;
        errorCode = err.code || "";
      } catch {
        const text = await response.text();
        errorMsg = text.substring(0, 140) || errorMsg;
      }

      if (response.status === 401 || response.status === 403 || errorCode === "PERMISSION_DENIED" || errorCode === "MISSING_API_KEY") {
        return `Gemini API key error (${response.status}): ${errorMsg}`;
      }
      if (response.status === 429 || errorCode === "RESOURCE_EXHAUSTED") {
        return `Rate limit / quota reached (429): ${errorMsg}`;
      }
      throw new Error(errorMsg);
    }

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      const text = await response.text();
      if (text.includes("<!doctype html>") || text.includes("<html") || text.includes("<body")) {
        return "Mimi server is restarting, please try again in a second.";
      }
      throw new Error(`Expected JSON but received ${contentType || "unknown"}. Body: ${text.substring(0, 100)}`);
    }

    const data = await response.json();
    return data.text || "I didn't catch a response for that. Could you try again?";
  } catch (error) {
    console.error("Gemini Proxy Error:", error);
    const errStr = String(error).toLowerCase();

    if (errStr.includes("failed to fetch")) {
      return "Unable to reach the Mimi server. Please check your connection and try again.";
    }
    if (errStr.includes("safety") || errStr.includes("blocked")) {
      return "That request was blocked by safety filters. Please rephrase and try again.";
    }
    return `Gemini request failed: ${error instanceof Error ? error.message : String(error)}`;
  }
}

export async function getAgentResponse(
  prompt: string,
  agent: string
): Promise<{ text: string; steps?: any[] }> {
  try {
    const response = await fetch("/api/gemini/agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, agent }),
    });

    if (!response.ok) {
      let errorMsg = `Server returned ${response.status}`;
      try {
        const err = await response.json();
        errorMsg = err.error || errorMsg;
      } catch {
        const text = await response.text();
        errorMsg = text.substring(0, 120) || errorMsg;
      }
      throw new Error(errorMsg);
    }

    return await response.json();
  } catch (error) {
    console.error("Agent Proxy Error:", error);
    throw error;
  }
}

export async function getMimiAudio(
  text: string,
  voiceId?: string,
  voiceProfile?: string
): Promise<string | null> {
  try {
    const response = await fetch("/api/gemini/tts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, voiceId, voiceProfile }),
    });

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    return data.audio || null;
  } catch (error) {
    console.error("Audio Proxy Error:", error);
    return null;
  }
}
