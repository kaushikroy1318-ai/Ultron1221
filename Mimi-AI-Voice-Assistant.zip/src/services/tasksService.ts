export interface GoogleTaskList {
  id: string;
  title: string;
  updated: string;
}

export interface GoogleTask {
  id: string;
  title: string;
  notes?: string;
  status: "needsAction" | "completed";
  due?: string; // RFC 3339
  completed?: string; // RFC 3339
  updated: string;
}

export async function listTaskLists(accessToken: string): Promise<GoogleTaskList[]> {
  const url = 'https://tasks.googleapis.com/v1/users/@me/lists?pageSize=50';
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch tasks lists: ${res.statusText}`);
  }
  const data = await res.json();
  return data.items || [];
}

export async function listTasks(accessToken: string, listId: string): Promise<GoogleTask[]> {
  const url = `https://tasks.googleapis.com/v1/lists/${listId}/tasks?pageSize=100&showCompleted=true&showHidden=true`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to fetch tasks: ${res.statusText}`);
  }
  const data = await res.json();
  return data.items || [];
}

export async function createGoogleTask(
  accessToken: string,
  listId: string,
  task: { title: string; notes?: string; due?: string }
): Promise<GoogleTask> {
  const url = `https://tasks.googleapis.com/v1/lists/${listId}/tasks`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(task)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to create task: ${res.statusText}`);
  }
  return await res.json();
}

export async function updateGoogleTask(
  accessToken: string,
  listId: string,
  taskId: string,
  updateBody: Partial<GoogleTask>
): Promise<GoogleTask> {
  const url = `https://tasks.googleapis.com/v1/lists/${listId}/tasks/${taskId}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(updateBody)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to update task: ${res.statusText}`);
  }
  return await res.json();
}

export async function deleteGoogleTask(accessToken: string, listId: string, taskId: string): Promise<void> {
  const url = `https://tasks.googleapis.com/v1/lists/${listId}/tasks/${taskId}`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${accessToken}` }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || `Failed to delete task: ${res.statusText}`);
  }
}
