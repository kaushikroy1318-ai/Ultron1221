/**
 * AudioStreamer handles smooth 24kHz PCM16 audio playback from Gemini Live
 * while exposing live frequency magnitudes for visualizers across all UI themes.
 */
export class AudioStreamer {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private analyserBuffer: Uint8Array<ArrayBuffer> | null = null;
  private gainNode: GainNode | null = null;
  private nextStartTime = 0;
  private activeSources = new Set<AudioBufferSourceNode>();
  private readonly sampleRate = 24000;
  public onPlaybackDrain: (() => void) | null = null;

  constructor() {
    audioStreamerRegistry.add(this);
  }

  public isPlaying(): boolean {
    return this.activeSources.size > 0;
  }

  private ensureContext(): AudioContext {
    if (!this.ctx || this.ctx.state === "closed") {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ sampleRate: this.sampleRate });
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.analyser.smoothingTimeConstant = 0.72;

      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = 1;

      this.gainNode.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
      const buf = new ArrayBuffer(this.analyser.frequencyBinCount);
      this.analyserBuffer = new Uint8Array(buf);
      this.nextStartTime = this.ctx.currentTime;
    }

    if (this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }

    return this.ctx;
  }

  /**
   * Decodes base64 PCM16 little-endian audio (24kHz mono) and queues seamless playback.
   */
  public addPCM16(base64Audio: string): void {
    if (!base64Audio) return;
    try {
      const ctx = this.ensureContext();
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      if (len < 2) return;

      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const numSamples = Math.floor(bytes.length / 2);
      const view = new DataView(bytes.buffer, bytes.byteOffset, numSamples * 2);
      const float32 = new Float32Array(numSamples);
      for (let i = 0; i < numSamples; i++) {
        float32[i] = view.getInt16(i * 2, true) / 32768;
      }

      const audioBuffer = ctx.createBuffer(1, numSamples, this.sampleRate);
      audioBuffer.copyToChannel(float32, 0);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      if (this.gainNode) {
        source.connect(this.gainNode);
      } else {
        source.connect(ctx.destination);
      }

      const now = ctx.currentTime;
      if (this.nextStartTime < now) {
        this.nextStartTime = now + 0.015;
      }

      const startAt = this.nextStartTime;
      this.nextStartTime = startAt + audioBuffer.duration;

      this.activeSources.add(source);
      source.onended = () => {
        this.activeSources.delete(source);
        try {
          source.disconnect();
        } catch {
          // ignore cleanup failure
        }
        if (this.activeSources.size === 0 && this.onPlaybackDrain) {
          this.onPlaybackDrain();
        }
      };

      source.start(startAt);
    } catch (err) {
      console.warn("AudioStreamer addPCM16 warning:", err);
    }
  }

  /**
   * Immediately interrupts and clears all queued audio (for barge-in & session teardown).
   */
  public stop(): void {
    for (const source of this.activeSources) {
      try {
        source.onended = null;
        source.stop();
        source.disconnect();
      } catch {
        // already stopped
      }
    }
    this.activeSources.clear();
    if (this.ctx && this.ctx.state !== "closed") {
      this.nextStartTime = this.ctx.currentTime;
    } else {
      this.nextStartTime = 0;
    }
  }

  public destroy(): void {
    this.stop();
    audioStreamerRegistry.delete(this);
    if (this.ctx && this.ctx.state !== "closed") {
      this.ctx.close().catch(() => {});
    }
    this.ctx = null;
    this.analyser = null;
    this.analyserBuffer = null;
    this.gainNode = null;
  }

  public sampleFrequencyData(out: Uint8Array): boolean {
    if (!this.ctx || this.ctx.state !== "running" || !this.analyser || !this.analyserBuffer) {
      return false;
    }
    if (this.activeSources.size === 0) {
      return false;
    }
    this.analyser.getByteFrequencyData(this.analyserBuffer);
    const limit = Math.min(out.length, this.analyserBuffer.length);
    let active = false;
    for (let i = 0; i < limit; i++) {
      if (this.analyserBuffer[i] > out[i]) {
        out[i] = this.analyserBuffer[i];
      }
      if (this.analyserBuffer[i] > 0) active = true;
    }
    return active;
  }
}

const audioStreamerRegistry = new Set<AudioStreamer>();

class AudioStreamerService {
  private analysers = new Map<AudioContext, AnalyserNode>();
  private dataBuffers = new Map<AudioContext, Uint8Array<ArrayBuffer>>();

  /**
   * Ensures an AnalyserNode exists for the given AudioContext and is routed to ctx.destination.
   */
  public getOrCreateAnalyser(ctx: AudioContext): AnalyserNode {
    let analyser = this.analysers.get(ctx);
    if (!analyser) {
      analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.72;
      analyser.connect(ctx.destination);
      this.analysers.set(ctx, analyser);
      const buffer = new ArrayBuffer(analyser.frequencyBinCount);
      this.dataBuffers.set(ctx, new Uint8Array(buffer));
    }
    return analyser;
  }

  /**
   * Connects an AudioNode (such as an AudioBufferSourceNode) through the shared AnalyserNode.
   */
  public connectSource(ctx: AudioContext, source: AudioNode): void {
    try {
      const analyser = this.getOrCreateAnalyser(ctx);
      source.connect(analyser);
    } catch {
      try {
        source.connect(ctx.destination);
      } catch {
        // Ignore if context is already closing
      }
    }
  }

  /**
   * Releases references when an AudioContext is closed.
   */
  public releaseContext(ctx: AudioContext | null): void {
    if (!ctx) return;
    this.analysers.delete(ctx);
    this.dataBuffers.delete(ctx);
  }

  /**
   * Returns a Uint8Array of frequency bin magnitudes (0..255) across active audio contexts and AudioStreamer instances.
   */
  public getFrequencyData(targetLength = 32): Uint8Array {
    const out = new Uint8Array(targetLength);
    let hasActiveSignal = false;

    for (const streamer of audioStreamerRegistry) {
      if (streamer.sampleFrequencyData(out)) {
        hasActiveSignal = true;
      }
    }

    for (const [ctx, analyser] of this.analysers.entries()) {
      if (ctx.state === "closed") {
        this.analysers.delete(ctx);
        this.dataBuffers.delete(ctx);
        continue;
      }
      if (ctx.state !== "running") continue;

      const buf = this.dataBuffers.get(ctx);
      if (!buf) continue;

      analyser.getByteFrequencyData(buf);
      const limit = Math.min(targetLength, buf.length);
      for (let i = 0; i < limit; i++) {
        if (buf[i] > out[i]) {
          out[i] = buf[i];
        }
        if (buf[i] > 0) {
          hasActiveSignal = true;
        }
      }
    }

    if (!hasActiveSignal) {
      return out;
    }
    return out;
  }

  /**
   * Returns a normalized loudness scalar in [0, 1] suitable for driving waveforms & 3D orb pulsing.
   */
  public getNormalizedLoudness(): number {
    const bins = this.getFrequencyData(24);
    let sum = 0;
    let peak = 0;
    for (let i = 0; i < bins.length; i++) {
      sum += bins[i];
      if (bins[i] > peak) peak = bins[i];
    }
    const avg = sum / (bins.length * 255);
    const peakNorm = peak / 255;
    return Math.min(1, avg * 1.45 + peakNorm * 0.45);
  }
}

export const audioStreamer = new AudioStreamerService();
