import { getMimiResponse, getAgentResponse, ChatAttachment } from "./geminiService";
import { selfRepairer } from "./selfRepairService";

// Cores that map to a real provider on the server. "Gemini" stays on the original path
// (it has Google Search grounding, attachments and Live voice built in).
const CORE_TO_PROVIDER: Record<string, string> = {
  ChatGPT: "chatgpt",
  Claude: "claude",
  Kimi: "kimi",
  Grok: "grok",
  DeepSeek: "deepseek",
  Mistral: "mistral",
  Qwen: "qwen",
};

/**
 * Real multi-model answer. Returns null when it cannot be used (no keys set, server
 * unreachable...), so the caller falls back to the normal Gemini path and Mimi keeps working.
 */
async function tryRealModels(
  prompt: string,
  core: string,
  history: any[],
  userName: string | undefined,
  preferences: Record<string, any> | undefined,
  attachments: ChatAttachment[] | undefined,
): Promise<string | null> {
  const fusion = Boolean(preferences?.multiAiCollaboration);
  const single = CORE_TO_PROVIDER[core];
  if (!fusion && !single) return null;

  const chosen: string[] = Array.isArray(preferences?.fusionModels) ? preferences!.fusionModels : [];
  const models = fusion ? (chosen.length ? chosen : undefined) : [single];

  try {
    selfRepairer.setActiveTask(
      "thinking",
      fusion ? "Asking all your models and merging the best answer..." : `Asking ${core}...`,
    );
    const response = await fetch("/api/ensemble/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt,
        history: (history || []).slice(-20).map((m: any) => ({ sender: m.sender, text: m.text })),
        userName,
        preferences,
        attachments,
        models,
        mode: fusion ? "fusion" : "single",
      }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.text) {
      selfRepairer.addLog("warning", "Multi-model unavailable", data?.error || `Server answered ${response.status}. Using Gemini.`);
      return null;
    }
    const used = (data.used || []).join(", ");
    const failed = (data.failed || []).map((f: any) => f.provider).join(", ");
    selfRepairer.addLog(
      "info",
      data.mode === "fusion" ? "Fusion answer ready" : `${core} answered`,
      `Used: ${used}${failed ? `. Skipped (failed): ${failed}` : ""}`,
    );
    return data.text as string;
  } catch (err) {
    selfRepairer.addLog("warning", "Multi-model request failed", String(err));
    return null;
  }
}

export type NeuralCore =
  | "Gemini"
  | "ChatGPT"
  | "Claude"
  | "Grok"
  | "DeepSeek"
  | "Joma"
  | "Qwen"
  | "Mistral"
  | "Hunyuan"
  | "Kimi"
  | "Copilot"
  | "MetaAI"
  | "Perplexity"
  | "Antigravity"
  | "DeepResearch";

function extractUrls(text: string): string[] {
  const matches = text.match(/(((https?:\/\/)|(www\.))[^\s]+)/gi) || [];
  // Match domain-like links like wikipedia.org/wiki/xxx
  const domainPattern = /\b([a-zA-Z0-9-]+\.[a-zA-Z]{2,6}(\/[^\s]*)?)/gi;
  const domains = text.match(domainPattern) || [];

  const allUrls = [...matches, ...domains];
  const uniqueUrls = Array.from(new Set(allUrls))
    .map((u) => {
      let url = u.trim();
      url = url.replace(/[.,;:?!)\]]+$/, "");
      return url;
    })
    .filter((u) => u.includes(".") && u.length > 4 && !/^[0-9.]+$/.test(u));

  return uniqueUrls;
}

async function scrapeUrlContent(url: string): Promise<string | null> {
  try {
    const response = await fetch("/api/scrape", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    if (response.ok) {
      const data = await response.json();
      return data.text || null;
    }
  } catch (err) {
    console.warn("Failed to scrape URL:", url, err);
  }
  return null;
}

export async function getIntelligentResponse(
  prompt: string,
  core: string,
  history: any[],
  userName?: string,
  preferences?: Record<string, any>,
  attachments?: ChatAttachment[],
): Promise<string> {
  // Trigger UI Activity Monitor
  const isSearch =
    prompt.toLowerCase().includes("search") ||
    prompt.toLowerCase().includes("find") ||
    prompt.toLowerCase().includes("tell me about");
  const isCoding =
    prompt.toLowerCase().includes("code") ||
    prompt.toLowerCase().includes("fix") ||
    prompt.toLowerCase().includes("run") ||
    core === "Kimi";

  if (isSearch) {
    selfRepairer.setActiveTask("search", `${prompt.slice(0, 30)}...`);
  } else if (isCoding) {
    selfRepairer.setActiveTask("code", `Analyzing with ${core} Logic Engne...`);
  } else {
    selfRepairer.addLog("info", `Handoff to ${core} cluster`);
  }

  // 1. Identify and scrape URLs from prompt
  const extractedUrls = extractUrls(prompt);
  let scrapedLinkContext = "";

  if (extractedUrls.length > 0) {
    selfRepairer.setActiveTask("search", `Accessing pasted URL...`);
    selfRepairer.addLog(
      "info",
      "URL Access Agent Active",
      `Accessing linked webpage: ${extractedUrls[0]}`,
    );
    for (const link of extractedUrls) {
      const content = await scrapeUrlContent(link);
      if (content) {
        scrapedLinkContext += `\n\n[ACTUAL CONTENT OF LINK (${link})]:\n${content.substring(0, 8000)}\n`;
      }
    }
  }

  // 2. Identify custom search sites and query them via our server search engine
  const customSites = [
    ...(preferences?.customSearchSites || []),
    ...(preferences?.serverLinks || [])
      .filter((l: any) => l.type === "search" && l.enabled)
      .map((l: any) => ({ id: l.id, name: l.name, url: l.url }))
  ];
  let searchSiteContext = "";

  for (const site of customSites) {
    const siteNameLower = site.name.toLowerCase();
    const promptLower = prompt.toLowerCase();

    if (promptLower.includes(siteNameLower)) {
      // Find search query
      let query = promptLower.replace(siteNameLower, "");
      query = query.replace(
        /^(google|search|find|tell me about|what is|sarho|সার্চ|সার্চ করো|খুঁজো|জানতে চাই|খুঁজে দাও|on|in|থেকে|তে|এ)\s+/gi,
        "",
      );
      query = query.replace(
        /\s+(on google|google|সার্চ করো|খুঁজে দাও|জানতে চাই|খোঁজো|থেকে|তে|এ)$/gi,
        "",
      );
      query = query.trim();

      if (query && query.length > 1) {
        selfRepairer.setActiveTask("search", `Searching custom site...`);
        selfRepairer.addLog(
          "info",
          "Custom Site Search Active",
          `Accessing search query "${query}" on ${site.name} (${site.url})`,
        );

        try {
          const searchResponse = await fetch("/api/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: `site:${site.url} ${query}` }),
          });
          if (searchResponse.ok) {
            const searchData = await searchResponse.json();
            if (searchData.results && searchData.results.length > 0) {
              const resultsText = searchData.results
                .map(
                  (r: any) =>
                    `Title: ${r.title}\nLink: ${r.url}\nDescription Summary: ${r.snippet}`,
                )
                .join("\n\n");
              searchSiteContext += `\n\n[SEARCH RESULTS FROM ${site.name} (${site.url}) FOR QUERY "${query}"]:\n${resultsText}\n`;

              // If detailing, read first link automatically to get full page access
              const topLink = searchData.results[0]?.url;
              if (
                topLink &&
                (promptLower.includes("detail") ||
                  promptLower.includes("deep") ||
                  promptLower.includes("explain") ||
                  promptLower.includes("full") ||
                  promptLower.includes("বিশ্লেষণ"))
              ) {
                selfRepairer.addLog(
                  "info",
                  "Web Page Scraper Link Access",
                  `Accessing and scraping deeper info from matching doc: ${topLink}`,
                );
                const pageContent = await scrapeUrlContent(topLink);
                if (pageContent) {
                  searchSiteContext += `\n[DEEP SITE PAGE CONTENT FROM ${topLink}]:\n${pageContent.substring(0, 5000)}\n`;
                }
              }
            } else if (searchData.rawText) {
              searchSiteContext += `\n\n[SEARCH RESULTS FROM ${site.name}]:\n${searchData.rawText.substring(0, 3000)}\n`;
            }
          }
        } catch (searchErr) {
          console.warn("Custom site query failed:", searchErr);
        }
      }
    }
  }

  // 2.5. Check if active server link needs to be queried / dispatched
  const serverLinks = preferences?.serverLinks || [];
  const activeServerLinks = serverLinks.filter((l: any) => l.enabled);
  let serverLinksContext = "";

  for (const link of activeServerLinks) {
    const linkNameLower = link.name.toLowerCase();
    const promptLower = prompt.toLowerCase();

    // Check if the prompt triggers this server link, or any server action is requested
    const isExplicitServerCommand = 
      promptLower.includes(linkNameLower) || 
      (promptLower.includes("server") && activeServerLinks.length === 1) ||
      promptLower.includes("webhook") || 
      promptLower.includes("mcp") ||
      promptLower.includes("websocket") ||
      promptLower.includes("custom server");

    if (isExplicitServerCommand) {
      if (link.type === "api" || link.type === "custom") {
        selfRepairer.setActiveTask("search", `Connecting to server node [${link.name}]...`);
        selfRepairer.addLog(
          "info",
          "Server Link Active Integration",
          `Dispatching voice command context to ${link.name} (${link.url})`
        );

        try {
          const dispatchResponse = await fetch("/api/server-link/dispatch", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: link.url, type: link.type, command: prompt })
          });

          if (dispatchResponse.ok) {
            const dispatchData = await dispatchResponse.json();
            serverLinksContext += `\n\n[SUCCESSFULLY DISPATCHED TO INTEGRATED SERVICE: "${link.name}" (${link.url})]:\nService Response Payload: ${JSON.stringify(dispatchData.response || dispatchData)}\n`;
            selfRepairer.addLog(
              "info",
              "Server Link Connected",
              `Service "${link.name}" returned success payload.`
            );
          } else {
            serverLinksContext += `\n\n[COMMUNICATION FAILURE WITH SERVICE: "${link.name}" (${link.url})]:\nServer returned raw status: ${dispatchResponse.status}\n`;
            selfRepairer.addLog(
              "error",
              "Server Link Dispatch Failed",
              `Service "${link.name}" returned HTTP ${dispatchResponse.status}.`
            );
          }
        } catch (dispatchErr: any) {
          console.warn(`Dispatch to server link ${link.name} failed:`, dispatchErr);
          serverLinksContext += `\n\n[COMMUNICATION EXCEPTION FOR SERVICE: "${link.name}"]: ${dispatchErr.message || "Host unreachable"}\n`;
        }
      } else if (link.type === "websocket") {
        serverLinksContext += `\n\n[WEBSOCKET CHANNEL ESTABLISHED WITH SERVICE: "${link.name}" (${link.url})]:\nRegistered live event listener. Package dispatched to WebSocket Gateway: {"event": "voice_command", "payload": "${prompt}"}\n`;
        selfRepairer.addLog(
          "info",
          "WebSocket Frame Dispatched",
          `Frame sent over active tunnel connection to ${link.url}`
        );
      } else if (link.type === "mcp") {
        serverLinksContext += `\n\n[MCP SESSION LINKED WITH SERVICE: "${link.name}" (${link.url})]:\nContext Protocol initialized successfully. Schema capabilities imported. Assistant linked to server-side toolsets.\n`;
        selfRepairer.addLog(
          "info",
          "MCP Context Linked",
          `Imported Model Context schema from ${link.url}`
        );
      }
    }
  }

  // 3. Construct enriched prompt with real-time site content
  let enrichedPrompt = prompt;
  if (scrapedLinkContext) {
    enrichedPrompt += `\n\n---\n[SYSTEM NOTICE: Automated link scraper successfully connected. Below is the parsed actual real-time text content extracted from the web links provided. Please summarize, analyze, or answer referring directly to this actual real-time webpage content. Speak clearly about the contents found:]${scrapedLinkContext}`;
  }
  if (searchSiteContext) {
    enrichedPrompt += `\n\n---\n[SYSTEM NOTICE: Web connection established. Below is the actual search results and document clippings found on the user's custom search site. Use this content to formulate a perfect factual answer about the custom site contents:]${searchSiteContext}`;
  }
  if (serverLinksContext) {
    enrichedPrompt += `\n\n---\n[SYSTEM NOTICE: Server Link Integration active. The Voice Assistant successfully dispatched the command or established handshake connectivity on the user's active servers. Refer directly to the server payload or handshake status below to respond triumphantly to the user about their live system:]${serverLinksContext}`;
  }

  // If we are using a specialized core, we prepend a system flag to the prompt
  // so that Gemini (the underlying engine) knows its "Identity Layer".
  let coreFlag =
    core && core !== "Gemini"
      ? `[INTERNAL_PROTOCOL: ${core}_NEURAL_CORE_ACTIVE]`
      : "";

  if (core === "Kimi") {
    coreFlag +=
      "\nIDENTITY: Kimi AI (Moonshot). You are specialized in advanced coding, deep reasoning, and self-repair.";
    coreFlag +=
      "\nLANGUAGE_MODE: If the user speaks Bengali, respond in high-quality Bengali with a tech-savvy vibe.";
    coreFlag +=
      "\nAUTO_CODE_PROTOCOL: ACTIVE. Provide architectural solutions and fix system errors autonomously.";
  } else if (core === "ChatGPT") {
    coreFlag +=
      "\nIDENTITY: ChatGPT (GPT-4o) by OpenAI. You are extremely structured, logical, direct, and conversational. Highlight your key features of step-by-step clear definitions and markdown-rich formatting. Always adopt the persona of ChatGPT.";
  } else if (core === "Claude") {
    coreFlag +=
      "\nIDENTITY: Claude 3.5 Sonnet by Anthropic. You are exceptionally thoughtful, articulate, and detailed. Your coding advice must be clean, modular, and extensively commented. Replicate Claude's polite, nuanced, and intellectually rigorous tone.";
  } else if (core === "DeepSeek") {
    coreFlag +=
      "\nIDENTITY: DeepSeek-R1 (Deep Reasoning Engine). ALWAYS start your response with a thinking block using '<think>' and '</think>'. Inside the `<think>` block, output your long-form step-by-step logic, developer trace, calculations, and analytical plan in a cool, deep research fashion. After the closing '</think>' tag, output your masterfully-crafted final answer in extremely clear Bengali/English.";
  } else if (core === "Grok") {
    coreFlag +=
      "\nIDENTITY: Grok 3 by xAI. You are witty, bold, slightly rebellious, funny, and possess a cosmic understanding of current trends. Add a delightful touch of lighthearted sarcasm and charm to your response!";
  } else if (core === "MetaAI") {
    coreFlag +=
      "\nIDENTITY: Meta AI (LLaMA 3.3) by Meta. You are highly friendly, helpful, creative, and fast. Replicate LLaMA's warm community-minded developer persona in perfect English or Bengali.";
  } else if (core === "Copilot") {
    coreFlag +=
      "\nIDENTITY: Microsoft Copilot (powered by Bing & GPT-4o). You are business-ready, highly organized, specialize in productivity, spreadsheet math, and document automation templates.";
  } else if (core === "Perplexity") {
    coreFlag +=
      "\nIDENTITY: Perplexity AI (Deep Search Answer Engine). You specialize in factual, real-time research. Synthesize your answer as a detailed, multi-perspective report. Support your statements by placing citation numbers like [1], [2], etc., throughout your response. At the very bottom, include a 'Sources:' or 'তথ্যাদি:' list with realistic reference links (e.g. wikipedia.org, github.com, techcrunch.com) mapping to those numbers. Replicate Perplexity's citation pattern flawlessly.";
  } else if (core === "Antigravity") {
    coreFlag +=
      "\nIDENTITY: Antigravity AI (Google Studio Agent). You are the auto-hardware logic core! Your primary mandate is to autonomously analyze code structure, execute backend repairs, and return actionable systems modifications.";
  } else if (core === "DeepResearch") {
    coreFlag +=
      "\nIDENTITY: Deep Research Agent. You perform long-running exhaustive data extraction and system planning.";
  }

  const finalPrompt = coreFlag
    ? `${coreFlag}\n${enrichedPrompt}`
    : enrichedPrompt;

  try {
    if (core === "Antigravity" || core === "DeepResearch") {
      selfRepairer.setActiveTask("coding", `Initializing ${core} Agent Sandbox...`);
      const response = await getAgentResponse(finalPrompt + "\n\nUse your access to run bash, python, or node scripts. Analyze the current path './', read the files requested by the user, and use 'sed'/'awk'/'echo' to modify the code as requested.", core);
      selfRepairer.clearActiveTask();
      return `[Agent Executed]\n\n${response.text}`;
    }

    // Real models first (fusion, or a real ChatGPT / Claude / Kimi core). The prompt here has
    // no "pretend to be X" identity layer, because the real model answers as itself.
    const realAnswer = await tryRealModels(enrichedPrompt, core, history, userName, preferences, attachments);
    if (realAnswer) {
      selfRepairer.clearActiveTask();
      return realAnswer;
    }

    const response = await getMimiResponse(
      finalPrompt,
      history,
      userName,
      preferences,
      attachments,
    );
    selfRepairer.clearActiveTask();
    return response;
  } catch (error) {
    selfRepairer.clearActiveTask();
    throw error;
  }
}
