import { wsUrl as buildWsUrl } from "../lib/apiBase";
import { LiveServerMessage } from "@google/genai";
import { audioStreamer } from "./audioStreamer";

export type LiveConnectionStatus = "connected" | "connecting" | "disconnected";

export class LiveSessionManager {
  private ws: WebSocket | null = null;
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  
  // Video support
  private videoStream: MediaStream | null = null;
  private videoFrameTimeout: any = null;
  private isProcessingFrame: boolean = false;
  
  // Audio playback state
  private playbackContext: AudioContext | null = null;
  private nextPlayTime: number = 0;
  private isPlaying: boolean = false;
  public isMuted: boolean = false;
  public audioStreamer = audioStreamer;
  
  public onCommand: (url: string) => void = () => {};
  public onStateChange: (state: "idle" | "listening" | "processing" | "speaking") => void = () => {};
  public onConnectionChange: (status: LiveConnectionStatus) => void = () => {};
  public onMessage: (sender: "user" | "mimi", text: string) => void = () => {};
  public onError: (message: string) => void = () => {};

  setVideoStream(stream: MediaStream | null) {
    this.videoStream = stream;
    if (stream) {
      this.startVideoLoop();
    } else {
      this.stopVideoLoop();
    }
  }

  private async startVideoLoop() {
    this.stopVideoLoop();
    const video = document.createElement("video");
    video.srcObject = this.videoStream;
    video.muted = true;
    try {
      await video.play();
    } catch (e) {
      console.error("Error playing video for capture", e);
      return;
    }

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");

    const processFrame = async () => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN || !ctx || !video.readyState || !this.videoStream) return;
      if (this.isProcessingFrame) {
        this.videoFrameTimeout = setTimeout(processFrame, 100);
        return;
      }

      this.isProcessingFrame = true;

      try {
        canvas.width = 480;
        canvas.height = 360;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const base64 = canvas.toDataURL("image/jpeg", 0.5).split(",")[1];

        this.ws.send(JSON.stringify({
          type: "input",
          input: { video: { data: base64, mimeType: "image/jpeg" } }
        }));
      } catch (err) {
        console.error("Error sending video frame", err);
      } finally {
        this.isProcessingFrame = false;
        this.videoFrameTimeout = setTimeout(processFrame, 500); 
      }
    };

    processFrame();
  }

  private stopVideoLoop() {
    if (this.videoFrameTimeout) {
      clearTimeout(this.videoFrameTimeout);
      this.videoFrameTimeout = null;
    }
    this.isProcessingFrame = false;
  }

  constructor() {
    // No API key needed on client anymore
  }

  async start(userName?: string, preferences?: Record<string, any>) {
    try {
      this.onStateChange("processing");
      this.onConnectionChange("connecting");
      
      const wsUrl = buildWsUrl("/api/live"); // server address + access token (see lib/apiBase.ts)
      
      console.log(`Mimi connecting to Live Bridge: ${wsUrl.split("?")[0]}`);
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.onConnectionChange("connected");
        this.ws?.send(JSON.stringify({
          type: "setup",
          userName,
          preferences
        }));
      };

      this.ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.type === "live") {
          this.handleLiveMessage(msg.data);
        } else if (msg.type === "state") {
          this.onStateChange(msg.state);
        } else if (msg.type === "error") {
          this.onError(msg.message);
          this.stop();
        }
      };

      this.ws.onerror = (err) => {
        console.error("WebSocket Error:", err);
        this.onConnectionChange("disconnected");
        this.onError("Network error. Could not connect to Live Bridge.");
        this.stop();
      };

      this.ws.onclose = () => {
        this.onConnectionChange("disconnected");
        this.onStateChange("idle");
      };

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      
      if (!this.audioContext || this.audioContext.state === 'closed') {
        this.audioContext = new AudioContextClass({ sampleRate: 16000 });
      }
      if (!this.playbackContext || this.playbackContext.state === 'closed') {
        this.playbackContext = new AudioContextClass({ sampleRate: 24000 });
      }
      
      if (this.audioContext.state === 'suspended') await this.audioContext.resume();
      if (this.playbackContext.state === 'suspended') await this.playbackContext.resume();

      this.nextPlayTime = this.playbackContext.currentTime;

      this.mediaStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
        } 
      });

      this.source = this.audioContext.createMediaStreamSource(this.mediaStream);
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);

      this.processor.onaudioprocess = (e) => {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16 = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          let s = Math.max(-1, Math.min(1, inputData[i]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        
        const buffer = new ArrayBuffer(pcm16.length * 2);
        const view = new DataView(buffer);
        for (let i = 0; i < pcm16.length; i++) {
          view.setInt16(i * 2, pcm16[i], true);
        }
        
        let binary = '';
        const bytes = new Uint8Array(buffer);
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64Data = btoa(binary);

        this.ws.send(JSON.stringify({
          type: "input",
          input: { audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' } }
        }));
      };

      this.source.connect(this.processor);
      this.processor.connect(this.audioContext.destination);

    } catch (error) {
      console.error("Failed to start Live Session:", error);
      this.stop();
    }
  }

  private handleLiveMessage(message: LiveServerMessage) {
    // Handle Audio Output
    const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      this.onStateChange("speaking");
      this.playAudioChunk(base64Audio);
    }

    // Handle Interruption
    if (message.serverContent?.interrupted) {
      this.stopPlayback();
      this.onStateChange("listening");
    }

    // Handle Transcriptions
    const userText = message.serverContent?.modelTurn?.parts?.[0]?.text;
    if (userText) {
       this.onMessage("mimi", userText);
    }

    // Handle Function Calls (Tool Calls)
    const functionCalls = message.toolCall?.functionCalls;
    if (functionCalls && functionCalls.length > 0) {
      for (const call of functionCalls) {
        if (call.name === "executeBrowserAction") {
          const args = call.args as any;
          let url = "";
          if (args.actionType === "youtube") {
            url = `https://www.youtube.com/results?search_query=${encodeURIComponent(args.query)}`;
          } else if (args.actionType === "spotify") {
            url = `https://open.spotify.com/search/${encodeURIComponent(args.query)}`;
          } else if (args.actionType === "whatsapp") {
            url = `https://web.whatsapp.com/send?phone=${args.target || ''}&text=${encodeURIComponent(args.query)}`;
          } else {
            let website = args.query.replace(/\s+/g, "");
            if (!website.includes(".")) website += ".com";
            url = `https://www.${website}`;
          }
          
          this.onCommand(url);
          
          this.ws?.send(JSON.stringify({
            type: "tool_response",
            response: {
              functionResponses: [{
                name: call.name,
                id: call.id,
                response: { result: "Action executed successfully in the browser." }
              }]
            }
          }));
        } else if (call.name === "get_device_time") {
          const now = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata", hour12: true });
          this.ws?.send(JSON.stringify({
            type: "tool_response",
            response: {
              functionResponses: [{
                name: call.name,
                id: call.id,
                response: { current_time: now }
              }]
            }
          }));
        }
      }
    }
  }

  private playAudioChunk(base64Data: string) {
    if (!this.playbackContext || this.isMuted) return;
    
    try {
      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const buffer = new Int16Array(bytes.buffer);
      const audioBuffer = this.playbackContext.createBuffer(1, buffer.length, 24000);
      const channelData = audioBuffer.getChannelData(0);
      for (let i = 0; i < buffer.length; i++) {
        channelData[i] = buffer[i] / 32768.0;
      }
      
      const source = this.playbackContext.createBufferSource();
      source.buffer = audioBuffer;
      audioStreamer.connectSource(this.playbackContext, source);
      
      const currentTime = this.playbackContext.currentTime;
      if (this.nextPlayTime < currentTime) {
        this.nextPlayTime = currentTime;
      }
      
      source.start(this.nextPlayTime);
      this.nextPlayTime += audioBuffer.duration;
      this.isPlaying = true;
      
      source.onended = () => {
        if (this.playbackContext && this.playbackContext.currentTime >= this.nextPlayTime - 0.1) {
          this.isPlaying = false;
          this.onStateChange("listening");
        }
      };
    } catch (e) {
      console.error("Error playing chunk", e);
    }
  }

  private stopPlayback() {
    if (this.playbackContext) {
      audioStreamer.releaseContext(this.playbackContext);
      this.playbackContext.close();
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.playbackContext = new AudioContextClass({ sampleRate: 24000 });
      this.nextPlayTime = this.playbackContext.currentTime;
      this.isPlaying = false;
    }
  }

  stop() {
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(t => t.stop());
      this.mediaStream = null;
    }
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
    this.stopVideoLoop();
    this.stopPlayback();
    
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    
    this.onConnectionChange("disconnected");
    this.onStateChange("idle");
  }

  sendText(text: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: "input",
        input: { text }
      }));
    }
  }
}
