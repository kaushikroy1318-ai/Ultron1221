import React, { useState, useEffect, useRef, useCallback, lazy, Suspense } from "react";
import { Mic, MicOff, Loader2, Volume2, VolumeX, Keyboard, Send, Trash2, LogIn, LogOut, User as UserIcon, Camera, CameraOff, Monitor, MonitorOff, RefreshCcw, Image as ImageIcon, Mail, Maximize2, Minimize2, Expand, Shrink, Crop, Battery, BatteryCharging, BatteryWarning, Smartphone } from "lucide-react";
import { getMimiAudio, resetMimiSession, ChatAttachment } from "./services/geminiService";
import { getIntelligentResponse } from "./services/multiModelService";
import { processCommand } from "./services/commandService";
import { LiveConnectionStatus } from "./services/liveService";
import { LiveSession, LiveDebugTelemetry } from "./services/liveSession";
import { LiveDebugPanel } from "./components/LiveDebugPanel";
import { ThemeSwitcherButton, HomeThemeMode } from "./components/ThemeSwitcherButton";
import type { ClaudeConversationSummary, ToolLaunchId } from "./components/ClaudeHome";
import GoogleAuthDiagnostics from "./components/GoogleAuthDiagnostics";
import Visualizer from "./components/Visualizer";
import PermissionModal from "./components/PermissionModal";
import { HandCursor } from "./components/HandCursor";
import { HandGestureTutorial } from "./components/HandGestureTutorial";
import { BrainVisualizer } from "./components/BrainVisualizer";
import { SystemMonitor } from "./components/SystemMonitor";
import { ActivityMonitor, ActivityState } from "./components/ActivityMonitor";
import SassyAnimations from "./components/SassyAnimations";
import { selfRepairer, DiagnosticLog } from "./services/selfRepairService";
import { googleStudioManager } from "./services/googleStudioManager";
import { playPCM, stopPlayPCM } from "./utils/audioUtils";
import { motion, AnimatePresence } from "motion/react";
import { Settings, Sparkles, Eye, EyeOff, Hand, Palette, Check, Sliders, Cpu, Layers, Wifi, ShieldCheck, Activity, RefreshCw, LayoutGrid } from "lucide-react";

const SpatialHome = lazy(() =>
  import("./components/SpatialHome").then((m) => ({ default: m.SpatialHome }))
);
const ClaudeHome = lazy(() =>
  import("./components/ClaudeHome").then((m) => ({ default: m.ClaudeHome }))
);
const SettingsModal = lazy(() => import("./components/SettingsModal"));
const MimiPhotoHub = lazy(() => import("./components/MimiPhotoHub"));
const MimiGmailHub = lazy(() => import("./components/MimiGmailHub"));
const RealmeControlHub = lazy(() =>
  import("./components/RealmeControlHub").then((m) => ({ default: m.RealmeControlHub }))
);
const LiveSyncController = lazy(() =>
  import("./components/LiveSyncController").then((m) => ({ default: m.LiveSyncController }))
);
const SystemUpgrade = lazy(() =>
  import("./components/SystemUpgrade").then((m) => ({ default: m.SystemUpgrade }))
);
const MapsModal = lazy(() =>
  import("./components/MapsModal").then((m) => ({ default: m.MapsModal }))
);
const WifiScannerModal = lazy(() =>
  import("./components/WifiScannerModal").then((m) => ({ default: m.WifiScannerModal }))
);
const WhatsAppModal = lazy(() =>
  import("./components/ToolModals").then((m) => ({ default: m.WhatsAppModal }))
);
const YouTubeModal = lazy(() =>
  import("./components/ToolModals").then((m) => ({ default: m.YouTubeModal }))
);
const BrowserModal = lazy(() =>
  import("./components/ToolModals").then((m) => ({ default: m.BrowserModal }))
);
const SystemMonitorModal = lazy(() =>
  import("./components/ToolModals").then((m) => ({ default: m.SystemMonitorModal }))
);
import { 
  auth, 
  db, 
  initAuth, 
  loginWithGoogle, 
  loginWithGoogleWorkspace,
  loginAnonymously,
  logout, 
  doc, 
  setDoc, 
  getDoc, 
  collection, 
  addDoc, 
  serverTimestamp, 
  query, 
  orderBy, 
  limit, 
  onSnapshot,
  handleFirestoreError,
  OperationType,
  getCachedAccessToken
} from "./services/firebaseService";
import { User } from "firebase/auth";
import RadialOrbitalTimeline from "@/components/ui/radial-orbital-timeline";
import { timelineData } from "@/components/ui/demo";
import { historyMemoryService, Memory, SearchLog, ConversationLog, VoiceLog, CommandLog } from "./services/historyMemoryService";

type AppState = "idle" | "listening" | "processing" | "speaking" | "upgrading";

interface ChatMessage {
  id: string;
  sender: "user" | "mimi";
  text: string;
  url?: string;
  urlType?: "youtube" | "google" | "whatsapp" | "generic";
  query?: string;
  appName?: string;
  whatsappRecipient?: string;
  whatsappPhone?: string;
  whatsappMessage?: string;
  attachments?: { name: string; mimeType: string; previewUrl?: string }[];
}

interface LocalChatThread {
  id: string;
  title: string;
  updatedAtMs: number;
  messages: ChatMessage[];
}

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [searchHistory, setSearchHistory] = useState<SearchLog[]>([]);
  const [conversations, setConversations] = useState<ConversationLog[]>([]);
  const [diagnosticLogs, setDiagnosticLogs] = useState<DiagnosticLog[]>([]);
  const [voiceLogs, setVoiceLogs] = useState<VoiceLog[]>([]);
  const [commandLogs, setCommandLogs] = useState<CommandLog[]>([]);

  const logVoiceActivity = useCallback((event: string, text?: string, duration?: number) => {
    if (user?.uid) {
      historyMemoryService.saveVoiceLog(user.uid, event, text, duration).catch(err => {
        console.error("Save voice log fail", err);
      });
    }
  }, [user]);

  const logCommandExecution = useCallback((command: string, response: string, appName?: string, status: "success" | "failed" = "success") => {
    if (user?.uid) {
      historyMemoryService.saveCommandLog(user.uid, command, response, appName, status).catch(err => {
        console.error("Save command log fail", err);
      });
    }
  }, [user]);

  const handleClearVoiceLogs = async () => {
    if (!user) return;
    try {
      await historyMemoryService.clearVoiceLogs(user.uid);
      selfRepairer.addLog("info", "Vocal Archive Purged", "Cleaned voice activity history completely.");
    } catch (err) {
      console.error("Clear voice logs fail", err);
    }
  };

  const handleClearCommandLogs = async () => {
    if (!user) return;
    try {
      await historyMemoryService.clearCommandLogs(user.uid);
      selfRepairer.addLog("info", "Command Trace Cleared", "Purged system command execution histories.");
    } catch (err) {
      console.error("Clear command logs fail", err);
    }
  };

  const [activity, setActivity] = useState<ActivityState>({ type: "idle", detail: "" });

  // Initialize self-repair logs and task listener
  useEffect(() => {
    selfRepairer.setLogListener((logs) => {
      setDiagnosticLogs(logs);
    });
    selfRepairer.setTaskListener((task) => {
      if (task) {
        setActivity({ type: task.type as any, detail: task.message });
      } else {
        setActivity({ type: "idle", detail: "" });
      }
    });
    selfRepairer.addLog("info", "System Core Initialized", "All neural pathways active.");

    // Perform System Health Check via our dedicated status endpoint
    const checkHealth = async () => {
      try {
        setServerConnectionStatus("connecting");
        const response = await fetch("/api/health");
        if (response.ok) {
          const data = await response.json();
          if (data.status === "ok") {
            setServerConnectionStatus("connected");
            const extra = data.apiKeySet ? "Logic core ready." : "Mimi Offline (Key Missing).";
            selfRepairer.addLog("info", "Neural Proxy Connection", `Logic cluster synchronized. ${extra}`);
          } else {
            setServerConnectionStatus("disconnected");
            selfRepairer.addLog("warning", "Channel Latency Detected", "Main logic link shifting to backup node.");
          }
        } else {
          setServerConnectionStatus("disconnected");
          selfRepairer.addLog("warning", "Channel Latency Detected", `Server responded with status: ${response.status}`);
        }
      } catch (e) {
        setServerConnectionStatus("disconnected");
        selfRepairer.addLog("warning", "Neural Drift Detected", "Recalibrating local intelligence core.");
      }
    };
    checkHealth();
  }, []);
  const [preferences, setPreferences] = useState<Record<string, any>>(() => {
    const saved = localStorage.getItem("mimi_preferences");
    const defaultWorkspace = {
      photoCategory: "all",
      photoAutoMatch: true,
      gmailLimit: 15,
      gmailAutoRead: true,
      driveSafetyLimit: 10,
      driveListFilter: "all",
      chatAutoResponse: false,
      tasksSortStyle: "dateCreated",
      contactsSortStyle: "first",
    };
    const savedTheme = localStorage.getItem("mimi_home_theme");
    const validTheme =
      savedTheme === "classic" || savedTheme === "3d" || savedTheme === "claude"
        ? savedTheme
        : undefined;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const savedModel = parsed?.studioConfig?.activeModel || "";
        const upgradedModel =
          !savedModel ||
          savedModel.includes("1.5") ||
          savedModel.includes("2.0") ||
          savedModel.includes("2.5") ||
          savedModel.includes("3.5") ||
          savedModel === "gemini-3.8-flash"
            ? "gemini-4-hydrogen"
            : savedModel;
        return {
          ...parsed,
          homeLayoutMode: parsed.homeLayoutMode || validTheme || "3d",
          workspace: { ...defaultWorkspace, ...(parsed.workspace || {}) },
          studioConfig: {
            region: "global",
            latencyOptimization: true,
            ...(parsed.studioConfig || {}),
            activeModel: upgradedModel,
          },
        };
      } catch (e) {
        console.error("Failed to parse local preferences");
      }
    }
    return {
      name: "",
      relationshipType: "Casual",
      isMuted: false,
      homeLayoutMode: validTheme || "3d",
      claudeDarkMode: false,
      starredChatIds: [],
      traits: {
        sassiness: 70,
        wit: 80,
        emotionality: 50
      },
      autoGameMode: false,
      autoCodeMode: true,
      autoRecordingMode: true,
      satelliteMode: false,
      remoteControlMode: true,
      showSystemMonitor: true,
      neuralCore: "Gemini",
      voiceId: "Kore",
      workspace: defaultWorkspace,
      studioConfig: {
        region: "global",
        activeModel: "gemini-4-hydrogen",
        latencyOptimization: true
      }
    };
  });
  const updatePreference = (key: string, value: any) => {
    setPreferences((prev) => {
      const newPrefs = { ...prev, [key]: value };
      localStorage.setItem("mimi_preferences", JSON.stringify(newPrefs));
      if (key === "homeLayoutMode") {
        localStorage.setItem("mimi_home_theme", String(value));
      }
      if (user) {
        const userDocRef = doc(db, "users", user.uid);
        setDoc(userDocRef, { preferences: newPrefs, updatedAt: serverTimestamp() }, { merge: true })
          .catch(e => handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`));
      }
      return newPrefs;
    });
  };

  const handleSelectHomeTheme = useCallback((theme: HomeThemeMode) => {
    updatePreference("homeLayoutMode", theme);
  }, [user]);

  const getThemeColors = (colorName: string) => {
    switch (colorName) {
      case "gold":
        return {
          primary: "text-amber-400",
          primaryBg: "bg-amber-500",
          primaryBorder: "border-amber-500/30",
          bgGlow: "from-amber-600/10 via-orange-500/5 to-transparent",
          textGrad: "from-amber-300 via-yellow-200 to-orange-400",
          btnGrad: "from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-black shadow-[0_0_15px_rgba(245,158,11,0.4)]",
          btnBorder: "border-amber-500/35",
          accentColor: "#f5a623",
          radialGrad: "from-amber-500/15 via-orange-500/5 to-transparent",
          iconColor: "text-amber-400",
          gGlow: "rgba(245, 166, 35, 0.25)",
          brandGrad: "from-amber-400 to-orange-500"
        };
      case "cyan":
        return {
          primary: "text-cyan-400",
          primaryBg: "bg-cyan-500",
          primaryBorder: "border-cyan-500/30",
          bgGlow: "from-cyan-600/10 via-blue-500/5 to-transparent",
          textGrad: "from-cyan-300 via-teal-200 to-blue-400",
          btnGrad: "from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-black shadow-[0_0_15px_rgba(6,182,212,0.4)]",
          btnBorder: "border-cyan-500/35",
          accentColor: "#00e5ff",
          radialGrad: "from-cyan-500/15 via-blue-500/5 to-transparent",
          iconColor: "text-cyan-400",
          gGlow: "rgba(0, 229, 255, 0.25)",
          brandGrad: "from-cyan-400 to-blue-500"
        };
      case "emerald":
        return {
          primary: "text-emerald-400",
          primaryBg: "bg-emerald-500",
          primaryBorder: "border-emerald-500/30",
          bgGlow: "from-emerald-600/10 via-teal-500/5 to-transparent",
          textGrad: "from-emerald-300 via-green-200 to-teal-400",
          btnGrad: "from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-black shadow-[0_0_15px_rgba(16,185,129,0.4)]",
          btnBorder: "border-emerald-500/35",
          accentColor: "#10b981",
          radialGrad: "from-emerald-500/15 via-teal-500/5 to-transparent",
          iconColor: "text-emerald-400",
          gGlow: "rgba(16, 185, 129, 0.25)",
          brandGrad: "from-emerald-400 to-teal-500"
        };
      case "crimson":
        return {
          primary: "text-rose-400",
          primaryBg: "bg-rose-500",
          primaryBorder: "border-rose-500/30",
          bgGlow: "from-rose-600/10 via-pink-500/5 to-transparent",
          textGrad: "from-rose-300 via-red-200 to-pink-400",
          btnGrad: "from-rose-500 to-red-500 hover:from-rose-600 hover:to-red-600 text-white shadow-[0_0_15px_rgba(244,63,94,0.4)]",
          btnBorder: "border-rose-500/35",
          accentColor: "#f43f5e",
          radialGrad: "from-rose-500/15 via-red-500/5 to-transparent",
          iconColor: "text-rose-400",
          gGlow: "rgba(244, 63, 94, 0.25)",
          brandGrad: "from-rose-500 to-red-500"
        };
      case "violet":
      default:
        return {
          primary: "text-violet-400",
          primaryBg: "bg-violet-500",
          primaryBorder: "border-violet-500/30",
          bgGlow: "from-violet-600/10 via-fuchsia-500/5 to-transparent",
          textGrad: "from-cyan-300 via-violet-300 to-fuchsia-300",
          btnGrad: "from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 text-white shadow-[0_0_15px_rgba(139,92,246,0.4)]",
          btnBorder: "border-violet-500/35",
          accentColor: "#a78bfa",
          radialGrad: "from-violet-500/15 via-fuchsia-500/5 to-transparent",
          iconColor: "text-violet-400",
          gGlow: "rgba(167, 139, 250, 0.25)",
          brandGrad: "from-violet-500 to-fuchsia-500"
        };
    }
  };

  const th = getThemeColors(preferences.themeColor || "violet");

  useEffect(() => {
    if (preferences.studioConfig) {
      googleStudioManager.updateConfig(preferences.studioConfig);
    }
  }, [preferences.studioConfig]);

  // Kimi Background Optimization Effect
  useEffect(() => {
    if (preferences.neuralCore === "Kimi" && preferences.autoCodeMode) {
      const interval = setInterval(() => {
        const tasks = [
          "Optimizing neural weights...",
          "Refactoring logic clusters...",
          "Kernel stabilization active",
          "Kimi buffer check: OK",
          "Applying dynamic code patches"
        ];
        const randomTask = tasks[Math.floor(Math.random() * tasks.length)];
        
        // Only show if nothing else is happening
        if (activity.type === "idle") {
          setActivity({ type: "coding", detail: randomTask });
          setTimeout(() => setActivity({ type: "idle", detail: "" }), 3000);
        }
      }, 15000);
      return () => clearInterval(interval);
    }
  }, [preferences.neuralCore, preferences.autoCodeMode, activity.type]);
  const [showSettings, setShowSettings] = useState(false);
  const [isLiveCustomizerOpen, setIsLiveCustomizerOpen] = useState(false);
  const [isWorkspaceHubOpen, setIsWorkspaceHubOpen] = useState(false);
  const [showGestureTutorial, setShowGestureTutorial] = useState(false);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [isMapsModalOpen, setIsMapsModalOpen] = useState(false);
  const [isYouTubeModalOpen, setIsYouTubeModalOpen] = useState(false);
  const [isBrowserModalOpen, setIsBrowserModalOpen] = useState(false);
  const [isWifiModalOpen, setIsWifiModalOpen] = useState(false);
  const [isSystemMonitorModalOpen, setIsSystemMonitorModalOpen] = useState(false);
  const [showDebugPanel, setShowDebugPanel] = useState(false);
  const [localChats, setLocalChats] = useState<LocalChatThread[]>(() => {
    try {
      const raw = localStorage.getItem("mimi_claude_chats");
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // Auth initialization
  useEffect(() => {
    const unsubscribe = initAuth((currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Load preferences from Firestore
        const userDocRef = doc(db, "users", currentUser.uid);
        getDoc(userDocRef).then((snap) => {
          if (snap.exists()) {
            const remotePrefs = snap.data().preferences || {};
            const savedTheme = localStorage.getItem("mimi_home_theme");
            const resolvedTheme = remotePrefs.homeLayoutMode || savedTheme || "3d";
            localStorage.setItem("mimi_home_theme", String(resolvedTheme));
            setPreferences((prev) => ({
              ...prev,
              ...remotePrefs,
              homeLayoutMode: resolvedTheme,
            }));
          } else {
            // Initialize user doc if it doesn't exist
            setDoc(userDocRef, {
              userId: currentUser.uid,
              preferences: preferences,
              updatedAt: serverTimestamp(),
              createdAt: serverTimestamp() // Added createdAt for completeness
            }).catch(e => handleFirestoreError(e, OperationType.WRITE, `users/${currentUser.uid}`));
          }
        }).catch(e => handleFirestoreError(e, OperationType.GET, `users/${currentUser.uid}`));
      }
    });
    return () => unsubscribe();
  }, []);

  const memoriesRef = useRef<Memory[]>([]);
  const searchHistoryRef = useRef<SearchLog[]>([]);

  useEffect(() => {
    memoriesRef.current = memories;
  }, [memories]);

  useEffect(() => {
    searchHistoryRef.current = searchHistory;
  }, [searchHistory]);

  // Real-time subscribe to memories
  useEffect(() => {
    if (user) {
      const memoriesRef = collection(db, "users", user.uid, "memories");
      const q = query(memoriesRef, orderBy("timestamp", "desc"));
      const unsubscribe = onSnapshot(q, (snap) => {
        const list = snap.docs.map(doc => ({
          id: doc.id,
          fact: doc.data().fact,
          category: doc.data().category || "general",
          timestamp: doc.data().timestamp
        } as Memory));
        setMemories(list);
      }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/memories`));
      return () => unsubscribe();
    } else {
      setMemories([]);
    }
  }, [user]);

  // Real-time subscribe to searches
  useEffect(() => {
    if (user) {
      const searchesRef = collection(db, "users", user.uid, "searches");
      const q = query(searchesRef, orderBy("timestamp", "desc"));
      const unsubscribe = onSnapshot(q, (snap) => {
        const list = snap.docs.map(doc => ({
          id: doc.id,
          query: doc.data().query,
          timestamp: doc.data().timestamp
        } as SearchLog));
        setSearchHistory(list);
      }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/searches`));
      return () => unsubscribe();
    } else {
      setSearchHistory([]);
    }
  }, [user]);

  // Real-time subscribe to voice_logs
  useEffect(() => {
    if (user) {
      const logsRef = collection(db, "users", user.uid, "voice_logs");
      const q = query(logsRef, orderBy("timestamp", "desc"));
      const unsubscribe = onSnapshot(q, (snap) => {
        const list = snap.docs.map(doc => ({
          id: doc.id,
          event: doc.data().event,
          text: doc.data().text,
          duration: doc.data().duration,
          timestamp: doc.data().timestamp
        } as VoiceLog));
        setVoiceLogs(list);
      }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/voice_logs`));
      return () => unsubscribe();
    } else {
      setVoiceLogs([]);
    }
  }, [user]);

  // Real-time subscribe to commands
  useEffect(() => {
    if (user) {
      const logsRef = collection(db, "users", user.uid, "commands");
      const q = query(logsRef, orderBy("timestamp", "desc"));
      const unsubscribe = onSnapshot(q, (snap) => {
        const list = snap.docs.map(doc => ({
          id: doc.id,
          command: doc.data().command,
          response: doc.data().response,
          appName: doc.data().appName || "System",
          status: doc.data().status || "success",
          timestamp: doc.data().timestamp
        } as CommandLog));
        setCommandLogs(list);
      }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/commands`));
      return () => unsubscribe();
    } else {
      setCommandLogs([]);
    }
  }, [user]);

  // Load current conversation when user is logged in
  useEffect(() => {
    if (user) {
      const conversationsRef = collection(db, "users", user.uid, "conversations");
      const q = query(conversationsRef, orderBy("createdAt", "desc"));
      const unsubscribe = onSnapshot(q, (snap) => {
        const convList = snap.docs.map(doc => ({
          id: doc.id,
          userId: doc.data().userId,
          createdAt: doc.data().createdAt,
          lastMessage: doc.data().lastMessage
        } as ConversationLog));
        setConversations(convList);
        
        setCurrentConversationId(prev => {
          if (!prev && convList.length > 0) {
            return convList[0].id;
          }
          return prev;
        });
      }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/conversations`));
      return () => unsubscribe();
    } else {
      setConversations([]);
    }
  }, [user]);

  // Load messages when conversationId changes
  useEffect(() => {
    if (user && currentConversationId) {
      const messagesRef = collection(db, "users", user.uid, "conversations", currentConversationId, "messages");
      const q = query(messagesRef, orderBy("timestamp", "asc"));
      const unsubscribe = onSnapshot(q, (snap) => {
        const loadedMessages = snap.docs.map(doc => ({
          id: doc.id,
          sender: doc.data().sender,
          text: doc.data().text
        } as ChatMessage));
        setMessages(loadedMessages);
      }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${user.uid}/conversations/${currentConversationId}/messages`));
      return () => unsubscribe();
    } else if (!currentConversationId) {
      setMessages([]);
    }
  }, [user, currentConversationId]);

  // Sync preferences to Firestore - Optimized to ignore redundant local updates
  const lastSyncedPrefs = useRef(JSON.stringify(preferences));
  useEffect(() => {
    const prefsString = JSON.stringify(preferences);
    localStorage.setItem("mimi_preferences", prefsString);
    
    if (user && prefsString !== lastSyncedPrefs.current) {
      lastSyncedPrefs.current = prefsString;
      const userDocRef = doc(db, "users", user.uid);
      try {
        setDoc(userDocRef, { 
          userId: user.uid,
          preferences,
          updatedAt: serverTimestamp() 
        }, { merge: true }).catch(error => {
          selfRepairer.addLog("error", "Firestore Sync Failed", String(error));
        });
      } catch (error) {
        console.error("Firestore sync error", error);
        selfRepairer.addLog("error", "Firestore Sync Failed", String(error));
        // Trigger a silent repair attempt if it's a known connection issue
        if (String(error).includes("network") || String(error).includes("offline")) {
          selfRepairer.addLog("repair", "Network Instability Detected", "Attempting to stabilize neural link...");
        }
      }
    }
  }, [preferences, user]);

  const handleSavePreferences = (newPrefs: any) => {
    setPreferences(newPrefs);
    localStorage.setItem("mimi_preferences", JSON.stringify(newPrefs));
    if (newPrefs?.homeLayoutMode) {
      localStorage.setItem("mimi_home_theme", String(newPrefs.homeLayoutMode));
    }
    if (user) {
      const userDocRef = doc(db, "users", user.uid);
      setDoc(userDocRef, { preferences: newPrefs, updatedAt: serverTimestamp() }, { merge: true })
        .catch(e => handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`));
    }
  };

  const handleClearHistory = async () => {
    setMessages([]);
    resetMimiSession();
    localStorage.removeItem("mimi_chat_history");
    setCurrentConversationId(null);
  };

  const handleSelectPastConversation = (id: string) => {
    setCurrentConversationId(id);
    if (!user) {
      const found = localChats.find((c) => c.id === id);
      if (found) setMessages(found.messages || []);
    }
    selfRepairer.addLog("info", "Session Changed", "Retrieved and initialized past chat session.");
  };

  const handleStartFreshConversation = async () => {
    resetMimiSession();
    if (!user) {
      const newLocalId = `local-${Date.now()}`;
      setCurrentConversationId(newLocalId);
      setMessages([]);
      return;
    }
    try {
      const newId = await historyMemoryService.startNewConversation(user.uid);
      if (newId) {
        setCurrentConversationId(newId);
        setMessages([]);
        selfRepairer.addLog("info", "Fresh Session Spawned", "Spinning up a clean neural slate with Mimi.");
      }
    } catch (err) {
      console.error("Start new conversation fail", err);
    }
  };

  const handleDeletePastConversation = async (id: string) => {
    if (!id) return;
    setLocalChats((prev) => {
      const next = prev.filter((c) => c.id !== id);
      localStorage.setItem("mimi_claude_chats", JSON.stringify(next));
      return next;
    });
    if (currentConversationId === id) {
      setCurrentConversationId(null);
      setMessages([]);
    }
    if (!user) return;
    try {
      await historyMemoryService.deleteConversation(user.uid, id);
      selfRepairer.addLog("info", "Session Pruned", "Removed archived interaction records safely.");
    } catch (err) {
      console.error("Delete conversation fail", err);
    }
  };

  const handleToggleStarConversation = (id: string) => {
    const existing: string[] = Array.isArray(preferences.starredChatIds)
      ? preferences.starredChatIds
      : [];
    const next = existing.includes(id)
      ? existing.filter((x) => x !== id)
      : [...existing, id];
    updatePreference("starredChatIds", next);
  };

  const handleAddManualMemory = async (fact: string) => {
    if (!user || !fact.trim()) return;
    try {
      await historyMemoryService.saveMemory(user.uid, fact.trim(), "manual");
      selfRepairer.addLog("info", "Synapse Bonded", "Logged new consolidated biographical memory.");
    } catch (err) {
      console.error("Add manual memory fail", err);
    }
  };

  const handleDeletePastMemory = async (id: string) => {
    if (!user || !id) return;
    try {
      await historyMemoryService.deleteMemory(user.uid, id);
      selfRepairer.addLog("info", "Synapse Severed", "Forgot individual learned fact from long-term memory.");
    } catch (err) {
      console.error("Delete memory fail", err);
    }
  };

  const handleClearSearchLog = async () => {
    if (!user) return;
    try {
      await historyMemoryService.clearSearches(user.uid);
      selfRepairer.addLog("info", "Search Trail Cleaned", "Purged search history indexes completely.");
    } catch (err) {
      console.error("Clear searches fail", err);
    }
  };

  const tryExtractMemory = async (userId: string, userText: string, mimiText: string) => {
    if (!userId || !userText?.trim() || !mimiText?.trim()) return;
    try {
      const prompt = `You are an advanced memory processing subsystem for a highly witty AI companion named Mimi. 
Analyze the following single exchange between the User and Mimi. 
If the User has shared any notable personal facts, biographical details, habits, hobbies, preferences, named family members/relationships, or persistent facts about their lifestyle/work, extract them into short, clear, third-person declarative facts (e.g. "The user likes standard milk tea", "The user is studying Python coding").
Only extract persistent, durable, and factual details about the user that Mimi should retain permanently to recall and understand them better.
Do NOT extract transient mood states, short reactions to a joke, greetings, or generic conversational statements.
Return a plain, valid JSON array of strings containing the facts. Example: ["The user is an artist"]. If no personal, biographical facts are mentioned, return exactly an empty JSON array: [].
Do not wrap your output in markdown formatting or write "json" headers, return ONLY raw JSON text.

Exchange:
User: "${userText}"
Mimi: "${mimiText}"`;

      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, model: "gemini-4-hydrogen" })
      });

      if (response.ok) {
        const data = await response.json();
        const textClean = (data.text || "").replace(/```json|```/g, "").trim();
        if (textClean && textClean !== "[]") {
          try {
            const extracted = JSON.parse(textClean);
            if (Array.isArray(extracted)) {
              for (const fact of extracted) {
                if (fact && fact.trim()) {
                  await historyMemoryService.saveMemory(userId, fact.trim(), "auto-extracted");
                }
              }
            }
          } catch (pe) {
            console.warn("Failed to parse automatic memory extraction:", textClean, pe);
          }
        }
      }
    } catch (e) {
      console.error("Automatic memory learning skipped:", e);
    }
  };

  const handleLoginBasic = async () => {
    try {
      const u = await loginWithGoogle();
      if (u) {
        selfRepairer.addLog("info", "User Authentication", "Connected via Google Workspace basic credentials.");
        setAuthErrorDetails(null);
      }
    } catch (e: any) {
      console.error("Basic Login failed", e);
      setAuthErrorDetails({
        code: e.code || "auth/handshake-failed",
        message: e.message || String(e),
        rawError: e,
        flowType: "standard"
      });
      selfRepairer.addLog("warning", "Authentication Interrupted", `Google Login failed: ${e.message}`);
      
      // Attempt silent guest fallback behind the scenes to keep app fully robust
      try {
        await loginAnonymously();
      } catch (anonErr) {
        console.error("Guest fallback failed", anonErr);
      }
    }
  };

  const handleLoginWorkspace = async () => {
    try {
      const u = await loginWithGoogleWorkspace();
      if (u) {
        selfRepairer.addLog("info", "User Authentication", "Connected via Google Workspace integrations.");
        setAuthErrorDetails(null);
        const refreshedToken = getCachedAccessToken();
        setAccessToken(refreshedToken);
      }
    } catch (e: any) {
      console.error("Workspace Login failed", e);
      setAuthErrorDetails({
        code: e.code || "auth/handshake-failed",
        message: e.message || String(e),
        rawError: e,
        flowType: "workspace"
      });
      selfRepairer.addLog("warning", "Authentication Interrupted", `Workspace Scope Authorization failed: ${e.message}`);
    }
  };

  const handleLogin = async () => {
    await handleLoginBasic();
  };

  const handleHardReboot = () => {
    // Force reset everything
    if (liveSessionRef.current) {
      liveSessionRef.current.stop();
      liveSessionRef.current = null;
    }
    if (cameraStream) cameraStream.getTracks().forEach(t => t.stop());
    if (screenStream) screenStream.getTracks().forEach(t => t.stop());
    
    setCameraStream(null);
    setScreenStream(null);
    setIsSessionActive(false);
    setAppState("idle");
    setErrorToast("System Neural Link Rebooting...");
    
    setTimeout(() => {
       window.location.reload();
    }, 1000);
  };

  const handleLogout = async () => {
    try {
      await logout();
      setMessages([]);
      setCurrentConversationId(null);
    } catch (e) {
      console.error("Logout failed", e);
    }
  };

  const saveMessageLocally = async (sender: "user" | "mimi", text: string) => {
    // Periodic automatic profile updates if user mentions things
    if (sender === "user") {
      const nameMatch = text.match(/(?:mera naam|my name is|amr naam)\s+([a-zA-Z\s]+)(?:hai|bato)?/i);
      if (nameMatch) {
        const name = nameMatch[1].trim();
        setPreferences(prev => ({ ...prev, name }));
      }
      
      // Auto save query to search log if it has query elements
      if (user) {
        const isSearch = /(?:search|find|who|what|where|how|why|which|query|kothay|kee|keno|kar|kemne|khujo|scra|google)/i.test(text);
        if (isSearch && text.trim().split(/\s+/).length >= 2) {
          historyMemoryService.saveSearch(user.uid, text.trim()).catch(err => {
            console.error("Save search log failed:", err);
          });
        }
      }
    }

    if (user) {
      try {
        let conversationId = currentConversationId;
        if (!conversationId) {
          const conversationsRef = collection(db, "users", user.uid, "conversations");
          const newConv = await addDoc(conversationsRef, {
            userId: user.uid,
            createdAt: serverTimestamp(),
            lastMessage: text
          });
          conversationId = newConv.id;
          setCurrentConversationId(conversationId);
        } else {
          // Keep conversation snippet updated
          const convDocRef = doc(db, "users", user.uid, "conversations", conversationId);
          setDoc(convDocRef, { lastMessage: text }, { merge: true }).catch(err => {
            console.error("Update conversation snippet failed", err);
          });
        }

        const messagesRef = collection(db, "users", user.uid, "conversations", conversationId, "messages");
        await addDoc(messagesRef, {
          sender,
          text,
          timestamp: serverTimestamp()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}/conversations/...`);
      }
    }
  };

  const [appState, setAppState] = useState<AppState>("idle");
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("mimi_chat_history");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse chat history", e);
      }
    }
    return [];
  });
  const messagesRef = useRef(messages);

  const [isJoking, setIsJoking] = useState(false);
  const [isAngry, setIsAngry] = useState(false);
  const [isClarityMode, setIsClarityMode] = useState(true);

  useEffect(() => {
    messagesRef.current = messages;
    const lastMessage = messages[messages.length - 1];
    if (lastMessage && lastMessage.sender === "mimi") {
      const text = lastMessage.text.toLowerCase();
      // Simple keyword detection
      const jokingKeywords = ["lol", "haha", "joke", "masti", "teasing", "ehe"];
      const angryKeywords = ["angry", "bad", "no", "hate", "ugh", "chup", "boro"];
      
      setIsJoking(jokingKeywords.some(k => text.includes(k)));
      setIsAngry(angryKeywords.some(k => text.includes(k)));
      
      // Auto-reset after a bit
      setTimeout(() => {
         setIsJoking(false);
         setIsAngry(false);
      }, 5000);
    }
  }, [messages]);

  useEffect(() => {
    messagesRef.current = messages;
    localStorage.setItem("mimi_chat_history", JSON.stringify(messages));
    if (messages.length > 0 && !user) {
      const firstUser = messages.find((m) => m.sender === "user");
      const title = (firstUser?.text || messages[0].text || "New chat").slice(0, 48);
      const threadId = currentConversationId || "local-default";
      if (!currentConversationId) {
        setCurrentConversationId(threadId);
      }
      setLocalChats((prev) => {
        const idx = prev.findIndex((c) => c.id === threadId);
        const updatedThread: LocalChatThread = {
          id: threadId,
          title,
          updatedAtMs: Date.now(),
          messages,
        };
        const next = idx >= 0
          ? prev.map((c, i) => (i === idx ? updatedThread : c))
          : [updatedThread, ...prev];
        const trimmed = next.slice(0, 40);
        localStorage.setItem("mimi_claude_chats", JSON.stringify(trimmed));
        return trimmed;
      });
    }
  }, [messages, user, currentConversationId]);

  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    setIsMuted(preferences.isMuted ?? false);
  }, [preferences.isMuted]);

  useEffect(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.setMuted(isMuted);
    }
  }, [isMuted]);

  const [showTextInput, setShowTextInput] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [isCameraMenuOpen, setIsCameraMenuOpen] = useState(false);
  const [isSensingHubOpen, setIsSensingHubOpen] = useState(false);
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [serverConnectionStatus, setServerConnectionStatus] = useState<LiveConnectionStatus>("connecting");
  const [liveConnectionStatus, setLiveConnectionStatus] = useState<LiveConnectionStatus>("disconnected");
  const [videoPreviewSize, setVideoPreviewSize] = useState<"small" | "large" | "full">("small");
  const [videoFitMode, setVideoFitMode] = useState<"cover" | "contain">("cover");
  const [batteryLevel, setBatteryLevel] = useState<number>(100);
  const [batteryCharging, setBatteryCharging] = useState<boolean>(false);

  useEffect(() => {
    let batteryInstance: any = null;

    const handleLevelChange = (e: any) => {
      setBatteryLevel(Math.round(e.target.level * 100));
    };

    const handleChargingChange = (e: any) => {
      setBatteryCharging(e.target.charging);
    };

    const initBattery = async () => {
      if (typeof navigator !== "undefined" && "getBattery" in navigator) {
        try {
          const battery = await (navigator as any).getBattery();
          batteryInstance = battery;
          setBatteryLevel(Math.round(battery.level * 100));
          setBatteryCharging(battery.charging);

          battery.addEventListener("levelchange", handleLevelChange);
          battery.addEventListener("chargingchange", handleChargingChange);
        } catch (err) {
          console.warn("Battery API error, falling back to simulated status", err);
          simulateBattery();
        }
      } else {
        simulateBattery();
      }
    };

    function simulateBattery() {
      setBatteryLevel(87);
      setBatteryCharging(false);
    }

    initBattery();

    return () => {
      if (batteryInstance) {
        batteryInstance.removeEventListener("levelchange", handleLevelChange);
        batteryInstance.removeEventListener("chargingchange", handleChargingChange);
      }
    };
  }, []);

  const refreshVideoDevices = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
        return;
      }
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = devices.filter(device => device.kind === "videoinput");
      setVideoDevices(videoInputs);
    } catch (e) {
      console.warn("Failed to enumerate video devices:", e);
    }
  };

  useEffect(() => {
    if (cameraStream || isCameraMenuOpen) {
      refreshVideoDevices();
    }
  }, [cameraStream, isCameraMenuOpen]);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      // Sync queue if needed
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [isGestureControlActive, setIsGestureControlActive] = useState(false);
  const [mousePos, setMousePos] = useState({ x: typeof window !== 'undefined' ? window.innerWidth / 2 : 500, y: typeof window !== 'undefined' ? window.innerHeight / 2 : 400 });

  useEffect(() => {
    if (!screenStream) return;
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, [screenStream]);

  const [errorToast, setErrorToast] = useState<string | null>(null);

  const [isPhotoHubOpen, setIsPhotoHubOpen] = useState(false);
  const [isRealmeHubOpen, setIsRealmeHubOpen] = useState(false);
  const [activeCommandPhotoCategory, setActiveCommandPhotoCategory] = useState<string | null>(null);

  const [isLiveSyncControllerOpen, setIsLiveSyncControllerOpen] = useState(false);
  const [isGmailHubOpen, setIsGmailHubOpen] = useState(false);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [authErrorDetails, setAuthErrorDetails] = useState<{
    code: string;
    message: string;
    rawError?: any;
    flowType?: "standard" | "workspace";
  } | null>(null);

  // Read accessToken from cache on initialization and on login
  useEffect(() => {
    const token = getCachedAccessToken();
    if (token) {
      setAccessToken(token);
    }
  }, [user]);

  const checkAndTriggerGmailHub = useCallback((text: string) => {
    const lowerTranscript = text.toLowerCase().trim();
    let shouldTriggerGmail = false;

    if (
      lowerTranscript.includes("gmail") || 
      lowerTranscript.includes("email") || 
      lowerTranscript.includes("inbox") || 
      lowerTranscript.includes("জিমেইল") || 
      lowerTranscript.includes("ইমেইল") || 
      lowerTranscript.includes("মেইল") || 
      lowerTranscript.includes("mail") || 
      lowerTranscript.includes("compose") || 
      lowerTranscript.includes("পাঠাও") || 
      lowerTranscript.includes("send email")
    ) {
      shouldTriggerGmail = true;
    }

    if (shouldTriggerGmail) {
      setIsGmailHubOpen(true);
    }
  }, []);

  const checkAndTriggerPhotoHub = useCallback((text: string) => {
    const lowerTranscript = text.toLowerCase().trim();
    let detectedCategory: string | null = null;
    let shouldTriggerPhotoHub = false;

    if (
      lowerTranscript.includes("বিড়াল") || 
      lowerTranscript.includes("biral") || 
      lowerTranscript.includes("cat")
    ) {
      detectedCategory = "cat";
      shouldTriggerPhotoHub = true;
    } else if (
      lowerTranscript.includes("nature") || 
      lowerTranscript.includes("beach") || 
      lowerTranscript.includes("mountain") || 
      lowerTranscript.includes("পাহাড়") || 
      lowerTranscript.includes("সমুদ্র")
    ) {
      detectedCategory = "nature";
      shouldTriggerPhotoHub = true;
    } else if (
      lowerTranscript.includes("family") || 
      lowerTranscript.includes("people") || 
      lowerTranscript.includes("পরিবার")
    ) {
      detectedCategory = "people";
      shouldTriggerPhotoHub = true;
    } else if (
      lowerTranscript.includes("photo") || 
      lowerTranscript.includes("album") || 
      lowerTranscript.includes("gallery") || 
      lowerTranscript.includes("ফটো") || 
      lowerTranscript.includes("ছবি") ||
      lowerTranscript.includes("গুগল ফটো") ||
      lowerTranscript.includes("google photo")
    ) {
      detectedCategory = "preset";
      shouldTriggerPhotoHub = true;
    }

    if (shouldTriggerPhotoHub) {
      setIsPhotoHubOpen(true);
      if (detectedCategory) {
        setActiveCommandPhotoCategory(detectedCategory);
        setTimeout(() => {
          setActiveCommandPhotoCategory(null);
        }, 150);
      }
    }
  }, []);

  useEffect(() => {
    if (errorToast) {
      const timer = setTimeout(() => setErrorToast(null), 8000); // Longer duration for reading
      return () => clearTimeout(timer);
    }
  }, [errorToast]);

  const liveSessionRef = useRef<LiveSession | null>(null);
  const [interimSpeech, setInterimSpeech] = useState("");
  const [isLiveReconnecting, setIsLiveReconnecting] = useState(false);
  const [liveDebugInfo, setLiveDebugInfo] = useState<LiveDebugTelemetry>({
    wsStatus: "disconnected",
    micActive: false,
    chunksSent: 0,
    chunksReceived: 0,
    state: "idle",
    lastError: null,
    reconnectAttempt: 0,
    maxReconnectAttempts: 5,
  });
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (videoPreviewRef.current) {
      videoPreviewRef.current.srcObject = cameraStream || screenStream;
    }
  }, [cameraStream, screenStream]);

  const getCameraStream = async (mode: "user" | "environment", deviceId?: string) => {
    // We try to formulate three-phase constraints to be ultra-resilient on mobile/iframes
    const baseConstraints: Record<string, any> = {
      width: { ideal: 1280 },
      height: { ideal: 720 },
    };

    // Phase 1: Try exact device ID or ideal facing mode
    let constraints: MediaStreamConstraints = {
      video: deviceId 
        ? { ...baseConstraints, deviceId: { exact: deviceId } }
        : { ...baseConstraints, facingMode: { ideal: mode } }
    };

    try {
      console.log("Attempting camera access with constraints:", JSON.stringify(constraints));
      return await navigator.mediaDevices.getUserMedia(constraints);
    } catch (err1) {
      console.warn("Camera constraint Phase 1 failed, attempting Phase 2...", err1);
      
      // Phase 2: Try standard string facing mode
      try {
        const fallbackConstraints: MediaStreamConstraints = {
          video: { facingMode: mode }
        };
        console.log("Attempting Phase 2 constraints:", JSON.stringify(fallbackConstraints));
        return await navigator.mediaDevices.getUserMedia(fallbackConstraints);
      } catch (err2) {
        console.warn("Camera constraint Phase 2 failed, attempting Phase 3 (raw video)...", err2);
        
        // Phase 3: Absolute fallback (essential for some iframe permissions and single-camera phones)
        try {
          return await navigator.mediaDevices.getUserMedia({ video: true });
        } catch (err3) {
          console.error("All camera stream attempts failed comprehensively:", err3);
          throw err3;
        }
      }
    }
  };

  const toggleCamera = async () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
      if (liveSessionRef.current) {
        liveSessionRef.current.setVideoStream(screenStream);
      }
    } else {
      try {
        if (screenStream) {
          screenStream.getTracks().forEach(t => t.stop());
          setScreenStream(null);
        }
        const stream = await getCameraStream(facingMode, selectedDeviceId);
        setCameraStream(stream);
        if (liveSessionRef.current) {
          liveSessionRef.current.setVideoStream(stream);
        }
      } catch (e) {
        console.error("Failed to start camera", e);
      }
    }
  };

  const switchCamera = async () => {
    const newMode = facingMode === "user" ? "environment" : "user";
    setFacingMode(newMode);
    setSelectedDeviceId(""); // Clear selected device ID to auto-negotiate correct lens orientation
    
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      try {
        const stream = await getCameraStream(newMode);
        setCameraStream(stream);
        if (liveSessionRef.current) {
          liveSessionRef.current.setVideoStream(stream);
        }
      } catch (e) {
        console.error("Failed to switch camera", e);
      }
    }
  };

  const selectCameraDevice = async (deviceId: string) => {
    setSelectedDeviceId(deviceId);
    
    // Auto-detect estimated mode based on friendly name
    const selectedDev = videoDevices.find(d => d.deviceId === deviceId);
    let estimatedMode: "user" | "environment" = facingMode;
    if (selectedDev && selectedDev.label) {
      const labelLower = selectedDev.label.toLowerCase();
      if (labelLower.includes("back") || labelLower.includes("rear") || labelLower.includes("environment")) {
        estimatedMode = "environment";
      } else if (labelLower.includes("front") || labelLower.includes("user") || labelLower.includes("selfie")) {
        estimatedMode = "user";
      }
    }
    setFacingMode(estimatedMode);
    
    if (cameraStream) {
      cameraStream.getTracks().forEach(t => t.stop());
      try {
        const stream = await getCameraStream(estimatedMode, deviceId);
        setCameraStream(stream);
        if (liveSessionRef.current) {
          liveSessionRef.current.setVideoStream(stream);
        }
      } catch (e) {
        console.error("Failed to switch camera to selected device ID", e);
      }
    }
  };

  const toggleScreen = async () => {
    if (screenStream) {
      screenStream.getTracks().forEach(t => t.stop());
      setScreenStream(null);
      if (liveSessionRef.current) {
         liveSessionRef.current.setVideoStream(cameraStream);
      }
    } else {
      try {
        if (cameraStream) {
          cameraStream.getTracks().forEach(t => t.stop());
          setCameraStream(null);
        }
        if (!navigator.mediaDevices?.getDisplayMedia) {
          alert("Screen sharing is not supported in this browser or environment. Try opening the app in a new tab.");
          return;
        }
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        setScreenStream(stream);
        if (liveSessionRef.current) {
          liveSessionRef.current.setVideoStream(stream);
        }
      } catch (e) {
        console.error("Failed to start screen share", e);
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, appState]);

  const handleTextCommand = useCallback(async (finalTranscript: string, attachments?: ChatAttachment[]) => {
    if (!finalTranscript.trim() && (!attachments || attachments.length === 0)) {
      setAppState("idle");
      return;
    }

    // Intercept photo commands and display Mimi Photo Album Space
    checkAndTriggerPhotoHub(finalTranscript);
    checkAndTriggerGmailHub(finalTranscript);

    const msgId = Date.now().toString();
    const msg: ChatMessage = {
      id: msgId,
      sender: "user",
      text: finalTranscript,
      attachments: attachments?.map((a) => ({
        name: a.name,
        mimeType: a.mimeType,
        previewUrl: a.data && a.mimeType.startsWith("image/") ? `data:${a.mimeType};base64,${a.data}` : undefined,
      })),
    };
    setMessages((prev) => [...prev, msg]);
    saveMessageLocally("user", finalTranscript);
    
    if (!navigator.onLine) {
      setAppState("processing");
      setTimeout(() => {
        const offlineReply = "Dada/Didi, amar logic network ektu samay nibe, ami ekhon satellite mode-e achi. Internet ashlei tomar ei kotha ami mathay rakhbo! (Offline Mode Active)";
        const chatMsg = { id: Date.now().toString() + "-off", sender: "mimi" as const, text: offlineReply };
        setMessages((prev) => [...prev, chatMsg]);
        setAppState("idle");
        saveMessageLocally("mimi", offlineReply);
      }, 1000);
      return;
    }

    // If Live BiDi WebSocket session is connected and no binary attachments, route text through it cleanly
    if (
      isSessionActive &&
      liveSessionRef.current?.isLiveBiDiActive() &&
      (!attachments || attachments.length === 0)
    ) {
      liveSessionRef.current.sendText(finalTranscript);
      return;
    }

    setAppState("processing");
    selfRepairer.setActiveTask("searching", `Analyzing: "${finalTranscript.substring(0, 50)}..."`);

    // 1. Check for browser commands
    const searchSitesList = [
      ...(preferences?.customSearchSites || []),
      ...(preferences?.serverLinks || [])
        .filter((l: any) => l.type === "search" && l.enabled)
        .map((l: any) => ({ id: l.id, name: l.name, url: l.url }))
    ];
    const commandResult = processCommand(finalTranscript, searchSitesList);

    let responseText = "";

    if (commandResult.appName === "System Upgrade") {
      setAppState("upgrading");
      return;
    }

    if (commandResult.isBrowserAction && (!attachments || attachments.length === 0)) {
      selfRepairer.setActiveTask("coding", "Executing browser automation command...");
      responseText = commandResult.action;
      const browserMsg: ChatMessage = { 
        id: Date.now().toString() + "-z", 
        sender: "mimi", 
        text: responseText,
        url: commandResult.url,
        urlType: commandResult.urlType,
        query: commandResult.query,
        appName: commandResult.appName,
        whatsappRecipient: commandResult.whatsappRecipient,
        whatsappPhone: commandResult.whatsappPhone,
        whatsappMessage: commandResult.whatsappMessage
      };
      setMessages((prev) => [...prev, browserMsg]);
      saveMessageLocally("mimi", responseText);
      logCommandExecution(finalTranscript, responseText, commandResult.appName, "success");
      
      if (!isMuted) {
        setAppState("speaking");
        const audioBase64 = await getMimiAudio(responseText, preferences.voiceId, preferences.voiceProfile);
        if (audioBase64) {
          logVoiceActivity("Mimi Spoke System Command Response", responseText);
          await playPCM(audioBase64);
        }
      }

      setAppState(liveSessionRef.current?.isActive ? "listening" : "idle");

      if (commandResult.url && commandResult.urlType !== "youtube" && commandResult.urlType !== "google") {
        try {
          const newWindow = window.open(commandResult.url, "_blank");
          if (!newWindow) {
            window.location.href = commandResult.url;
          }
          selfRepairer.addLog("info", "Browser Command Executed", `Opened: ${commandResult.url}`);
        } catch (e) {
          setErrorToast("Browser control blocked. Please allow popups.");
          selfRepairer.addLog("error", "Browser Action Blocked", String(e));
        }
      }
    } else {
      try {
        selfRepairer.setActiveTask("thinking", `Synthesizing response with ${preferences.neuralCore || "Gemini"}...`);
        responseText = await getIntelligentResponse(
          finalTranscript, 
          preferences.neuralCore || "Gemini",
          messagesRef.current,
          preferences.name || undefined,
          {
            ...preferences,
            memories: memoriesRef.current,
            recentSearches: searchHistoryRef.current.slice(0, 5)
          },
          attachments
        );
        const chatMsg: ChatMessage = { id: Date.now().toString() + "-z", sender: "mimi", text: responseText };
        setMessages((prev) => [...prev, chatMsg]);
        saveMessageLocally("mimi", responseText);
        logCommandExecution(finalTranscript, responseText, preferences.neuralCore || "Mimi Core", "success");

        const isErrorReply =
          responseText.startsWith("Rate limit / quota reached") ||
          responseText.startsWith("Gemini API key error") ||
          responseText.startsWith("Gemini request failed") ||
          responseText.startsWith("Core server is temporarily unavailable") ||
          responseText.startsWith("Unable to reach the Mimi server") ||
          responseText.startsWith("Mimi server is restarting") ||
          responseText.startsWith("That request was blocked by safety filters");

        if (isErrorReply) {
          setErrorToast(responseText);
        } else if (user && finalTranscript.trim().length >= 10) {
          tryExtractMemory(user.uid, finalTranscript, responseText);
        }
        selfRepairer.clearActiveTask();
        
        if (!isMuted && preferences.homeLayoutMode !== "claude" && !isErrorReply) {
          setAppState("speaking");
          const audioBase64 = await getMimiAudio(responseText, preferences.voiceId, preferences.voiceProfile);
          if (audioBase64) {
            logVoiceActivity("Mimi Responded with Voice", responseText);
            await playPCM(audioBase64);
          } else if (isSessionActive && typeof window !== "undefined" && "speechSynthesis" in window) {
            await new Promise<void>((resolve) => {
              const utter = new SpeechSynthesisUtterance(responseText.slice(0, 800));
              utter.onend = () => resolve();
              utter.onerror = () => resolve();
              window.speechSynthesis.speak(utter);
            });
          }
        }
      } catch (err) {
        console.error("Neural Error:", err);
        logCommandExecution(finalTranscript, `Error: ${String(err)}`, preferences.neuralCore || "Mimi Core", "failed");
        selfRepairer.addLog("error", "Neural Core Failure", String(err));
        setErrorToast("Neural pathway logic failure. Resetting core to Gemini...");
        setPreferences(prev => ({ ...prev, neuralCore: "Gemini" }));
        resetMimiSession();
      }
      setAppState(liveSessionRef.current?.isActive ? "listening" : "idle");
    }
  }, [isMuted, isSessionActive, preferences, user]);

  const handleTextCommandRef = useRef(handleTextCommand);
  useEffect(() => {
    handleTextCommandRef.current = handleTextCommand;
  }, [handleTextCommand]);

  const handleRegenerateMessage = useCallback(async (assistantMessageId: string) => {
    const idx = messagesRef.current.findIndex((m) => m.id === assistantMessageId);
    if (idx === -1) return;
    let promptText = "";
    for (let i = idx - 1; i >= 0; i--) {
      if (messagesRef.current[i].sender === "user") {
        promptText = messagesRef.current[i].text;
        break;
      }
    }
    if (!promptText.trim()) return;
    setMessages((prev) => prev.filter((m) => m.id !== assistantMessageId));
    setAppState("processing");
    try {
      const responseText = await getIntelligentResponse(
        promptText,
        preferences.neuralCore || "Gemini",
        messagesRef.current.slice(0, idx),
        preferences.name || undefined,
        {
          ...preferences,
          memories: memoriesRef.current,
          recentSearches: searchHistoryRef.current.slice(0, 5),
        }
      );
      setMessages((prev) => [
        ...prev,
        { id: `${Date.now()}-regen`, sender: "mimi", text: responseText },
      ]);
      saveMessageLocally("mimi", responseText);
    } catch (err) {
      setErrorToast(`Regenerate failed: ${String(err)}`);
    } finally {
      setAppState("idle");
    }
  }, [preferences]);

  const handleSpeakText = useCallback(async (text: string) => {
    const clean = text.replace(/```[\s\S]*?```/g, "code block").replace(/[*`#]/g, "").trim();
    if (!clean) return;
    setAppState("speaking");
    try {
      const audioBase64 = await getMimiAudio(clean.slice(0, 1200), preferences.voiceId, preferences.voiceProfile);
      if (audioBase64) {
        await playPCM(audioBase64);
      } else if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
        await new Promise<void>((resolve) => {
          const utter = new SpeechSynthesisUtterance(clean.slice(0, 1200));
          utter.onend = () => resolve();
          utter.onerror = () => resolve();
          window.speechSynthesis.speak(utter);
        });
      }
    } finally {
      setAppState((prev) => (prev === "speaking" ? "idle" : prev));
    }
  }, [preferences.voiceId, preferences.voiceProfile]);

  const handleStopSpeaking = useCallback(() => {
    stopPlayPCM();
    if (liveSessionRef.current) {
      liveSessionRef.current.audioStreamer.stop();
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setAppState(liveSessionRef.current?.isActive ? "listening" : "idle");
  }, []);

  useEffect(() => {
    return () => {
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
      }
    };
  }, []);

  const toggleListening = async (forceStart?: boolean) => {
    const shouldStop = isSessionActive && forceStart !== true;
    if (shouldStop) {
      logVoiceActivity("Voice session ended");
      setIsSessionActive(false);
      setInterimSpeech("");
      setIsLiveReconnecting(false);
      if (cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        setCameraStream(null);
      }
      if (screenStream) {
        screenStream.getTracks().forEach(t => t.stop());
        setScreenStream(null);
      }
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
        liveSessionRef.current = null;
      }
      setLiveConnectionStatus("disconnected");
      setAppState("idle");
      resetMimiSession();
    } else {
      try {
        logVoiceActivity("Voice session started");
        setIsSessionActive(true);
        setLiveConnectionStatus("connecting");
        resetMimiSession();
        
        const session = new LiveSession();
        session.setMuted(isMuted);
        liveSessionRef.current = session;
        
        if (cameraStream) session.setVideoStream(cameraStream);
        if (screenStream) session.setVideoStream(screenStream);
        
        session.onStateChange = (state) => {
          if (state === "connecting") setAppState("idle");
          else if (state === "listening") setAppState("listening");
          else if (state === "thinking") setAppState("processing");
          else if (state === "speaking") setAppState("speaking");
        };

        session.onReconnecting = (reconnecting) => {
          setIsLiveReconnecting(reconnecting);
          setLiveConnectionStatus(reconnecting ? "connecting" : "connected");
        };

        session.onDebugUpdate = (info) => {
          setLiveDebugInfo(info);
          if (info.wsStatus === "open") setLiveConnectionStatus("connected");
          else if (info.wsStatus === "connecting" || info.wsStatus === "reconnecting") {
            setLiveConnectionStatus("connecting");
          } else {
            setLiveConnectionStatus("disconnected");
          }
        };

        session.onInterimSpeech = (text) => {
          setInterimSpeech(text);
        };

        session.onSpeechInput = async (text) => {
          setInterimSpeech("");
          const trimmed = text.trim();
          if (!trimmed) return;
          logVoiceActivity("User vocalised speech (fallback)", trimmed);
          await handleTextCommandRef.current(trimmed);
        };
        
        session.onMessage = (sender, text) => {
          const normalizedSender = sender === "ultron" ? "mimi" : sender;
          if (normalizedSender === "user") {
            setInterimSpeech("");
            logVoiceActivity("User vocalised speech", text);
            checkAndTriggerPhotoHub(text);
            checkAndTriggerGmailHub(text);

            const searchSitesList = [
              ...(preferences?.customSearchSites || []),
              ...(preferences?.serverLinks || [])
                .filter((l: any) => l.type === "search" && l.enabled)
                .map((l: any) => ({ id: l.id, name: l.name, url: l.url }))
            ];
            const cmdRes = processCommand(text, searchSitesList);
            
            if (cmdRes.appName === "System Upgrade") {
              setAppState("upgrading");
              return;
            }

            if (cmdRes.isBrowserAction) {
              const speakText = cmdRes.action;
              logCommandExecution(text, speakText, cmdRes.appName, "success");
              setTimeout(() => {
                setMessages((prev) => [
                  ...prev,
                  {
                    id: Date.now().toString() + "-livecmd",
                    sender: "mimi" as const,
                    text: speakText,
                    url: cmdRes.url,
                    urlType: cmdRes.urlType,
                    query: cmdRes.query,
                    appName: cmdRes.appName,
                    whatsappRecipient: cmdRes.whatsappRecipient,
                    whatsappPhone: cmdRes.whatsappPhone,
                    whatsappMessage: cmdRes.whatsappMessage
                  }
                ]);
                saveMessageLocally("mimi", speakText);
              }, 400);

              if (cmdRes.url && cmdRes.urlType !== "youtube" && cmdRes.urlType !== "google") {
                setTimeout(() => {
                  try {
                    const newWindow = window.open(cmdRes.url, "_blank");
                    if (!newWindow) {
                      window.location.href = cmdRes.url;
                    }
                  } catch (e) {}
                }, 1500);
              }
            }
          } else {
            logVoiceActivity("Mimi Responded with Voice", text);
          }
          setMessages((prev) => {
            const msg: ChatMessage = { id: Date.now().toString() + "-" + normalizedSender, sender: normalizedSender, text };
            saveMessageLocally(normalizedSender, text);
            return [...prev, msg];
          });
        };
        
        session.onCommand = (url) => {
          setTimeout(() => {
            try {
              const newWindow = window.open(url, "_blank");
              if (!newWindow) {
                window.location.href = url;
              }
            } catch (e) {}
          }, 1000);
        };

        session.onSessionEnd = () => {
          setIsSessionActive(false);
          setInterimSpeech("");
          setIsLiveReconnecting(false);
          setLiveConnectionStatus("disconnected");
          setAppState("idle");
        };

        session.onError = (message, fatal) => {
          setErrorToast(message);
          selfRepairer.addLog("error", "Live API Failure", message);
          if (fatal !== false) {
            setIsSessionActive(false);
            setAppState("idle");
            liveSessionRef.current = null;
          }
        };

        await session.start(
          preferences.name || undefined,
          preferences
        );

        const hour = new Date().getHours();
        const timePeriod =
          hour >= 5 && hour < 12
            ? "morning"
            : hour >= 12 && hour < 17
              ? "afternoon"
              : hour >= 17 && hour < 21
                ? "evening"
                : "night";
        const greetingPrompt = `[Voice session connected. Time of day: ${timePeriod}. Warmly greet ${preferences.name || "the user"} in 1 short sentence as Mimi and ask how you can help.]`;
        session.sendText(greetingPrompt);
      } catch (e) {
        console.error("Failed to start session", e);
        setShowPermissionModal(true);
        setIsSessionActive(false);
        setAppState("idle");
      }
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;
    
    handleTextCommand(textInput);
    setTextInput("");
    setShowTextInput(false);
  };

  const toggleVideoCall = async () => {
    if (isVideoCallActive) {
      setIsVideoCallActive(false);
      setIsGestureControlActive(false);
      if (!isSessionActive && cameraStream) {
        cameraStream.getTracks().forEach(t => t.stop());
        setCameraStream(null);
      }
    } else {
      setIsVideoCallActive(true);
      setIsGestureControlActive(true);
      setShowGestureTutorial(true);
      if (!cameraStream) {
        try {
          const stream = await getCameraStream('user', selectedDeviceId);
          setCameraStream(stream);
          if (liveSessionRef.current) {
            liveSessionRef.current.setVideoStream(stream);
          }
        } catch (e) {
          console.error("Failed to start camera for video call", e);
        }
      }
    }
  };

  const homeTheme: HomeThemeMode =
    preferences.homeLayoutMode === "classic"
      ? "classic"
      : preferences.homeLayoutMode === "claude"
        ? "claude"
        : "3d";
  const isClassicHome = homeTheme === "classic";
  const isSpatialHome = homeTheme === "3d";
  const isClaudeHome = homeTheme === "claude";

  const effectiveConnectionStatus: LiveConnectionStatus = !isOnline
    ? "disconnected"
    : isSessionActive
      ? liveConnectionStatus
      : serverConnectionStatus;

  const starredSet = new Set<string>(
    Array.isArray(preferences.starredChatIds) ? preferences.starredChatIds : []
  );

  const claudeConversations: ClaudeConversationSummary[] = user
    ? conversations.map((c) => {
        const tsAny: any = c.createdAt;
        const ms =
          tsAny?.toMillis?.() ||
          (typeof tsAny?.seconds === "number" ? tsAny.seconds * 1000 : Date.now());
        return {
          id: c.id,
          title: (c.lastMessage || "Conversation").slice(0, 48),
          preview: c.lastMessage || "",
          updatedAtMs: ms,
          starred: starredSet.has(c.id),
        };
      })
    : localChats.map((c) => ({
        id: c.id,
        title: c.title || "New conversation",
        preview: c.messages[c.messages.length - 1]?.text || "",
        updatedAtMs: c.updatedAtMs,
        starred: starredSet.has(c.id),
      }));

  const handleOpenTool = (tool: ToolLaunchId) => {
    switch (tool) {
      case "gmail":
        setIsGmailHubOpen(true);
        break;
      case "whatsapp":
        setIsWhatsAppModalOpen(true);
        break;
      case "photos":
        setIsPhotoHubOpen(true);
        break;
      case "maps":
        setIsMapsModalOpen(true);
        break;
      case "youtube":
        setIsYouTubeModalOpen(true);
        break;
      case "browser":
        setIsBrowserModalOpen(true);
        break;
      case "monitor":
        setIsSystemMonitorModalOpen(true);
        break;
      case "wifi":
        setIsWifiModalOpen(true);
        break;
      case "realme":
        setIsRealmeHubOpen(true);
        break;
      case "livesync":
        setIsLiveSyncControllerOpen(true);
        break;
      case "upgrade":
        setAppState("upgrading");
        break;
      case "settings":
        setShowSettings(true);
        break;
    }
  };

  return (
    <div className={`h-[100dvh] w-screen ${isClaudeHome ? (preferences.claudeDarkMode ? "bg-[#191816]" : "bg-[#FAF9F5]") : "bg-[#020205] text-white"} flex flex-col items-center justify-between font-sans relative overflow-hidden m-0 p-0 ${isClassicHome && isClarityMode ? 'cyber-grid' : ''} ${isVideoCallActive ? 'video-call-theme' : ''}`}>
      {isClassicHome && isClarityMode && <div className="absolute inset-0 cyber-dots pointer-events-none z-0" />}
      {isClassicHome && isClarityMode && <div className="scan-line" />}
      {/* Pulse cursor follow overlay when screen sharing */}
      {screenStream && (
        <motion.div 
          animate={{
            x: mousePos.x + 16,
            y: mousePos.y + 16,
          }}
          transition={{
            type: "spring",
            damping: 25,
            stiffness: 150,
            mass: 0.5,
          }}
          style={{ 
            position: 'fixed', 
            left: 0,
            top: 0,
            pointerEvents: 'none', 
            zIndex: 999999,
          }}
          className="flex items-center gap-2.5 px-4 py-2 bg-black/75 backdrop-blur-md rounded-full shadow-2xl border border-red-500/30 text-white text-[10px] uppercase font-bold tracking-wider select-none ring-1 ring-white/10"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span>
          </span>
          <span className="text-[9px] font-sans text-red-100 font-bold">Screen Sharing Active</span>
          <span className="text-[8px] text-white/30 border-l border-white/10 pl-2 font-mono">
            {mousePos.x > 0 ? `${Math.round(mousePos.x)}, ${Math.round(mousePos.y)}` : "STANDBY"}
          </span>
        </motion.div>
      )}

      {/* Hand Gesture Cursor Layer */}
      <HandCursor 
        stream={cameraStream || screenStream} 
        active={isGestureControlActive} 
        onGesture={(type, data) => {
          if (type === "click") {
            // Visual feedback for clicking? HandCursor component already does that.
          }
        }}
      />

      {showPermissionModal && (
        <PermissionModal 
          onClose={() => setShowPermissionModal(false)} 
        />
      )}

      <HandGestureTutorial
        isOpen={showGestureTutorial}
        onClose={() => setShowGestureTutorial(false)}
        isGestureActive={isGestureControlActive}
        onToggleGestures={() => setIsGestureControlActive(!isGestureControlActive)}
        cameraStream={cameraStream || screenStream}
      />

      <Suspense fallback={null}>
        <AnimatePresence>
          {appState === "upgrading" && (
            <SystemUpgrade onComplete={() => setAppState("idle")} />
          )}
        </AnimatePresence>
      </Suspense>

      {isClaudeHome && (
        <Suspense
          fallback={
            <div className={`h-[100dvh] w-screen flex items-center justify-center ${preferences.claudeDarkMode ? "bg-[#191816] text-[#F2EFE9]" : "bg-[#FAF9F5] text-[#1F1E1B]"}`}>
              <Loader2 className="animate-spin opacity-60" size={24} />
            </div>
          }
        >
          <ClaudeHome
            appState={appState}
            isSessionActive={isSessionActive}
            connectionStatus={effectiveConnectionStatus}
            isReconnecting={isLiveReconnecting}
            interimSpeech={interimSpeech}
            isMuted={isMuted}
            messages={messages}
            conversations={claudeConversations}
            currentConversationId={currentConversationId}
            user={user}
            preferences={preferences}
            onSelectTheme={handleSelectHomeTheme}
            onToggleDarkMode={() => updatePreference("claudeDarkMode", !preferences.claudeDarkMode)}
            onToggleListening={() => toggleListening()}
            onToggleMute={() => {
              const nextMuted = !isMuted;
              setIsMuted(nextMuted);
              updatePreference("isMuted", nextMuted);
            }}
            onSendMessage={(txt, atts) => handleTextCommand(txt, atts)}
            onRegenerateMessage={handleRegenerateMessage}
            onSpeakText={handleSpeakText}
            onStopSpeaking={handleStopSpeaking}
            onNewChat={handleStartFreshConversation}
            onSelectConversation={handleSelectPastConversation}
            onToggleStarConversation={handleToggleStarConversation}
            onDeleteConversation={handleDeletePastConversation}
            onUpdateModel={(coreId) => updatePreference("neuralCore", coreId)}
            onOpenTool={handleOpenTool}
            onToggleDebugPanel={() => setShowDebugPanel((prev) => !prev)}
            onLogin={handleLogin}
            onLogout={handleLogout}
          />
        </Suspense>
      )}

      {isSpatialHome && (
        <Suspense
          fallback={
            <div className="h-[100dvh] w-screen flex items-center justify-center bg-[#040716] text-cyan-300">
              <Loader2 className="animate-spin" size={26} />
            </div>
          }
        >
          <SpatialHome
            appState={appState}
            isSessionActive={isSessionActive}
            connectionStatus={effectiveConnectionStatus}
            isMuted={isMuted}
            messages={messages}
            user={user}
            preferences={preferences}
            onToggleListening={() => toggleListening()}
            onToggleMute={() => {
              const nextMuted = !isMuted;
              setIsMuted(nextMuted);
              updatePreference("isMuted", nextMuted);
            }}
            onSendText={(txt) => handleTextCommand(txt)}
            onClearChat={handleClearHistory}
            onOpenGmail={() => setIsGmailHubOpen(true)}
            onOpenPhotos={() => setIsPhotoHubOpen(true)}
            onOpenSettings={() => setShowSettings(true)}
            onOpenWorkspaceHub={() => {
              setIsSensingHubOpen(false);
              setIsWorkspaceHubOpen((prev) => !prev);
            }}
            onOpenSensingHub={() => {
              setIsWorkspaceHubOpen(false);
              setIsSensingHubOpen((prev) => !prev);
            }}
            onLogin={handleLogin}
            onLogout={handleLogout}
            onHardReboot={handleHardReboot}
            onSelectTheme={handleSelectHomeTheme}
          />
        </Suspense>
      )}

      {isClassicHome && (
      <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none">
        {/* AI "Brain" Logic Visualization */}
        {preferences.showBrainWaves !== false && (
          <BrainVisualizer appState={appState} />
        )}
        
        {preferences.showBackgroundStars !== false && (
          <div className="absolute inset-0 opacity-30">
            {[...Array(50)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: Math.random() }}
                animate={{ opacity: [0.2, 1, 0.2] }}
                transition={{ duration: 2 + Math.random() * 3, repeat: Infinity }}
                className="absolute bg-white rounded-full"
                style={{
                  width: Math.random() * 2 + "px",
                  height: Math.random() * 2 + "px",
                  top: Math.random() * 100 + "%",
                  left: Math.random() * 100 + "%",
                }}
              />
            ))}
          </div>
        )}

        {!isClarityMode && (
          <>
            <motion.div 
              animate={{
                scale: appState === "idle" ? 1 : 1.2,
                opacity: appState === "idle" ? 0.1 : 0.25,
                backgroundColor: appState === "listening" ? `hsl(${258 + (preferences.traits?.sassiness - 50) * 0.5}, 87%, 66%)` : appState === "processing" ? `hsl(${191 + (preferences.traits?.sassiness - 50) * 0.5}, 95%, 43%)` : appState === "speaking" ? `hsl(${331 + (preferences.traits?.sassiness - 50) * 0.5}, 84%, 70%)` : `hsl(${256 + (preferences.traits?.sassiness - 50) * 0.5}, 63%, 44%)`
              }}
              className="absolute top-[-10%] left-[-5%] w-[60%] h-[60%] blur-[150px] rounded-full" 
            />
            <motion.div 
              animate={{
                scale: appState === "idle" ? 1 : 1.2,
                opacity: appState === "idle" ? 0.1 : 0.25,
                backgroundColor: appState === "speaking" ? `hsl(${330 + (preferences.traits?.sassiness - 50) * 0.5}, 83%, 60%)` : `hsl(${337 + (preferences.traits?.sassiness - 50) * 0.5}, 72%, 42%)`
              }}
              className="absolute bottom-[-10%] right-[-5%] w-[60%] h-[60%] blur-[150px] rounded-full"
            />
            <div className="absolute inset-0 w-full h-full bg-[radial-gradient(circle_at_center,transparent_0%,#050505_90%)]" />
          </>
        )}
        
        <SassyAnimations 
          sassiness={preferences.traits?.sassiness || 0} 
          isJoking={isJoking}
          isAngry={isAngry}
        />
        
        {/* Full Screen Video Call Background */}
        <AnimatePresence>
          {isVideoCallActive && (cameraStream || screenStream) && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 w-full h-full z-0"
            >
              <video
                ref={(el) => {
                  if (el) el.srcObject = cameraStream || screenStream;
                }}
                autoPlay
                playsInline
                muted
                className="absolute inset-0 w-full h-full object-cover opacity-60"
                style={{ transform: cameraStream && facingMode === 'user' ? 'scaleX(-1)' : 'none' }}
              />
              <div className="absolute inset-0 bg-gradient-to-b from-[#050505]/80 via-transparent to-[#050505]/80" />
              
              {/* Dynamic HUD for Video Call */}
              <div className="absolute inset-0 pointer-events-none border-[1px] border-white/5 m-4 rounded-[2rem]">
                 <div className="absolute top-8 left-8 flex flex-col gap-1">
                    <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-[0.3em]">Neural Feed Active</span>
                    <div className="flex items-center gap-2">
                       <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                       <span className="text-xs font-mono text-white/50 uppercase tracking-widest leading-none">Mimi Visual Link</span>
                    </div>
                 </div>
                 
                 <div className="absolute bottom-32 right-12 text-right">
                    <span className="text-[10px] font-mono text-cyan-400/50 uppercase tracking-[0.2em]">Spatial Mapping</span>
                    <p className="text-xs font-mono text-white/30 uppercase">Gestural Control: Active</p>
                    <p className={`text-[10px] font-mono uppercase mt-1 ${isOnline ? 'text-green-400/50' : 'text-red-400 animate-pulse'}`}>
                      Network: {isOnline ? 'Stable' : 'Satellite Mode (Offline)'}
                    </p>
                    
                    {/* Diagnostic Feed Mini */}
                    <div className="mt-4 flex flex-col items-end gap-1 max-w-[200px]">
                      {diagnosticLogs.slice(0, 3).map(log => (
                        <div key={log.id} className="text-[9px] font-mono whitespace-nowrap overflow-hidden text-ellipsis">
                          <span className={`mr-2 ${
                            log.type === 'error' ? 'text-red-400' : 
                            log.type === 'repair' ? 'text-purple-400 animate-pulse' : 
                            'text-white/40'
                          }`}>
                            [{log.type.toUpperCase()}]
                          </span>
                          <span className="text-white/20">{log.message}</span>
                        </div>
                      ))}
                    </div>
                 </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      )}

      <AnimatePresence>
        {errorToast && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-2xl bg-red-500/90 backdrop-blur-md border border-red-400 text-white text-sm font-medium shadow-2xl flex items-center gap-3"
          >
            <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
            <div className="flex flex-col">
              <span className="font-bold text-[10px] uppercase tracking-tighter opacity-70">System Alert</span>
              <span>{errorToast}</span>
            </div>
            <button onClick={() => {
              setErrorToast(null);
              if (isSessionActive) toggleListening();
            }} className="ml-4 px-3 py-1 rounded-lg bg-white/20 text-xs backdrop-blur-md hover:bg-white/40 transition-colors">Reset</button>
            <button onClick={() => setErrorToast(null)} className="ml-2 hover:opacity-100">✕</button>
          </motion.div>
        )}
      </AnimatePresence>

      {isClassicHome && (
      <header className="absolute top-0 left-0 w-full flex justify-between items-center z-30 shrink-0 px-6 py-4 md:px-12 md:py-6 bg-gradient-to-b from-black/50 to-transparent backdrop-blur-[2px]">
        <div className="flex items-center gap-3 group">
          <motion.div 
            whileHover={{ scale: 1.1, rotate: 360 }}
            transition={{ duration: 0.8 }}
            className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-400 via-pink-500 via-violet-500 to-amber-300 p-0.5 shadow-[0_0_15px_rgba(236,72,153,0.5)] flex items-center justify-center cursor-pointer overflow-hidden relative"
          >
            <div className="w-full h-full rounded-[10px] overflow-hidden bg-black/40 relative">
              <img 
                src="/src/assets/images/colorful_3d_core_1782217293823.jpg" 
                alt="Mimi 3D Colorful Logo" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
          <div>
            <h1 className="text-xl font-black tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 via-pink-400 via-violet-400 to-amber-350 drop-shadow-[0_0_8px_rgba(236,72,153,0.3)]">MIMI</h1>
            <div className="flex items-center gap-2">
               <p className="text-[10px] font-mono uppercase tracking-[0.2em] opacity-40">AI Neural Link</p>
               <div className="h-1 w-1 rounded-full bg-white/20" />
               <p className="text-[9px] font-mono opacity-30 select-all">{window.location.host}</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-xs font-semibold text-white/90">{user.displayName || preferences.name || "Mimi Guest"}</span>
                <button onClick={handleLogout} className="text-[10px] text-violet-400 hover:text-violet-300 font-mono uppercase tracking-widest">Logout</button>
              </div>
              {user.photoURL ? (
                <motion.img 
                  whileHover={{ scale: 1.1 }}
                  src={user.photoURL} 
                  alt="Profile" 
                  className="w-10 h-10 rounded-full border border-violet-500/30 object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-violet-600/20 border border-violet-500/35 flex items-center justify-center text-violet-400" title="Guest Session Profile">
                  <UserIcon size={18} />
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={handleLogin}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 transition-all border border-white/10 text-sm font-medium"
            >
              <LogIn size={16} />
              <span>Login</span>
            </button>
          )}
          <button
            onClick={handleHardReboot}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 transition-all border border-white/10 text-cyan-400 group relative"
            title="Hard Reboot System"
          >
            <RefreshCcw size={18} className="group-hover:rotate-180 transition-transform duration-500" />
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 scale-0 group-hover:scale-100 transition-transform bg-black/80 px-2 py-1 rounded text-[8px] whitespace-nowrap">Reboot Neural Link</span>
          </button>
          <button
            onClick={() => {
              setIsClarityMode(!isClarityMode);
              selfRepairer.addLog("info", "Clarity Settings Recalibrated", !isClarityMode ? "Activated razor-sharp Clarity HUD mode" : "Activated immersive mode");
            }}
            className={`p-2.5 rounded-full ${isClarityMode ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-400/30 shadow-[0_0_15px_rgba(34,211,238,0.2)]' : 'bg-white/5 text-white/40 border border-white/10'} hover:bg-cyan-500/15 hover:text-cyan-400 hover:border-cyan-400/40 transition-all group relative`}
            title={isClarityMode ? "Disable Clarity HD Grid" : "Enable Clarity HD Grid"}
          >
            {isClarityMode ? <Eye size={18} className="animate-pulse" /> : <EyeOff size={18} />}
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 scale-0 group-hover:scale-100 transition-transform bg-black/80 px-2 py-1 rounded text-[8px] whitespace-nowrap">{isClarityMode ? "Immersive Mode" : "Clarity HUD Mode"}</span>
          </button>
          <ThemeSwitcherButton
            currentTheme={homeTheme}
            onSelectTheme={handleSelectHomeTheme}
            variant="classic"
          />
          <button
            onClick={() => setShowSettings(true)}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 transition-all border border-white/10 text-violet-400 shadow-lg shadow-violet-500/10"
            title="System Settings"
          >
            <Settings size={18} />
          </button>
        </div>
      </header>
      )}

      {isClassicHome && (
      <main className={`absolute inset-0 flex flex-col items-center justify-center w-full h-full z-10 overflow-hidden pt-24 pb-28 px-4 md:px-12 transition-all duration-500 ${isVideoCallActive ? 'bg-transparent' : ''}`}>
        <div className={`w-full max-w-5xl h-full flex flex-col gap-4 overflow-y-auto scrollbar-hide px-4 py-8 pointer-events-auto transition-opacity duration-500 ${isVideoCallActive ? 'opacity-30 hover:opacity-100' : 'opacity-100'}`}>
          <AnimatePresence mode="popLayout">
            {true ? (
              <motion.div
                key="empty-state-timeline"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full h-full flex flex-col items-center justify-center relative min-h-[420px]"
              >
                {/* Welcome Heading */}
                <div className="text-center mb-6 z-20">
                  <span className={`text-[10px] uppercase tracking-[0.3em] font-extrabold font-mono drop-shadow-[0_0_8px_${th.gGlow}] ${th.primary}`}>Neural Interface Active & Verified</span>
                  <h2 className={`text-3xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r ${th.textGrad} mt-1 drop-shadow-md`}>
                    Mimi Neural Orbital Link
                  </h2>
                  <p className="text-xs text-white md:text-white/90 max-w-lg mx-auto mt-2 font-bold leading-relaxed bg-black/40 px-4 py-2 rounded-2xl border border-white/5 backdrop-blur-md">
                    ক্লিক করে Mimi সিস্টেমের বিভিন্ন নোড এবং মাইলস্টোন এক্সপ্লোর করুন। কথা শুরু করতে নিচে "Start Session"-এ বা কীবোর্ড আইকনে চাপুন।
                  </p>
                </div>

                {/* The Orbital Timeline */}
                {preferences.showOrbitalTimeline !== false ? (
                  <div className="w-full flex-1 relative flex items-center justify-center overflow-visible">
                    <RadialOrbitalTimeline 
                      timelineData={timelineData} 
                      themeColor={preferences.themeColor || "violet"}
                    />
                  </div>
                ) : (
                  <div className="w-full flex-1 flex flex-col items-center justify-center p-6 border border-white/10 bg-black/50 rounded-[32px] backdrop-blur-2xl relative overflow-hidden select-none max-w-2xl mx-auto shadow-[0_20px_50px_rgba(0,0,0,0.8),_inset_0_1px_1px_rgba(255,255,255,0.05)] text-center group">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#06060c]/20 to-black pointer-events-none" />
                    
                    {/* Immersive 3D Circular Quantum Server Hologram with glow */}
                    <div className="relative mb-6 w-44 h-44 flex items-center justify-center p-2 rounded-full border border-white/10 bg-gradient-to-tr from-neutral-950 via-[#07070b] to-neutral-900 shadow-[0_0_40px_rgba(34,211,238,0.15)] group-hover:scale-105 transition-all duration-500">
                      {/* Interactive pulsing light rings */}
                      <div className={`absolute -inset-1 rounded-full border border-dashed opacity-40 animate-spin-slow ${th.primaryBorder}`} style={{ animationDuration: '40s' }} />
                      <div className="absolute -inset-3.5 rounded-full border border-dotted opacity-20 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
                      
                      {/* Circular masked 3D Server Core Image with hover rotation */}
                      <div className="w-full h-full rounded-full overflow-hidden border border-white/15 relative">
                        <img 
                          src="/src/assets/images/colorful_3d_core_1782217293823.jpg" 
                          alt="Quantum Server Engine Visual"
                          className="w-full h-full object-cover transition-transform duration-700 hover:scale-115"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#040409]/90 via-transparent to-transparent" />
                      </div>

                      {/* Holographic glowing crystal points */}
                      <span className="absolute -top-1 right-8 w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_12px_rgba(34,211,238,0.95)]" />
                      <span className="absolute -bottom-1 left-8 w-2.5 h-2.5 rounded-full bg-fuchsia-400 animate-pulse shadow-[0_0_12px_rgba(244,114,182,0.95)]" />
                      <span className="absolute left-1/2 top-1 w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                    </div>

                    <span className={`text-[10px] font-mono uppercase tracking-[0.2em] font-extrabold px-3.5 py-1 rounded-xl bg-white/5 border border-white/10 ${th.primary} shadow-md`}>
                      Mimi Quantum Server Engine v9.4
                    </span>
                    <h3 className="text-white text-base font-black tracking-wide uppercase mt-4">Advanced AI Core Interfaced</h3>
                    <p className="text-white/40 text-[10px] font-mono max-w-sm mt-1.5 text-center font-bold">
                      Latency: <span className={th.primary}>2.4ms</span> / CPU Load: <span className={th.primary}>12.8%</span> / Health: <span className="text-emerald-400">100.00% SECURE</span>
                    </p>
                    <p className="text-white/60 text-xs mt-3.5 max-w-md text-center leading-relaxed">
                      হ্যালিয়োস কাস্টমাইজারে "Orbital Timeline" পুনরায় সক্রিয় করলে মাইলস্টোনের নোড রিংটি ফিরে আসবে।
                    </p>
                  </div>
                )}
              </motion.div>
            ) : (
              <></>
            )}
          </AnimatePresence>
          <div ref={messagesEndRef} className="h-4 shrink-0" />
        </div>

        <div className="absolute top-24 left-1/2 -translate-x-1/2 flex items-center gap-4 pointer-events-none">
          <AnimatePresence mode="wait">
            {appState === "processing" ? (
              <motion.div
                key="processing"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-medium backdrop-blur-sm"
              >
                <Loader2 size={12} className="animate-spin" />
                MIMI IS THINKING
              </motion.div>
            ) : appState === "listening" ? (
              <motion.div
                key="listening"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-xs font-medium backdrop-blur-sm"
              >
                <div className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />
                LISTENING TO YOU
              </motion.div>
            ) : appState === "speaking" ? (
              <motion.div
                key="speaking"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-300 text-xs font-medium backdrop-blur-sm"
              >
                <Volume2 size={12} className="animate-bounce" />
                MIMI IS SPEAKING
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>

        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0 opacity-40">
          <Visualizer state={appState} />
        </div>
      </main>
      )}

      <footer className={`absolute bottom-0 left-0 w-full flex flex-col items-center justify-center pb-6 md:pb-8 shrink-0 gap-4 ${isClassicHome ? 'z-20' : 'z-40 pointer-events-none'}`}>
        <AnimatePresence>
          {isClassicHome && showTextInput && (
            <motion.form 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              onSubmit={handleTextSubmit}
              className="w-full max-w-md flex items-center gap-2 bg-white/5 border border-white/10 rounded-full p-1 pl-4 backdrop-blur-md shadow-2xl"
            >
              <input 
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="Type a message to Mimi..."
                className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-white/30 text-sm"
                autoFocus
              />
              <button 
                type="submit"
                disabled={!textInput.trim()}
                className="p-2 rounded-full bg-violet-500 hover:bg-violet-600 disabled:opacity-50 disabled:hover:bg-violet-500 transition-colors"
              >
                <Send size={16} />
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="flex items-center gap-4 flex-wrap justify-center">
          {/* Settings Button - Elegant Gold/Amber Theme */}
          {isClassicHome && (
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-4 rounded-full border transition-all duration-300 shadow-[0_4px_20px_rgba(0,0,0,0.5)] relative overflow-hidden group select-none hover:translate-y-[-2px] ${
              showSettings 
                ? 'bg-gradient-to-tr from-amber-600 via-yellow-500 to-amber-400 border-white/20 text-white shadow-[0_0_20px_rgba(245,158,11,0.55)] scale-110' 
                : 'bg-amber-950/20 border-amber-500/25 text-amber-300 hover:border-amber-500/60 hover:bg-amber-950/40 hover:text-amber-200'
            }`}
            title="Settings"
          >
            <div className="absolute inset-x-0 bottom-0 top-[60%] bg-gradient-to-t from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
            <Settings size={20} className="relative z-10 transition-transform duration-500 group-hover:rotate-45" />
          </button>
          )}

          {/* AI Studio Live Sync & Tactical Switch Button - Neon Violet Circular Controller */}
          {isClassicHome && (
          <button
            onClick={() => setIsLiveSyncControllerOpen(!isLiveSyncControllerOpen)}
            className={`p-4 rounded-full border transition-all duration-300 shadow-[0_4px_20px_rgba(0,0,0,0.5)] relative overflow-hidden group select-none hover:translate-y-[-2px] ${
              isLiveSyncControllerOpen 
                ? 'bg-gradient-to-tr from-violet-600 via-purple-500 to-pink-400 border-white/20 text-white shadow-[0_0_20px_rgba(139,92,246,0.55)] scale-110' 
                : 'bg-violet-950/20 border-violet-500/25 text-violet-300 hover:border-violet-500/60 hover:bg-violet-950/40 hover:text-violet-200'
            }`}
            title="AI Studio Live Sync Switch"
          >
            <div className="absolute inset-x-0 bottom-0 top-[60%] bg-gradient-to-t from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
            <RefreshCw size={20} className={`relative z-10 transition-transform duration-500 ${isLiveSyncControllerOpen ? 'rotate-180 animate-spin-slow' : 'group-hover:rotate-180'}`} />
          </button>
          )}

          {/* Unified Workspace Core & Interface Hub - Combining all workspace features into a single premium switch */}
          <div className="relative pointer-events-auto">
            {isClassicHome && (
            <button
              onClick={() => setIsWorkspaceHubOpen(!isWorkspaceHubOpen)}
              className={`p-4 rounded-full border transition-all duration-500 shadow-[0_0_30px_rgba(236,72,153,0.35),0_12px_45px_rgba(0,0,0,0.8),inset_0_2px_4px_rgba(255,255,255,0.2)] md:shadow-[0_0_40px_rgba(236,72,153,0.4),0_15px_50px_rgba(0,0,0,0.9),inset_0_2px_6px_rgba(255,255,255,0.35)] relative select-none hover:translate-y-[-3px] active:translate-y-0 active:scale-95 group ${
                (isLiveCustomizerOpen || isRealmeHubOpen || isPhotoHubOpen || isGmailHubOpen)
                  ? 'bg-gradient-to-tr from-cyan-500 via-pink-500 via-purple-600 to-red-500 border-white/30 text-white scale-110'
                  : 'bg-neutral-900/60 border-pink-500/35 text-pink-400 hover:border-pink-400/80 hover:bg-neutral-900/90'
              }`}
              title="Quantum Workspace Hub"
            >
              {/* Colorful high-glow outer aura rings */}
              <span className="absolute -inset-1 rounded-full bg-gradient-to-tr from-cyan-400 via-pink-500 to-red-500 opacity-0 group-hover:opacity-30 blur-md transition-opacity duration-500" />
              
              {/* Dynamic Overlapping Combined Logo Component */}
              <div className="relative w-5 h-5 flex items-center justify-center">
                {/* Rotating multi-layered colourful outer orbital lines */}
                <span className={`absolute inset-[-6px] rounded-full border-2 border-dashed border-pink-400/40 pointer-events-none ${
                  (isLiveCustomizerOpen || isRealmeHubOpen || isPhotoHubOpen || isGmailHubOpen) ? 'animate-spin' : 'group-hover:rotate-45 transition-transform duration-700'
                }`} style={{ animationDuration: '8s' }} />
                
                <span className={`absolute inset-[-10px] rounded-full border border-cyan-400/20 border-dotted pointer-events-none ${
                  (isLiveCustomizerOpen || isRealmeHubOpen || isPhotoHubOpen || isGmailHubOpen) ? 'animate-spin' : ''
                }`} style={{ animationDuration: '14s', animationDirection: 'reverse' }} />
                
                {/* Visual state icon representations with beautiful gradients */}
                {isLiveCustomizerOpen ? (
                  <Palette size={18} className="relative z-10 text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)] animate-pulse" />
                ) : isRealmeHubOpen ? (
                  <Smartphone size={18} className="relative z-10 text-violet-300 drop-shadow-[0_0_8px_rgba(167,139,250,0.8)] animate-pulse" />
                ) : isPhotoHubOpen ? (
                  <ImageIcon size={18} className="relative z-10 text-pink-300 drop-shadow-[0_0_8px_rgba(244,63,94,0.8)] animate-pulse" />
                ) : isGmailHubOpen ? (
                  <Mail size={18} className="relative z-10 text-rose-300 drop-shadow-[0_0_8px_rgba(251,113,133,0.8)] animate-pulse" />
                ) : (
                  <Layers size={18} className="relative z-10 text-pink-400 group-hover:text-pink-300 group-hover:rotate-180 transition-all duration-500" />
                )}

                {/* 4 neon glowing status indicators with real 3D shine */}
                <span className={`absolute -top-1.5 -right-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(34,211,238,0.9)] ${isLiveCustomizerOpen ? 'bg-cyan-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
                <span className={`absolute -bottom-1.5 -right-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(139,92,246,0.9)] ${isRealmeHubOpen ? 'bg-violet-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
                <span className={`absolute -bottom-1.5 -left-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(236,72,153,0.9)] ${isPhotoHubOpen ? 'bg-pink-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
                <span className={`absolute -top-1.5 -left-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(244,63,94,0.9)] ${isGmailHubOpen ? 'bg-rose-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
              </div>
            </button>
            )}

            <AnimatePresence>
              {isWorkspaceHubOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 15, scale: 0.93 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 15, scale: 0.93 }}
                  className={`${isClassicHome ? 'absolute bottom-full mb-4 left-1/2 -translate-x-1/2' : 'fixed bottom-24 left-1/2 -translate-x-1/2'} flex flex-col gap-3 bg-[#050508]/99 backdrop-blur-3xl border border-pink-500/35 p-4 rounded-3xl shadow-[0_0_60px_rgba(236,72,153,0.35)] z-50 w-[350px] max-h-[82vh] overflow-y-auto custom-scrollbar`}
                >
                  {/* Premium Header */}
                  <div className="flex flex-col gap-1 border-b border-white/10 pb-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="p-1 rounded-lg bg-gradient-to-br from-pink-500 to-rose-500 shadow-[0_0_12px_rgba(236,72,153,0.5)] flex items-center justify-center animate-pulse">
                          <Palette size={13} className="text-white animate-spin-slow" />
                        </div>
                        <span className="text-[11px] text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-rose-300 uppercase tracking-widest font-mono font-bold">Workspace Master Core</span>
                      </div>
                      <span className="text-[8px] bg-gradient-to-r from-pink-500 to-rose-500 text-white px-2 py-0.5 rounded-full font-mono uppercase font-black tracking-wider shadow-[0_0_8px_rgba(236,72,153,0.4)]">
                        v9.5 Active
                      </span>
                    </div>
                    <span className="text-[9px] text-white/50 leading-none pl-7">Mimi Personal Core Systems & Overlay Hub</span>
                  </div>

                  {/* MASTER MULTI-WINDOW TOGGLE OVERRIDE */}
                  <div className="bg-gradient-to-r from-pink-950/40 to-slate-900/40 border border-pink-500/30 p-2.5 rounded-2xl flex items-center justify-between gap-3 text-left">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[11px] font-bold text-pink-300 uppercase font-sans tracking-wide">Kill Overlays / ডকিং রিসেট</span>
                      <span className="text-[8px] text-white/50">সব ওপেন উইন্ডো এবং ওভারলে একসাথে বন্ধ করুন</span>
                    </div>
                    <button
                      onClick={() => {
                        setIsLiveCustomizerOpen(false);
                        setIsRealmeHubOpen(false);
                        setIsPhotoHubOpen(false);
                        setIsGmailHubOpen(false);
                      }}
                      className="text-[9px] font-black px-3 py-1.5 bg-gradient-to-r from-red-600 to-rose-500 text-white rounded-xl shadow-[0_3px_10px_rgba(220,38,38,0.4)] hover:shadow-[0_5px_15px_rgba(220,38,38,0.6)] active:scale-95 transition-all text-center"
                    >
                      Reset All
                    </button>
                  </div>

                  {/* WORKSPACE APP GRIDS */}
                  <div className="flex flex-col gap-2">
                    
                    {/* 1. HELIOS CUSTOMIZER - CYAN */}
                    <div className="bg-cyan-950/20 border border-cyan-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-cyan-400" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                          <Palette size={16} className="text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)] animate-pulse" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Customizer (থিম কাস্টমাইজার)</span>
                          <span className="text-[8px] text-white/50 leading-none">Live template styling & layout widgets</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsLiveCustomizerOpen(!isLiveCustomizerOpen)}
                        className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all duration-300 border ${
                          isLiveCustomizerOpen
                            ? 'bg-cyan-500 text-black font-black border-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]'
                            : 'bg-white/5 border-white/10 text-white/80 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {isLiveCustomizerOpen ? "Open" : "Launch"}
                      </button>
                    </div>

                    {/* 2. REALME HUB - VIOLET */}
                    <div className="bg-violet-950/20 border border-violet-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-violet-400" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-violet-500/10 border border-violet-500/30">
                          <Smartphone size={16} className="text-violet-400 drop-shadow-[0_0_8px_rgba(167,139,250,0.8)] animate-pulse" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Realme Center (রিয়েলমি হাব)</span>
                          <span className="text-[8px] text-white/50 leading-none">Android tactical sensory control panel</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsRealmeHubOpen(!isRealmeHubOpen)}
                        className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all duration-300 border ${
                          isRealmeHubOpen
                            ? 'bg-violet-500 text-black font-black border-violet-400 shadow-[0_0_10px_rgba(167,139,250,0.5)]'
                            : 'bg-white/5 border-white/10 text-white/80 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {isRealmeHubOpen ? "Active" : "Bridge"}
                      </button>
                    </div>

                    {/* 3. MIMI PHOTOS - PINK */}
                    <div className="bg-pink-950/20 border border-pink-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-pink-400" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-pink-500/10 border border-pink-500/30">
                          <ImageIcon size={16} className="text-pink-400 drop-shadow-[0_0_8px_rgba(236,72,153,0.8)] animate-pulse" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Photo Space (ফটো স্পেস)</span>
                          <span className="text-[8px] text-white/50 leading-none">Browses generative illustrations & feeds</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsPhotoHubOpen(!isPhotoHubOpen)}
                        className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all duration-300 border ${
                          isPhotoHubOpen
                            ? 'bg-pink-500 text-black font-black border-pink-400 shadow-[0_0_10px_rgba(236,72,153,0.5)]'
                            : 'bg-white/5 border-white/10 text-white/80 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {isPhotoHubOpen ? "Viewer On" : "Explore"}
                      </button>
                    </div>

                    {/* 4. MIMI GMAIL - CRIMSON */}
                    <div className="bg-red-950/20 border border-red-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-rose-500" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-red-500/10 border border-red-500/30">
                          <Mail size={16} className="text-rose-400 drop-shadow-[0_0_8px_rgba(251,113,133,0.8)] animate-pulse" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Gmail Link (জি-মেইল সংযোগ)</span>
                          <span className="text-[8px] text-white/50 leading-none">Synchronized mailbox and secure logs</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsGmailHubOpen(!isGmailHubOpen)}
                        className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all duration-300 border ${
                          isGmailHubOpen
                            ? 'bg-rose-500 text-black font-black border-rose-400 shadow-[0_0_10px_rgba(251,113,133,0.5)]'
                            : 'bg-white/5 border-white/10 text-white/80 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {isGmailHubOpen ? "Mail Link" : "Sync Sync"}
                      </button>
                    </div>

                    {/* 5. TACTICAL SYNC CONTROLLER - GRADIENT AMBER/VIOLET */}
                    <div className="bg-gradient-to-r from-violet-950/20 to-pink-950/20 border border-violet-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-gradient-to-b from-violet-400 to-pink-500" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-violet-500/10 border border-violet-500/30">
                          <RefreshCcw size={16} className="text-violet-400 drop-shadow-[0_0_8px_rgba(139,92,246,0.8)] animate-spin-slow" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Sync Controller (সিস্টেম কন্ট্রোলার)</span>
                          <span className="text-[8px] text-white/50 leading-none">AI Live-Sync, circular dial & life story settings</span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setIsLiveSyncControllerOpen(true);
                          setIsWorkspaceHubOpen(false);
                        }}
                        className="text-[9px] font-bold px-3 py-1 rounded-lg bg-gradient-to-r from-violet-600 to-pink-500 text-white border border-violet-400/35 hover:scale-105 active:scale-95 transition-all shadow-[0_0_12px_rgba(139,92,246,0.4)]"
                      >
                        Launch Switch
                      </button>
                    </div>

                  </div>

                  {/* 3D KINETIC REACTOR CORE - DYNAMIC 3D COLOR VISUAL GRAPHIC */}
                  <div className="relative h-28 my-1 flex items-center justify-center bg-black/60 rounded-2xl border border-pink-500/20 overflow-hidden group shadow-[inset_0_0_20px_rgba(236,72,153,0.15)]">
                    {/* Glowing grid background */}
                    <div className="absolute inset-0 bg-[radial-gradient(#ec489912_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
                    
                    {/* 3D Holographic Spinning Spheres (SVG + CSS Animation) */}
                    <div className="relative w-24 h-24 flex items-center justify-center transform-gpu">
                      {/* Outer Ring - Cyan */}
                      <span className="absolute w-20 h-20 rounded-full border-[2px] border-cyan-400/20 border-t-cyan-400 border-r-cyan-400 animate-spin" style={{ animationDuration: '3s' }} />
                      
                      {/* Middle Ring - Violet */}
                      <span className="absolute w-16 h-16 rounded-full border-[2px] border-violet-500/35 border-b-violet-500 border-l-violet-500 animate-spin" style={{ animationDuration: '5s', animationDirection: 'reverse' }} />
                      
                      {/* Inner Ring - Pink */}
                      <span className="absolute w-12 h-12 rounded-full border-[1.5px] border-pink-500/40 border-t-pink-500 border-l-pink-500 animate-ping" style={{ animationDuration: '4s' }} />
                      
                      {/* Core Glowing Orb (3D Feeling with radial gradient) */}
                      <div className="absolute w-7 h-7 rounded-full bg-gradient-to-tr from-pink-500 via-purple-600 to-cyan-400 shadow-[0_0_20px_rgba(236,72,153,0.8),inset_0_2px_4px_rgba(255,255,255,0.6)] animate-pulse flex items-center justify-center">
                        <Sparkles size={11} className="text-white animate-spin-slow" />
                      </div>

                      {/* 3D Projected Floating Nodes */}
                      <div className="absolute -top-1 left-5 w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,1)] animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="absolute bottom-1 right-3 w-1.5 h-1.5 rounded-full bg-pink-400 shadow-[0_0_8px_rgba(244,63,94,1)] animate-bounce" style={{ animationDelay: '0.5s' }} />
                      <div className="absolute top-9 -right-1.5 w-2 h-2 rounded-full bg-violet-400 shadow-[0_0_8px_rgba(167,139,250,1)] animate-bounce" style={{ animationDelay: '0.9s' }} />
                      <div className="absolute top-11 -left-1 w-1.5 h-1.5 rounded-full bg-rose-400 shadow-[0_0_8px_rgba(251,113,133,1)] animate-bounce" style={{ animationDelay: '1.3s' }} />
                    </div>

                    {/* Overlay Tech Label */}
                    <div className="absolute bottom-1.5 left-3 right-3 flex items-center justify-between font-mono text-[7px] text-white/40">
                      <span>PROJECTOR ATOM: v9.5</span>
                      <span className="text-pink-400 animate-pulse font-extrabold tracking-widest">3D HYPERCORE ACTIVE</span>
                    </div>
                  </div>

                  {/* HIGH CALIBRE UPGRADE TELEMETRY FOR WORKSPACE & CORE SERVER */}
                  <div className="border border-white/10 p-2.5 rounded-2xl bg-black/60 font-mono text-[8px] text-white/40 text-left relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-1 opacity-[0.10] group-hover:opacity-[0.20] transition-opacity pointer-events-none">
                      <Sliders size={32} className="text-pink-400" />
                    </div>
                    
                    <div className="flex items-center justify-between border-b border-white/5 pb-1.5 mb-1.5">
                      <div className="flex items-center gap-1.5 text-pink-400 font-black uppercase">
                        <Cpu size={12} className="text-pink-400 animate-spin" style={{ animationDuration: '6s' }} />
                        <span>Core Server Upgraded & Calibrated</span>
                      </div>
                      <span className="text-emerald-400 font-bold animate-pulse">OPTIMIZED</span>
                    </div>

                    <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-white/50 leading-relaxed font-bold">
                      <div>SYSTEM NODE: <span className="font-mono text-pink-400">v9.5 CORE</span></div>
                      <div>DB SYNC: <span className="font-mono text-emerald-400">remixed-db</span></div>
                      <div>ACTIVE PORT: <span className="font-mono text-teal-400">3000 (SECURE)</span></div>
                      <div>REACTIVE SPEED: <span className="font-mono text-cyan-400">&lt; 3ms</span></div>
                    </div>

                    {/* Live upgrade button inside the workspace card as they requested */}
                    <button
                      onClick={() => {
                        selfRepairer.setActiveTask("system_tuning", "Calibrating server reactor cores and routing tables...");
                        setTimeout(() => {
                          selfRepairer.setActiveTask("idle", "");
                        }, 2000);
                      }}
                      className="mt-2 w-full text-center text-[8px] uppercase tracking-wider font-extrabold font-mono py-1 rounded bg-pink-500/10 border border-pink-500/20 hover:bg-pink-500/20 hover:border-pink-500/40 text-pink-300 transition-all flex items-center justify-center gap-1.5 shadow-[inset_0_1px_4px_rgba(236,72,153,0.15)]"
                    >
                      <Sparkles size={9} className="animate-pulse text-pink-400" />
                      <span>Hot-Calibrate Workspace Servers (সার্ভার রিক্যালিব্রেট করুন)</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Unified Quantum Sensing & Media Core Hub - Combining all 4 features into a single premium switch */}
          <div className="relative pointer-events-auto">
            {isClassicHome && (
            <button
              onClick={() => setIsSensingHubOpen(!isSensingHubOpen)}
              className={`p-4 rounded-full border transition-all duration-500 shadow-[0_0_30px_rgba(6,182,212,0.35),0_12px_45px_rgba(0,0,0,0.8),inset_0_2px_4px_rgba(255,255,255,0.2)] md:shadow-[0_0_40px_rgba(6,182,212,0.4),0_15px_50px_rgba(0,0,0,0.9),inset_0_2px_6px_rgba(255,255,255,0.35)] relative select-none hover:translate-y-[-3px] active:translate-y-0 active:scale-95 group ${
                (cameraStream || screenStream || isVideoCallActive)
                  ? 'bg-gradient-to-tr from-teal-500 via-indigo-500 via-cyan-500 to-emerald-400 border-white/30 text-white scale-110'
                  : 'bg-neutral-900/60 border-cyan-500/35 text-cyan-400 hover:border-cyan-400/80 hover:bg-neutral-900/90'
              }`}
              title="Quantum Sensing Hub"
            >
              {/* Colorful high-glow outer aura rings */}
              <span className="absolute -inset-1 rounded-full bg-gradient-to-tr from-teal-400 via-indigo-500 to-emerald-400 opacity-0 group-hover:opacity-30 blur-md transition-opacity duration-500" />
              
              {/* Dynamic Overlapping Combined Logo Component */}
              <div className="relative w-5 h-5 flex items-center justify-center">
                {/* Rotating multi-layered colourful outer orbital lines */}
                <span className={`absolute inset-[-6px] rounded-full border-2 border-dashed border-cyan-400/40 pointer-events-none ${
                  (cameraStream || screenStream || isVideoCallActive) ? 'animate-spin' : 'group-hover:rotate-45 transition-transform duration-700'
                }`} style={{ animationDuration: '8s' }} />
                
                <span className={`absolute inset-[-10px] rounded-full border border-emerald-400/20 border-dotted pointer-events-none ${
                  (cameraStream || screenStream || isVideoCallActive) ? 'animate-spin' : ''
                }`} style={{ animationDuration: '14s', animationDirection: 'reverse' }} />
                
                {/* Visual state icon representations with beautiful gradients */}
                {isVideoCallActive ? (
                  <Activity size={18} className="relative z-10 animate-pulse text-emerald-400 drop-shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
                ) : screenStream ? (
                  <Monitor size={18} className="relative z-10 text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                ) : cameraStream ? (
                  <Camera size={18} className="relative z-10 text-emerald-300 drop-shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                ) : (
                  <Cpu size={18} className="relative z-10 text-cyan-400 group-hover:text-cyan-300 group-hover:rotate-180 transition-all duration-500" />
                )}

                {/* 4 neon glowing status indicators inside the button boundaries */}
                <span className={`absolute -top-1.5 -right-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(52,211,153,0.9)] ${cameraStream ? 'bg-emerald-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
                <span className={`absolute -bottom-1.5 -right-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(59,130,246,0.9)] ${screenStream ? 'bg-blue-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
                <span className={`absolute -bottom-1.5 -left-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(20,184,166,0.9)] ${isVideoCallActive ? 'bg-teal-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
                <span className={`absolute -top-1.5 -left-1.5 w-2 h-2 rounded-full border border-black/50 shadow-[0_0_8px_rgba(167,139,250,0.9)] ${isSensingHubOpen ? 'bg-violet-400 animate-pulse scale-110' : 'bg-neutral-700'}`} />
              </div>
            </button>
            )}
            
            <AnimatePresence>
              {isSensingHubOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 15, scale: 0.93 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 15, scale: 0.93 }}
                  className={`${isClassicHome ? 'absolute bottom-full mb-4 left-1/2 -translate-x-1/2' : 'fixed bottom-24 left-1/2 -translate-x-1/2'} flex flex-col gap-3 bg-[#050508]/99 backdrop-blur-3xl border border-cyan-500/35 p-4 rounded-3xl shadow-[0_0_60px_rgba(6,182,212,0.35)] z-50 w-[350px] max-h-[82vh] overflow-y-auto custom-scrollbar`}
                >
                  {/* Premium Header */}
                  <div className="flex flex-col gap-1 border-b border-white/10 pb-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="p-1 rounded-lg bg-gradient-to-br from-cyan-500 to-indigo-500 shadow-[0_0_12px_rgba(6,182,212,0.5)] flex items-center justify-center animate-pulse">
                          <Cpu size={13} className="text-white animate-spin-slow" />
                        </div>
                        <span className="text-[11px] text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-300 uppercase tracking-widest font-mono font-bold">Quantum Sensing Hub</span>
                      </div>
                      <span className="text-[8px] bg-gradient-to-r from-cyan-500 to-indigo-500 text-white px-2 py-0.5 rounded-full font-mono uppercase font-black tracking-wider shadow-[0_0_8px_rgba(6,182,212,0.4)] animate-pulse">
                        v9.5 Secure
                      </span>
                    </div>
                    <span className="text-[9px] text-white/50 leading-none pl-7">Mimi Adaptive Media & Sensory Overrides</span>
                  </div>

                  {/* MASTER OVERRIDE CONTROLLER SMART SWITCH */}
                  <div className="bg-gradient-to-r from-cyan-950/40 to-slate-900/40 border border-cyan-500/30 p-2.5 rounded-2xl flex items-center justify-between gap-3 text-left">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[11px] font-bold text-cyan-300 uppercase font-sans tracking-wide">Master Sensing Link</span>
                      <span className="text-[8px] text-white/50">টগল করে সব সেন্সর একসাথে অন/অফ করুন</span>
                    </div>
                    <button
                      onClick={async () => {
                        const anyActive = cameraStream || screenStream || isVideoCallActive;
                        if (anyActive) {
                          // Stop all
                          if (cameraStream) {
                            cameraStream.getTracks().forEach(t => t.stop());
                            setCameraStream(null);
                          }
                          if (screenStream) {
                            screenStream.getTracks().forEach(t => t.stop());
                            setScreenStream(null);
                          }
                          if (isVideoCallActive) {
                            toggleVideoCall();
                          }
                        } else {
                          // Start Camera
                          try {
                            const stream = await getCameraStream(facingMode, selectedDeviceId);
                            setCameraStream(stream);
                            if (liveSessionRef.current) {
                              liveSessionRef.current.setVideoStream(stream);
                            }
                          } catch (err) {
                            console.error("Failed to start Master Camera link:", err);
                          }
                        }
                      }}
                      className={`text-[9px] font-black px-3 py-1.5 rounded-xl uppercase tracking-wider transition-all duration-300 border ${
                        (cameraStream || screenStream || isVideoCallActive)
                          ? 'bg-gradient-to-r from-red-650 to-rose-600 text-white border-red-500/35 shadow-[0_3px_10px_rgba(220,38,38,0.45)]'
                          : 'bg-gradient-to-r from-emerald-600 to-teal-500 text-white border-emerald-500/35 shadow-[0_3px_10px_rgba(16,185,129,0.45)]'
                      }`}
                    >
                      {(cameraStream || screenStream || isVideoCallActive) ? "Kill All" : "Awaken"}
                    </button>
                  </div>

                  {/* SENSOR NODES CONTROLLERS */}
                  <div className="flex flex-col gap-2">
                    
                    {/* OPTICLE CAMERA SENSOR - EMERALD MODULE */}
                    <div className="bg-emerald-950/20 border border-emerald-500/30 p-2.5 rounded-2xl flex flex-col gap-1.5 text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-emerald-400" />
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5 pl-1.5">
                          <div className="p-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
                            <Camera size={16} className="text-emerald-400 drop-shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse" />
                          </div>
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Cam Core (ক্যামেরা সংযোগ)</span>
                        </div>
                        <button
                          onClick={toggleCamera}
                          className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all border ${
                            cameraStream
                              ? 'bg-red-500 text-white font-black border-red-400 shadow-[0_0_10px_rgba(239,68,68,0.4)]'
                              : 'bg-emerald-500 text-black font-black border-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.5)]'
                          }`}
                        >
                          {cameraStream ? "Disable" : "Enable"}
                        </button>
                      </div>

                      {cameraStream && (
                        <div className="flex flex-col gap-1.5 pt-2 border-t border-emerald-500/25 ml-1.5">
                          <button
                            onClick={switchCamera}
                            className="w-full justify-center flex items-center gap-1.5 px-2 py-1 rounded-lg bg-[#0e0e12] border border-white/10 text-[9px] text-white/80 hover:bg-white/10 transition-all font-bold"
                          >
                            <RefreshCcw size={10} className="text-violet-400 animate-spin" style={{ animationDuration: '4s' }} />
                            <span>Flip Camera Sensor (ক্যামেরা ফ্লিপ করুন)</span>
                          </button>

                          {videoDevices.length > 0 && (
                            <div className="flex flex-col gap-1 mt-0.5">
                              <span className="text-[7px] uppercase tracking-wider font-mono text-white/40 px-1 font-bold">Select Active Camera Hardware:</span>
                              <div className="flex flex-col gap-0.5 max-h-[85px] overflow-y-auto custom-scrollbar bg-black/40 p-1 rounded">
                                {videoDevices.map((device, idx) => {
                                  const isSelected = selectedDeviceId === device.deviceId || (!selectedDeviceId && idx === 0);
                                  return (
                                    <button
                                      key={device.deviceId || idx}
                                      onClick={() => selectCameraDevice(device.deviceId)}
                                      className={`w-full text-[8px] leading-tight px-1.5 py-1 rounded flex items-center justify-between text-left ${
                                        isSelected 
                                          ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/25' 
                                          : 'text-white/55 hover:bg-white/5'
                                      }`}
                                    >
                                      <span className="truncate max-w-[200px]">{device.label || `Sensor Lens ${idx + 1}`}</span>
                                      {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]" />}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* SCREEN BROADCAST SHARING - INDIGO MODULE */}
                    <div className="bg-blue-950/20 border border-blue-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-blue-400" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-blue-500/10 border border-blue-500/30">
                          <Monitor size={16} className="text-blue-400 drop-shadow-[0_0_8px_rgba(96,165,250,0.8)] animate-pulse" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Screen Share (স্ক্রিন শেয়ার)</span>
                          <span className="text-[8px] text-white/50 leading-none">Casts workspace presentation layers</span>
                        </div>
                      </div>
                      <button
                        onClick={toggleScreen}
                        className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all duration-300 border ${
                          screenStream
                            ? 'bg-red-500 text-white font-black border-red-400 shadow-[0_0_10px_rgba(239,68,68,0.4)]'
                            : 'bg-blue-500 text-black font-black border-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.5)]'
                        }`}
                      >
                        {screenStream ? "Casting" : "Cast Link"}
                      </button>
                    </div>

                    {/* VIDEO CALL ENGINE CORE - TEAL MODULE */}
                    <div className="bg-cyan-950/20 border border-cyan-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-cyan-400" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
                          <Activity size={16} className="text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.8)] animate-pulse" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Video Call (ভিডিও সেশন)</span>
                          <span className="text-[8px] text-white/50 leading-none">Immersive holographic teleconference stream</span>
                        </div>
                      </div>
                      <button
                        onClick={toggleVideoCall}
                        className={`text-[9px] font-bold px-3 py-1 rounded-lg transition-all duration-300 border ${
                          isVideoCallActive
                            ? 'bg-red-500 text-white font-black border-red-400 shadow-[0_0_10px_rgba(239,68,68,0.4)]'
                            : 'bg-cyan-500 text-black font-black border-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]'
                        }`}
                      >
                        {isVideoCallActive ? "Connected" : "Join Call"}
                      </button>
                    </div>

                    {/* TOUCH GESTURE RADAR - AQUAMARINE MODULE BOUNDARY */}
                    <div className="bg-teal-950/20 border border-teal-500/30 p-2.5 rounded-2xl flex items-center justify-between text-left relative overflow-hidden group">
                      <span className="absolute inset-y-0 left-0 w-[3px] bg-teal-400" />
                      <div className="flex items-center gap-2.5 pl-1.5">
                        <div className="p-1 rounded-lg bg-teal-500/10 border border-teal-500/30 animate-pulse">
                          <Hand size={16} className="text-teal-400 drop-shadow-[0_0_8px_rgba(45,212,191,0.8)] animate-bounce" />
                        </div>
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase font-mono font-bold text-white/90">Gesture Radar (জেসচার ডায়াগনস্টিকস)</span>
                          <span className="text-[8px] text-white/50 leading-none">AI tactical hand controller overlay</span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setShowGestureTutorial(true);
                          setIsSensingHubOpen(false); // Clean overlay closing
                        }}
                        className="text-[9px] font-black px-3 py-1 rounded-lg border border-teal-500/30 bg-teal-500 text-black shadow-[0_0_10px_rgba(45,212,191,0.4)] hover:bg-teal-400 transition-all"
                      >
                        Open Pad
                      </button>
                    </div>

                  </div>

                  {/* 3D HOLOGRAPHIC SENSING RADAR - DYNAMIC 3D COLOR VISUAL GRAPHIC */}
                  <div className="relative h-28 my-1 flex items-center justify-center bg-black/60 rounded-2xl border border-cyan-500/20 overflow-hidden group shadow-[inset_0_0_20px_rgba(6,182,212,0.15)]">
                    {/* Glowing grid background */}
                    <div className="absolute inset-0 bg-[radial-gradient(#22d3ee0d_1px,transparent_1px)] [background-size:14px_14px] pointer-events-none" />
                    
                    {/* Concentric Radar sweeping vector illustration */}
                    <div className="relative w-22 h-22 flex items-center justify-center">
                      {/* Rotating radar swept beam sweep */}
                      <div className="absolute w-20 h-20 rounded-full bg-gradient-to-tr from-cyan-500/20 via-transparent to-transparent animate-spin" style={{ animationDuration: '4s' }} />
                      
                      {/* Radar Rings */}
                      <div className="absolute w-20 h-20 rounded-full border border-cyan-500/25 animate-pulse" />
                      <div className="absolute w-14 h-14 rounded-full border border-cyan-500/15 border-dashed" />
                      <div className="absolute w-8 h-8 rounded-full border border-cyan-500/10" />
                      
                      {/* Grid crosshairs */}
                      <div className="absolute w-20 h-[1px] bg-cyan-500/15" />
                      <div className="absolute h-20 w-[1px] bg-cyan-500/15" />

                      {/* Dynamic Core Orb Layer (3D radial gradient sphere with premium specular shine) */}
                      <div className="absolute w-6 h-6 rounded-full bg-gradient-to-tr from-cyan-500 via-indigo-600 to-emerald-400 shadow-[0_0_15px_rgba(6,182,212,0.8),inset_0_2.5px_4px_rgba(255,255,255,0.75)] animate-pulse flex items-center justify-center">
                        <Cpu size={10} className="text-white animate-spin-slow" />
                      </div>

                      {/* Detected "Sensing" Target blips glowing brightly */}
                      <div className="absolute top-5 left-5 w-2 h-2 rounded-full bg-emerald-400 animate-ping shadow-[0_0_10px_rgba(52,211,153,1)]" style={{ animationDuration: '1.8s' }} />
                      <div className="absolute top-5 left-5 w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,1)]" />

                      <div className="absolute bottom-6 right-5 w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping shadow-[0_0_10px_rgba(96,165,250,1)]" style={{ animationDuration: '2.5s' }} />
                      <div className="absolute bottom-6 right-5 w-1.5 h-1.5 rounded-full bg-blue-400 shadow-[0_0_6px_rgba(96,165,250,1)]" />

                      <div className="absolute top-12 right-4 w-2 h-2 rounded-full bg-amber-400 animate-ping shadow-[0_0_10px_rgba(251,191,36,1)]" style={{ animationDuration: '3s' }} />
                      <div className="absolute top-12 right-4 w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_6px_rgba(251,191,36,1)]" />
                    </div>

                    {/* Overlay Tech Label */}
                    <div className="absolute bottom-1.5 left-3 right-3 flex items-center justify-between font-mono text-[7px] text-white/40">
                      <span>RADAR SWEEP: ACTIVE</span>
                      <span className="text-cyan-400 animate-pulse font-extrabold tracking-widest">3D SENSE RADAR ONLINE</span>
                    </div>
                  </div>

                  {/* LATEST QUANTUM SERVER UPGRADE TELEMETRY DISPLAY */}
                  <div className="border border-white/10 p-2.5 rounded-2xl bg-black/60 font-mono text-[8px] text-white/40 text-left relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-1 opacity-[0.10] group-hover:opacity-[0.20] transition-opacity pointer-events-none">
                      <Cpu size={32} className="text-cyan-400" />
                    </div>
                    
                    <div className="flex items-center justify-between border-b border-white/5 pb-1.5 mb-1.5">
                      <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                        <ShieldCheck size={11} className="text-emerald-400 animate-pulse" />
                        <span>QUANTUM UPLINK UPGRADE: ACTIVE</span>
                      </div>
                      <span className="text-cyan-400 animate-pulse font-bold tracking-tight">STABLE</span>
                    </div>

                    <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-white/50 leading-relaxed font-bold">
                      <div>UPLINK PORT: <span className="font-mono text-cyan-400">3000 (SECURE)</span></div>
                      <div>LATENCY: <span className="font-mono text-cyan-400">4ms (SYNC)</span></div>
                      <div>MEM DB ID: <span className="font-mono text-violet-400">remixed-db</span></div>
                      <div>OFFLINE: <span className="font-mono text-emerald-400 font-black">LOCAL SAFE</span></div>
                    </div>

                    {/* LIVE CALIBRATING SERVER REACTOR CORE - VISUAL CORE ADDITION */}
                    <div className="flex items-center gap-2 mt-2 pt-1.5 border-t border-white/5 text-[7px] text-cyan-400/80 uppercase justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                      <span>Server Engine v9.5 active calibration loop synced.</span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Main Voice Activation Session Controller - Absolute Premium 3D Power Button */}
          {isClassicHome && (
          <button
            onClick={toggleListening}
            className={`
              group relative flex items-center gap-3 px-8 py-4 rounded-full font-black tracking-wide transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.8)] overflow-hidden select-none active:scale-95
              ${
                isSessionActive
                  ? "bg-gradient-to-r from-red-650 via-rose-600 to-pink-600 text-white border border-white/20 shadow-[0_0_35px_rgba(239,68,68,0.7)]"
                  : "bg-gradient-to-r from-neutral-950 via-[#07070b] to-neutral-900 text-cyan-300 border border-cyan-500/35 hover:scale-105 hover:border-cyan-400 hover:shadow-[0_0_20px_rgba(34,211,238,0.25)]"
              }
            `}
          >
            <div className="absolute inset-x-0 top-0 h-[40%] bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />
            {isSessionActive ? (
              <>
                <MicOff size={20} className="relative z-10 text-white drop-shadow-[0_1px_5px_rgba(0,0,0,0.3)] animate-pulse" />
                <span className="relative z-10 uppercase text-xs">End Session</span>
              </>
            ) : (
              <>
                <Mic size={20} className="relative z-10 text-cyan-400 group-hover:animate-bounce drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]" />
                <span className="relative z-10 uppercase text-xs">Start Session</span>
              </>
            )}
          </button>
          )}
          
          {/* Key Message Input Trigger - Bright Cyber Lavender theme */}
          {isClassicHome && !isSessionActive && (
            <button
              onClick={() => setShowTextInput(!showTextInput)}
              className={`p-4 rounded-full border transition-all duration-300 shadow-[0_4px_20px_rgba(0,0,0,0.5)] relative overflow-hidden group select-none hover:translate-y-[-2px] ${
                showTextInput 
                  ? 'bg-gradient-to-tr from-violet-600 to-pink-500 border-white/20 text-white shadow-[0_0_20px_rgba(167,139,250,0.55)] scale-110' 
                  : 'bg-violet-950/20 border-violet-500/25 text-violet-300 hover:border-violet-500/60 hover:bg-violet-950/40 hover:text-violet-200'
              }`}
              title="Type instead"
            >
              <div className="absolute inset-x-0 bottom-0 top-[60%] bg-gradient-to-t from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              <Keyboard size={20} className="relative z-10 opacity-90 group-hover:scale-105 transition-transform" />
            </button>
          )}
        </div>

        {/* Interstitial backdrop for full screen preview */}
        <AnimatePresence>
          {((cameraStream || screenStream) && !isVideoCallActive && videoPreviewSize === "full") && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/85 backdrop-blur-md z-[998] pointer-events-auto"
              onClick={() => setVideoPreviewSize("small")}
            />
          )}
        </AnimatePresence>

        {/* Video Preview with Adaptive Framing & Size Adjustments */}
        <AnimatePresence>
          {(cameraStream || screenStream) && !isVideoCallActive && (
            <motion.div
              layoutId="cameraPreviewContainer"
              initial={{ scale: 0.9, opacity: 0, y: 30 }}
              animate={videoPreviewSize === "full" ? {
                scale: 1, 
                opacity: 1, 
                x: "-50%", 
                y: "-50%",
                left: "50%",
                top: "50%",
                bottom: "auto",
                right: "auto",
              } : {
                scale: 1, 
                opacity: 1, 
                x: 0, 
                y: 0,
                left: "auto",
                top: "auto",
                bottom: "112px",
                right: "24px",
              }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className={`${
                videoPreviewSize === "full"
                  ? "fixed w-[92vw] md:w-[75vw] max-w-4xl aspect-video rounded-3xl border-2 border-violet-400/50 shadow-[0_0_50px_rgba(139,92,246,0.4)] z-[999] bg-slate-950"
                  : videoPreviewSize === "large"
                    ? "absolute w-[340px] md:w-[500px] aspect-video rounded-3xl border border-violet-500/40 shadow-2xl z-30 bg-black/50 backdrop-blur-lg"
                    : "absolute w-52 md:w-72 aspect-video rounded-2xl border border-violet-500/30 shadow-xl z-30 bg-black/40 backdrop-blur-md"
              } overflow-hidden pointer-events-auto transition-all duration-300 flex flex-col justify-between`}
              id="mimi_camera_panel"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-violet-950/20 via-transparent to-cyan-950/10 pointer-events-none" />
              
              <video
                ref={videoPreviewRef}
                autoPlay
                playsInline
                muted
                className={`absolute inset-0 w-full h-full ${
                  videoFitMode === 'cover' ? 'object-cover' : 'object-contain bg-slate-950/90'
                }`}
                style={{ transform: cameraStream && facingMode === 'user' ? 'scaleX(-1)' : 'none' }}
              />

              {/* Top Bar with Live Indicator & Title */}
              <div className="absolute top-3 left-3 flex items-center gap-2 z-40 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 select-none">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
                <span className="text-[9px] font-mono font-black text-rose-100 uppercase tracking-widest">
                  {cameraStream ? `Cam (${facingMode === 'user' ? "Front/ফন্ট" : "Rear/ব্যাক"})` : 'Screen Link'}
                </span>
              </div>

              {/* Upgraded Cyber Navigation Controls - Top Right */}
              <div className="absolute top-3 right-3 flex items-center gap-1 z-40 bg-black/70 backdrop-blur-md p-1 rounded-full border border-white/10 shadow-lg">
                {/* Switch Camera Link */}
                {cameraStream && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      switchCamera();
                    }}
                    className="p-2 rounded-full hover:bg-violet-500/20 text-violet-300 hover:text-white transition-all cursor-pointer active:scale-90"
                    title="ক্যামেরা ফ্লিপ করুন (Flip Camera)"
                  >
                    <RefreshCcw size={13} className="animate-spin" style={{ animationDuration: '6s' }} />
                  </button>
                )}

                {/* Fit Mode Control Toggle */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setVideoFitMode(prev => prev === "cover" ? "contain" : "cover");
                  }}
                  className={`p-2 rounded-full transition-all cursor-pointer active:scale-95 ${
                    videoFitMode === 'contain' 
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/20' 
                      : 'hover:bg-white/10 text-white/80 hover:text-white'
                  }`}
                  title={videoFitMode === "cover" ? "সম্পূর্ণ ফ্রেম দেখুন (Fit Mode)" : "ফুল স্ক্রিন ক্রপ করুন (Cover Mode)"}
                >
                  <Crop size={13} />
                </button>

                {/* Size Swappers */}
                {videoPreviewSize !== "small" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setVideoPreviewSize("small");
                    }}
                    className="p-2 rounded-full hover:bg-white/10 text-white/80 hover:text-white transition-all cursor-pointer active:scale-95"
                    title="ছোট উইন্ডো (Small)"
                  >
                    <Shrink size={13} />
                  </button>
                )}

                {videoPreviewSize !== "large" && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setVideoPreviewSize("large");
                    }}
                    className="p-2 rounded-full hover:bg-white/10 text-white/80 hover:text-white transition-all cursor-pointer active:scale-95"
                    title="মাঝারি উইন্ডো (Medium)"
                  >
                    <Expand size={13} />
                  </button>
                )}

                {videoPreviewSize !== "full" ? (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setVideoPreviewSize("full");
                    }}
                    className="p-2 rounded-full bg-violet-600/30 text-violet-300 hover:bg-violet-500 hover:text-white transition-all cursor-pointer border border-violet-500/30 active:scale-90"
                    title="ফুল স্ক্রিন করুন (Full Screen View)"
                  >
                    <Maximize2 size={13} />
                  </button>
                ) : (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setVideoPreviewSize("small");
                    }}
                    className="p-2 rounded-full bg-amber-500/20 text-amber-300 hover:bg-amber-500 hover:text-slate-950 transition-all cursor-pointer border border-amber-400/35 active:scale-90"
                    title="ফুল স্ক্রিন থেকে বের হোন (Minimize)"
                  >
                    <Minimize2 size={13} />
                  </button>
                )}
              </div>

              {/* Bottom control bar showing device information or hints */}
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 flex items-center justify-between z-40 select-none">
                <span className="text-[9px] font-mono text-white/40 leading-none truncate max-w-[50%]">
                  {videoFitMode === 'cover' ? "ক্রপড ভিউ (Cropped to fit)" : "সম্পূর্ণ ক্যামেরা সেন্সর (Full Sensor View)"}
                </span>
                
                {/* Device switch indicators directly inside preview */}
                {videoDevices.length > 1 && (
                  <div className="flex gap-1">
                    {videoDevices.map((device, idx) => {
                      const isSelected = selectedDeviceId === device.deviceId || (!selectedDeviceId && idx === 0);
                      return (
                        <button
                          key={device.deviceId || idx}
                          onClick={(e) => {
                            e.stopPropagation();
                            selectCameraDevice(device.deviceId);
                          }}
                          className={`w-4 h-4 rounded-full text-[8px] font-mono font-bold flex items-center justify-center transition-all ${
                            isSelected 
                              ? "bg-violet-500 text-white shadow-md ring-1 ring-white/25 scale-110" 
                              : "bg-black/60 text-white/50 hover:bg-white/10 hover:text-white"
                          }`}
                          title={device.label || `Sensor ${idx + 1}`}
                        >
                          {idx + 1}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Settings Modal (lazy-loaded) */}
        <Suspense fallback={null}>
          {showSettings && (
            <div className="pointer-events-auto">
            <SettingsModal
              onClose={() => setShowSettings(false)}
              onUpgradeSystem={() => {
                setShowSettings(false);
                setAppState("upgrading");
              }}
              preferences={preferences}
              user={user}
              accessToken={accessToken}
              memories={memories}
              searchHistory={searchHistory}
              conversations={conversations}
              currentConversationId={currentConversationId}
              voiceLogs={voiceLogs}
              commandLogs={commandLogs}
              onClearVoiceLogs={handleClearVoiceLogs}
              onClearCommandLogs={handleClearCommandLogs}
              onSelectConversation={handleSelectPastConversation}
              onStartNewConversation={handleStartFreshConversation}
              onDeleteConversation={handleDeletePastConversation}
              onAddMemory={handleAddManualMemory}
              onDeleteMemory={handleDeletePastMemory}
              onClearSearches={handleClearSearchLog}
              onLogin={async () => {
                await handleLoginWorkspace();
              }}
              onLogout={async () => {
                try {
                  await logout();
                  setAccessToken(null);
                } catch (err) {
                  console.error("Settings logout error", err);
                }
              }}
              onSave={(newPrefs) => {
                handleSavePreferences(newPrefs);
              }}
              onClearHistory={() => {
                setMessages([]);
                localStorage.removeItem("mimi_chat_history");
              }}
            />
            </div>
          )}
        </Suspense>

        {/* HELIOS Live Customizer Drawer */}
        <AnimatePresence>
          {isLiveCustomizerOpen && (
            <motion.div
              initial={{ opacity: 0, x: 350 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 350 }}
              transition={{ type: "spring", damping: 25, stiffness: 180 }}
              className="fixed top-0 right-0 h-full w-full max-w-sm bg-neutral-950/95 backdrop-blur-2xl border-l border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.8)] z-50 flex flex-col justify-between select-none pointer-events-auto"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`p-2 rounded-xl bg-gradient-to-tr ${th.brandGrad} text-black font-extrabold shadow-md`}>
                    <Palette size={16} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white tracking-wider uppercase">HELIOS Customizer</h3>
                    <p className="text-[10px] text-white/40 tracking-wider font-mono">HOMEPAGE MODULATOR</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsLiveCustomizerOpen(false)}
                  className="p-1 px-2.5 text-xs font-mono font-bold text-white/40 hover:text-white hover:bg-white/5 rounded-lg border border-transparent hover:border-white/5 transition-all"
                >
                  ESC
                </button>
              </div>

              {/* Main controls scrollable view */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                
                {/* 1. COLOR ACCENT CONTROLS */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono tracking-widest text-white/50 uppercase font-bold">1. System Color Accent</span>
                    <span className={`text-[9px] font-mono font-extrabold uppercase px-1.5 py-0.5 rounded bg-white/5 ${th.primary}`}>
                      {preferences.themeColor || "VIOLET"}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { id: "violet", label: "Cyber Violet (ডিফল্ট)", emoji: "💜", desc: "Classic neon lavender neural wave", grad: "from-violet-600 via-fuchsia-500 to-pink-500" },
                      { id: "gold", label: "Realme Gold (গোল্ড)", emoji: "💛", desc: "Golden Realme amber premium hue", grad: "from-amber-500 via-yellow-400 to-orange-500" },
                      { id: "cyan", label: "Deep Neon Cyan (সায়ান)", emoji: "🩵", desc: "Cool high-contrast future tech", grad: "from-cyan-500 via-teal-400 to-blue-500" },
                      { id: "emerald", label: "Emerald Aurora (সবুজ)", emoji: "💚", desc: "Vibrant biological green synergy", grad: "from-emerald-500 via-green-400 to-teal-500" },
                      { id: "crimson", label: "Crimson Engine (লাল)", emoji: "❤️", desc: "Fiery high-power cyberpunk glow", grad: "from-rose-500 via-pink-500 to-red-600" }
                    ].map((tOpt) => {
                      const isSelected = (preferences.themeColor || "violet") === tOpt.id;
                      return (
                        <button
                          key={tOpt.id}
                          onClick={() => updatePreference("themeColor", tOpt.id)}
                          className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between relative overflow-hidden group ${
                            isSelected 
                              ? "bg-white/5 border-white/20 shadow-xl" 
                              : "bg-neutral-900/30 border-transparent hover:bg-neutral-900/50 hover:border-white/5"
                          }`}
                        >
                          <div className="flex items-center gap-3 relative z-10">
                            <div className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${tOpt.grad} flex items-center justify-center text-white text-base shadow`}>
                              {tOpt.emoji}
                            </div>
                            <div>
                              <div className="text-xs font-black text-white group-hover:text-cyan-300 transition-colors">{tOpt.label}</div>
                              <div className="text-[10px] text-white/40">{tOpt.desc}</div>
                            </div>
                          </div>
                          {isSelected && (
                            <div className={`p-1.5 rounded-full ${th.primaryBg} text-white shadow relative z-10`}>
                              <Check size={11} className="stroke-[3]" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. HOMEPAGE TOGGLES (FEATURES SWITCH) */}
                <div className="space-y-3 pt-3 border-t border-white/5">
                  <span className="text-[10px] font-mono tracking-widest text-white/50 uppercase font-bold block">2. Homepage Toggles</span>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 rounded-2xl border border-cyan-500/25 bg-cyan-950/20">
                      <div>
                        <div className="text-xs font-extrabold text-white">3D Spatial Home (নতুন ৩ডি ডিজাইন)</div>
                        <div className="text-[10px] text-white/50 leading-tight max-w-[210px]">Toggle between new 3D Orb home and Classic view</div>
                      </div>
                      <button
                        onClick={() => updatePreference("homeLayoutMode", isClassicHome ? "3d" : "classic")}
                        className={`w-10 h-6 rounded-full p-0.5 transition-colors relative flex items-center ${
                          !isClassicHome ? "bg-cyan-500" : "bg-neutral-800"
                        }`}
                      >
                        <motion.div
                          layout
                          className="w-5 h-5 rounded-full bg-white shadow-md animate-none"
                          animate={{ translateX: !isClassicHome ? "16px" : "0px" }}
                          transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        />
                      </button>
                    </div>
                    {[
                      { 
                        key: "showOrbitalTimeline", 
                        title: "Orbital Timeline (টাইমলাইন)", 
                        desc: "Display interactive milestone nodes",
                        val: preferences.showOrbitalTimeline !== false 
                      },
                      { 
                        key: "showBackgroundStars", 
                        title: "Floating Stars (প্যার্টিক্যালস)", 
                        desc: "Render ambient cosmic background stars",
                        val: preferences.showBackgroundStars !== false 
                      },
                      { 
                        key: "showBrainWaves", 
                        title: "Brain wave glow (ব্রেইন ওয়েভস)", 
                        desc: "Show AI brain status vector background",
                        val: preferences.showBrainWaves !== false 
                      },
                      { 
                        key: "showSystemMonitor", 
                        title: "Diagnostic Overlay (সিস্টেম মনিটর)", 
                        desc: "Render active core system metrics",
                        val: preferences.showSystemMonitor !== false 
                      }
                    ].map((toggle) => (
                      <div 
                        key={toggle.key}
                        className="flex items-center justify-between p-3 rounded-2xl border border-white/5 bg-neutral-900/20"
                      >
                        <div>
                          <div className="text-xs font-extrabold text-white">{toggle.title}</div>
                          <div className="text-[10px] text-white/40 leading-tight max-w-[210px]">{toggle.desc}</div>
                        </div>
                        <button
                          onClick={() => updatePreference(toggle.key, !toggle.val)}
                          className={`w-10 h-6 rounded-full p-0.5 transition-colors relative flex items-center ${
                            toggle.val ? th.primaryBg : "bg-neutral-800"
                          }`}
                        >
                          <motion.div 
                            layout
                            className="w-5 h-5 rounded-full bg-white shadow-md animate-none"
                            animate={{ translateX: toggle.val ? "16px" : "0px" }}
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. DYNAMIC BRANDING INPUTS */}
                <div className="space-y-3 pt-3 border-t border-white/5">
                  <span className="text-[10px] font-mono tracking-widest text-white/50 uppercase font-bold block">3. System Identity</span>
                  
                  <div className="space-y-2 bg-neutral-900/20 border border-white/5 p-4 rounded-3xl">
                    <div className="space-y-1">
                      <label className="text-[10px] font-extrabold text-white/50 font-mono uppercase block">Username Customizer</label>
                      <input 
                        type="text"
                        value={preferences.name || ""}
                        onChange={(e) => updatePreference("name", e.target.value)}
                        placeholder="your name..."
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-white/20 outline-none focus:border-cyan-400 transition-all font-mono"
                      />
                    </div>

                    <div className="space-y-1 mt-3">
                      <label className="text-[10px] font-extrabold text-white/50 font-mono uppercase block">Assistant Relationship Type</label>
                      <select
                        value={preferences.relationshipType || "Casual"}
                        onChange={(e) => updatePreference("relationshipType", e.target.value)}
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-2 py-2 text-xs text-white outline-none focus:border-cyan-400 transition-all font-mono"
                      >
                        <option value="Casual">Casual Partner (ক্যাজুয়াল)</option>
                        <option value="Professional">Professional Workspace Manager</option>
                        <option value="Sister Core">Sister AI Core Assistance</option>
                        <option value="Deep Link">Deep Neural Connection</option>
                      </select>
                    </div>
                  </div>
                </div>
                
              </div>

              {/* Footer upgrade actions */}
              <div className="p-6 border-t border-white/5 bg-black/50 space-y-3 shrink-0">
                <button
                  onClick={() => {
                    setIsLiveCustomizerOpen(false);
                    setAppState("upgrading");
                  }}
                  className={`w-full py-3 rounded-2xl bg-gradient-to-r ${th.btnGrad} text-center text-xs font-black uppercase tracking-wider transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer`}
                >
                  ⚡ Upgrade System Core (আপগ্রেড করুন)
                </button>
                <p className="text-[9px] text-center text-white/30 font-mono">
                  HELIOS OS V9.4 - Verified Secure Link
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Wrap shared workspace modals in pointer-events-auto so they are always interactive across themes */}
        <div className="pointer-events-auto">
        <Suspense fallback={null}>
          {/* Mimi Photo Hub */}
          <MimiPhotoHub 
            isOpen={isPhotoHubOpen}
            onClose={() => setIsPhotoHubOpen(false)}
            activeCommandPhotoCategory={activeCommandPhotoCategory}
            userName={preferences.name || "Dada/Didi"}
            onPhotoSelectedByMimi={(photoTitle) => {
              selfRepairer.addLog("info", "Photo Channel Sync", `Retrieved visual moment: "${photoTitle}"`);
            }}
          />

          {/* Realme OS Android Control Hub */}
          <RealmeControlHub
            isOpen={isRealmeHubOpen}
            onClose={() => setIsRealmeHubOpen(false)}
            cameraStream={cameraStream}
            batteryLevel={batteryLevel}
            batteryCharging={batteryCharging}
          />

          {/* Mimi Gmail Hub */}
          <MimiGmailHub 
            isOpen={isGmailHubOpen}
            onClose={() => setIsGmailHubOpen(false)}
            user={user}
            accessToken={accessToken}
            onLogin={async () => {
              await handleLoginWorkspace();
            }}
            mimiVocalize={async (vocalText) => {
              const chatMsg = { id: Date.now().toString() + "-gm", sender: "mimi" as const, text: vocalText };
              setMessages((prev) => [...prev, chatMsg]);
              if (!isMuted) {
                setAppState("speaking");
                const audioBase64 = await getMimiAudio(vocalText, preferences.voiceId);
                if (audioBase64) {
                  await playPCM(audioBase64);
                }
                setAppState("idle");
              }
            }}
          />

          {/* Live Sync Controller & Future Story Settings */}
          <LiveSyncController 
            isOpen={isLiveSyncControllerOpen}
            onClose={() => setIsLiveSyncControllerOpen(false)}
            user={user}
          />

          {/* Additional Tools Modals for Claude Style & Unified Workspace */}
          <WhatsAppModal
            isOpen={isWhatsAppModalOpen}
            onClose={() => setIsWhatsAppModalOpen(false)}
            darkMode={Boolean(preferences.claudeDarkMode)}
          />
          <MapsModal
            isOpen={isMapsModalOpen}
            onClose={() => setIsMapsModalOpen(false)}
            onAskDirections={(place) => handleTextCommand(`open google maps for ${place}`)}
            themeVariant={
              isClaudeHome
                ? preferences.claudeDarkMode
                  ? "warm-dark"
                  : "warm-light"
                : "space"
            }
          />
          <YouTubeModal
            isOpen={isYouTubeModalOpen}
            onClose={() => setIsYouTubeModalOpen(false)}
            darkMode={Boolean(preferences.claudeDarkMode)}
          />
          <BrowserModal
            isOpen={isBrowserModalOpen}
            onClose={() => setIsBrowserModalOpen(false)}
            darkMode={Boolean(preferences.claudeDarkMode)}
          />
          <WifiScannerModal
            isOpen={isWifiModalOpen}
            onClose={() => setIsWifiModalOpen(false)}
            serverLinks={preferences.serverLinks || []}
            darkMode={Boolean(preferences.claudeDarkMode)}
          />
          <SystemMonitorModal
            isOpen={isSystemMonitorModalOpen}
            onClose={() => setIsSystemMonitorModalOpen(false)}
            neuralCore={preferences.neuralCore || "Gemini"}
            batteryLevel={batteryLevel}
            batteryCharging={batteryCharging}
            isOnline={isOnline}
            diagnosticLogs={diagnosticLogs}
            darkMode={Boolean(preferences.claudeDarkMode)}
          />
        </Suspense>

        {/* Google Authentication Diagnostics Tool */}
        <GoogleAuthDiagnostics
          isOpen={authErrorDetails !== null}
          onClose={() => setAuthErrorDetails(null)}
          error={authErrorDetails}
          onRetryBasic={handleLoginBasic}
          onRetryWorkspace={handleLoginWorkspace}
        />

        {(showDebugPanel || isSessionActive || !isClaudeHome) && (
          <LiveDebugPanel info={liveDebugInfo} isReconnecting={isLiveReconnecting} />
        )}
        </div>

        {isClassicHome && (
        <>
        {/* Activity Monitor / Skin Layout */}
        <ActivityMonitor 
          activity={activity} 
          skin={preferences.displaySkin || "Tech"} 
        />

        {/* Neural Dashboard / System Monitor Skin */}
        <SystemMonitor 
          neuralCore={preferences.neuralCore || "Gemini"} 
          isActive={preferences.showSystemMonitor} 
        />

        {/* Futuristic Battery Status Indicator badge */}
        <div 
          className="flex items-center gap-2 bg-black/60 backdrop-blur-xl border border-white/5 rounded-full px-3 py-1.5 shadow-xl select-none transition-all hover:bg-black/85 hover:border-violet-500/30 z-30 mb-1"
          title="Device Battery Tracking Console"
        >
          <span className={`w-1.5 h-1.5 rounded-full ${batteryCharging ? "bg-amber-400 animate-pulse shadow-[0_0_8px_rgba(251,191,36,0.6)]" : batteryLevel < 20 ? "bg-red-500 animate-bounce" : "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"}`} />
          
          <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest text-white/50 font-bold">
            <span>Battery:</span>
            <span className={`font-black flex items-center gap-1 ${batteryCharging ? "text-amber-400" : batteryLevel < 20 ? "text-red-400 animate-pulse" : "text-emerald-400"}`}>
              {batteryCharging ? (
                <BatteryCharging size={11} className="animate-pulse" />
              ) : batteryLevel < 20 ? (
                <BatteryWarning size={11} className="text-red-400" />
              ) : (
                <Battery size={11} />
              )}
              {batteryLevel}%
            </span>
            {batteryCharging && (
              <span className="text-[8px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1.5 py-0.5 rounded font-sans uppercase">
                Charging
              </span>
            )}
          </div>
        </div>
        </>
        )}
      </footer>
    </div>
  );
}
