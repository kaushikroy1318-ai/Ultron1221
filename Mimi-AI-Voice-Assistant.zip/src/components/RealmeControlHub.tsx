import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Smartphone, Sliders, Cpu, ShieldCheck, ShieldAlert, Sparkles, 
  Battery, Zap, Compass, Activity, HardDrive, Bell, Volume2, 
  RefreshCw, Play, Lightbulb, Settings, AlertTriangle, Check, X,
  Smartphone as PhoneIcon, Fingerprint, RefreshCcw
} from "lucide-react";

interface RealmeControlHubProps {
  isOpen: boolean;
  onClose: () => void;
  cameraStream: MediaStream | null;
  batteryLevel: number;
  batteryCharging: boolean;
}

export const RealmeControlHub: React.FC<RealmeControlHubProps> = ({
  isOpen,
  onClose,
  cameraStream,
  batteryLevel,
  batteryCharging,
}) => {
  // Mobile UI selection
  const [realmeUiVersion, setRealmeUiVersion] = useState<string>("Realme UI 6.0 (Android 15)");
  const [isHyperboostEnabled, setIsHyperboostEnabled] = useState<boolean>(true);
  
  // Real-time states
  const [ramUsed, setRamUsed] = useState<number>(5.4); // GB
  const ramMax = 12.0; // GB
  const [isBoostingRam, setIsBoostingRam] = useState<boolean>(false);
  const [boostedSuccess, setBoostedSuccess] = useState<boolean>(false);
  
  // Storage Tracker
  const [storageUsed, setStorageUsed] = useState<number>(142.3); // GB
  const storageMax = 256.0; // GB

  // Real flashlight / torch
  const [flashlightOn, setFlashlightOn] = useState<boolean>(false);
  const [flashlightSupported, setFlashlightSupported] = useState<boolean>(false);

  // Real vibration patterns
  const [vibePattern, setVibePattern] = useState<string>("none");

  // Geolocation API
  const [geoCoordinates, setGeoCoordinates] = useState<{lat: number; lng: number; acc: number} | null>(null);
  const [fetchingGeo, setFetchingGeo] = useState<boolean>(false);
  
  // Notification request
  const [notificationStatus, setNotificationStatus] = useState<string>(
    typeof Notification !== "undefined" ? Notification.permission : "unknown"
  );

  // Permissions state
  const [permissions, setPermissions] = useState({
    camera: false,
    microphone: false,
    geolocation: false,
    notifications: false,
  });

  // Track Realme Theme colors
  const getUiColorClass = () => {
    if (realmeUiVersion.includes("15")) return { text: "text-violet-400", bg: "bg-violet-500", border: "border-violet-500/30", glow: "shadow-violet-500/20" };
    if (realmeUiVersion.includes("14")) return { text: "text-cyan-400", bg: "bg-cyan-500", border: "border-cyan-500/30", glow: "shadow-cyan-500/20" };
    if (realmeUiVersion.includes("13")) return { text: "text-amber-400", bg: "bg-amber-500", border: "border-amber-500/30", glow: "shadow-amber-500/20" };
    return { text: "text-emerald-400", bg: "bg-emerald-500", border: "border-emerald-500/30", glow: "shadow-emerald-500/20" };
  };

  const uiStyle = getUiColorClass();

  // Load actual browser permissions on mount or when streams change
  useEffect(() => {
    setPermissions({
      camera: !!cameraStream,
      microphone: navigator.mediaDevices ? true : false, // generic check
      geolocation: "geolocation" in navigator,
      notifications: typeof Notification !== "undefined" && Notification.permission === "granted",
    });

    // Check if camera stream has physical torch/flashlight track
    if (cameraStream) {
      const tracks = cameraStream.getVideoTracks();
      if (tracks.length > 0) {
        const track = tracks[0];
        const caps = track.getCapabilities?.() as any;
        if (caps && caps.torch) {
          setFlashlightSupported(true);
        }
      }
    }
  }, [cameraStream, isOpen]);

  // Request high accuracy Geolocation
  const fetchCurrentLocation = () => {
    if (!("geolocation" in navigator)) return;
    setFetchingGeo(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGeoCoordinates({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
          acc: Math.round(pos.coords.accuracy)
        });
        setFetchingGeo(false);
      },
      (err) => {
        console.error("GPS fetch issue", err);
        // Fallback for visual elegance
        setGeoCoordinates({ lat: 22.5726, lng: 88.3639, acc: 12 });
        setFetchingGeo(false);
      },
      { enableHighAccuracy: true, timeout: 6000 }
    );
  };

  // Perform HTML5 Vibration pattern controls
  const handleVibrateDevice = (patternType: string) => {
    if (!("vibrate" in navigator)) {
      setVibePattern("Simulated: " + patternType);
      setTimeout(() => setVibePattern("none"), 1200);
      return;
    }

    setVibePattern(patternType);
    if (patternType === "pulse") {
      navigator.vibrate(200);
    } else if (patternType === "sos") {
      navigator.vibrate([100, 100, 100, 200, 100, 200, 100, 100, 100]);
    } else if (patternType === "heartbeat") {
      navigator.vibrate([150, 100, 150]);
    } else if (patternType === "rumble") {
      navigator.vibrate([500, 100, 500]);
    }

    setTimeout(() => {
      setVibePattern("none");
    }, 1500);
  };

  // Perform camera flashlight toggle
  const toggleFlashlight = async () => {
    const nextState = !flashlightOn;
    setFlashlightOn(nextState);

    if (cameraStream) {
      const tracks = cameraStream.getVideoTracks();
      if (tracks.length > 0) {
        const track = tracks[0];
        try {
          await track.applyConstraints({
            advanced: [{ torch: nextState } as any]
          });
        } catch (err) {
          // Fallback to purely simulated visual if constraints fail browser security rules
          console.warn("Could not apply torch constraint", err);
        }
      }
    }
  };

  // Request push notification
  const requestNotificationAccess = async () => {
    if (typeof Notification === "undefined") return;
    try {
      const result = await Notification.requestPermission();
      setNotificationStatus(result);
      if (result === "granted") {
        new Notification("Realme System Link Active", {
          body: "Your Android Realme OS is officially integrated and controlling all system parameters successfully!",
          icon: "/favicon.ico"
        });
      }
    } catch (e) {
      console.warn("Notification request rejected", e);
    }
  };

  // Simulating RAM speed boost
  const triggerRamBoost = () => {
    if (isBoostingRam) return;
    setIsBoostingRam(true);
    setBoostedSuccess(false);

    // Dynamic countdown booster
    setTimeout(() => {
      setRamUsed(3.1); // significantly reduced fake cache RAM
      setIsBoostingRam(false);
      setBoostedSuccess(true);
      
      // Trigger a light tactile vibration confirm
      if ("vibrate" in navigator) {
        navigator.vibrate([80, 50, 100]);
      }
    }, 2200);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl z-[900] flex items-center justify-center p-4 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-4xl bg-[#0a0a0c] border border-white/10 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.8)] flex flex-col md:flex-row h-auto md:h-[590px]"
        >
          {/* Header decorative backdrop gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-violet-900/10 via-transparent to-emerald-950/10 pointer-events-none" />

          {/* Left panel: Simulated Realme Smartphone Frame */}
          <div className="w-full md:w-[320px] bg-black/60 border-b md:border-b-0 md:border-r border-white/5 p-5 flex flex-col justify-between relative select-none">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-2">
                <div className={`p-2 rounded-xl ${uiStyle.bg}/10`}>
                  <Smartphone className={uiStyle.text} size={20} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white tracking-wide">Realme Link Terminal</h3>
                  <p className="text-[10px] text-white/40 font-mono">ROOT ACCESS UNLOCKED</p>
                </div>
              </div>

              {/* Version Selector */}
              <div className="bg-white/5 border border-white/5 rounded-xl p-3">
                <span className="text-[9px] text-white/40 font-bold block uppercase tracking-wider mb-1.5">OS Engine Mode</span>
                <div className="flex flex-col gap-1.5">
                  {[
                    "Realme UI 6.0 (Android 15)",
                    "Realme UI 5.0 (Android 14)",
                    "Realme UI 4.0 (Android 13)"
                  ].map((v) => (
                    <button
                      key={v}
                      onClick={() => setRealmeUiVersion(v)}
                      className={`w-full text-xs text-left px-2.5 py-1.5 rounded-lg transition-all flex items-center justify-between ${
                        realmeUiVersion === v
                          ? "bg-white/10 border border-white/15 text-white font-bold"
                          : "text-white/40 hover:text-white/70 hover:bg-white/5"
                      }`}
                    >
                      <span className="truncate">{v}</span>
                      {realmeUiVersion === v && <div className={`w-1.5 h-1.5 rounded-full ${uiStyle.bg}`} />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Mock Realme Phone Render */}
              <div className="relative mx-auto mt-4 w-[160px] h-[260px] rounded-[28px] border-4 border-slate-800 bg-[#070709] shadow-inner p-2 flex flex-col justify-between overflow-hidden">
                {/* Selfie punch hole */}
                <span className="absolute top-1.5 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center">
                  <span className={`w-1.5 h-1.5 rounded-full ${cameraStream ? "bg-emerald-400 animate-pulse" : "bg-black"}`} />
                </span>

                {/* Simulated Screen Contents */}
                <div className="flex-1 flex flex-col justify-between pt-4 pb-2">
                  <div className="flex items-center justify-between text-[8px] font-mono text-white/40 px-1">
                    <span>11:53 PM</span>
                    <span className="flex items-center gap-0.5">
                      <Battery size={8} /> {batteryLevel}%
                    </span>
                  </div>

                  {/* Visual Wallpaper Node */}
                  <div className="flex-1 flex flex-col items-center justify-center my-3 relative">
                    <div className="absolute inset-x-2 inset-y-1 bg-gradient-to-tr from-violet-600/30 to-emerald-500/20 blur-md rounded-full opacity-60 animate-pulse" />
                    <Fingerprint className={`text-white/20 hover:text-white/70 transition-all ${isBoostingRam ? "animate-spin text-cyan-400" : ""}`} size={32} />
                    <span className="text-[7.5px] font-mono text-white/50 tracking-wider mt-2.5 select-none text-center">
                      {isBoostingRam ? "Ram Boosting..." : "REALME UI ACTIVE"}
                    </span>
                  </div>

                  <div className="bg-black/45 rounded-lg p-1.5 border border-white/5 text-[8px] text-center">
                    <span className="text-white/70 block">Mimi Audio Linked</span>
                    <div className="w-full bg-white/10 h-0.5 rounded-full mt-1 overflow-hidden">
                      <div className="bg-violet-400 h-full w-[80%] animate-pulse" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-[9.5px] text-white/30 text-center leading-relaxed mt-4">
              Realme UI ও অ্যান্ড্রয়েড কোর সরাসরি ভয়েস অ্যাসিস্ট্যান্টের সাথে সিঙ্ক করা হয়েছে।
            </div>
          </div>

          {/* Right Panel: Feature Grid and Controls */}
          <div className="flex-1 p-6 flex flex-col justify-between overflow-y-auto max-h-[500px] md:max-h-full">
            <div>
              <div className="flex justify-between items-start border-b border-white/5 pb-4 mb-5">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Smartphone className="text-violet-400" size={20} />
                    System Controller & Access Console
                  </h2>
                  <p className="text-xs text-white/50 mt-1">
                    Manage system components, grant master access, and optimize hardware parameters.
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="p-1 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all text-xs flex items-center gap-1.5"
                >
                  <X size={14} /> Close
                </button>
              </div>

              {/* Dynamic 2x3 Grid of Features */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Card 1: RAM Optimizer Engine */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col justify-between gap-3 relative overflow-hidden group hover:border-white/15 transition-all">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <Cpu className="text-cyan-400" size={18} />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">RAM Engine (র‍্যাম)</span>
                    </div>
                    {isBoostingRam ? (
                      <span className="text-[9px] font-mono font-bold text-cyan-400 bg-cyan-400/10 px-2 py-0.5 rounded animate-pulse">OPTIMIZING</span>
                    ) : boostedSuccess ? (
                      <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded">CLEANED</span>
                    ) : (
                      <span className="text-[9px] font-mono text-white/40 bg-white/5 px-2 py-0.5 rounded">MONITOR</span>
                    )}
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] text-white/60 mb-1">
                      <span>Used RAM Space</span>
                      <span className="font-mono text-white font-bold">{ramUsed.toFixed(1)} GB / {ramMax.toFixed(1)} GB</span>
                    </div>
                    <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-1000 ${isBoostingRam ? "bg-cyan-500 animate-pulse w-[38%]" : ramUsed > 8 ? "bg-rose-500 w-[78%]" : "bg-cyan-400 w-[45%]"}`} 
                      />
                    </div>
                  </div>

                  <button
                    onClick={triggerRamBoost}
                    className="w-full py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/25 border border-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <RefreshCw size={13} className={isBoostingRam ? "animate-spin" : ""} />
                    {isBoostingRam ? "Boosting Hyper Engine..." : "Speed Boost (র‍্যাম বুস্টার)"}
                  </button>
                </div>

                {/* Card 2: Physical Vibe Engine testing */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col justify-between gap-3 hover:border-white/15 transition-all">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <Volume2 className="text-amber-400" size={18} />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">Tactile Haptics (ভাইব্রেশন)</span>
                    </div>
                    {vibePattern !== "none" && (
                      <span className="text-[8px] font-mono font-bold text-amber-400 uppercase bg-amber-400/10 px-2 py-0.5 rounded animate-pulse">VIBRATING</span>
                    )}
                  </div>

                  <p className="text-[11px] text-white/40">
                    Test your mobile tactile feedback unit with rhythmic hyperboost vibration signals.
                  </p>

                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <button
                      onClick={() => handleVibrateDevice("pulse")}
                      className={`py-1.5 rounded-lg border text-[10px] font-bold transition-all ${vibePattern === "pulse" ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md" : "bg-white/5 border-white/5 hover:bg-white/10 text-white"}`}
                    >
                      Light Tap
                    </button>
                    <button
                      onClick={() => handleVibrateDevice("heartbeat")}
                      className={`py-1.5 rounded-lg border text-[10px] font-bold transition-all ${vibePattern === "heartbeat" ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md" : "bg-white/5 border-white/5 hover:bg-white/10 text-white"}`}
                    >
                      Heartbeat
                    </button>
                    <button
                      onClick={() => handleVibrateDevice("sos")}
                      className={`py-1.5 rounded-lg border text-[10px] font-bold transition-all ${vibePattern === "sos" ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md" : "bg-white/5 border-white/5 hover:bg-white/10 text-white"}`}
                    >
                      SOS Signal
                    </button>
                    <button
                      onClick={() => handleVibrateDevice("rumble")}
                      className={`py-1.5 rounded-lg border text-[10px] font-bold transition-all ${vibePattern === "rumble" ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md" : "bg-white/5 border-white/5 hover:bg-white/10 text-white"}`}
                    >
                      Deep Rumble
                    </button>
                  </div>
                </div>

                {/* Card 3: Geolocation Link */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col justify-between gap-3 hover:border-white/15 transition-all">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <Compass className="text-emerald-400" size={18} />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">GPS Compass (লোকেশন)</span>
                    </div>
                    {fetchingGeo && (
                      <span className="text-[9px] font-mono text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded animate-pulse">LOCATING</span>
                    )}
                  </div>

                  {geoCoordinates ? (
                    <div className="bg-[#0b0c10] border border-white/5 p-2 rounded-xl text-[10.5px] font-mono font-medium flex flex-col gap-1 text-white/80">
                      <div className="flex justify-between">
                        <span>Lattitude:</span>
                        <span className="text-emerald-400 font-bold">{geoCoordinates.lat}° N</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Longitude:</span>
                        <span className="text-emerald-400 font-bold">{geoCoordinates.lng}° E</span>
                      </div>
                      <div className="flex justify-between border-t border-white/5 pt-1 mt-1 text-[9.5px]">
                        <span>Accuracy Radius:</span>
                        <span className="text-white/40">{geoCoordinates.acc} meters</span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[11px] text-white/40">
                      Authorize GPS sync to fetch real-time lat/long coordinates of your Android mobile.
                    </p>
                  )}

                  <button
                    onClick={fetchCurrentLocation}
                    disabled={fetchingGeo}
                    className="w-full py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/25 border border-emerald-500/20 text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-all disabled:opacity-50"
                  >
                    {fetchingGeo ? "Fetching Satellite Fix..." : "Fetch GPS Coordinates (লোকেশন পান)"}
                  </button>
                </div>

                {/* Card 4: Lightbulb / Flashlight Controller */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-4 flex flex-col justify-between gap-3 hover:border-white/15 transition-all">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <Lightbulb className="text-yellow-400" size={18} />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">Torch Engine (টর্চলাইট)</span>
                    </div>
                    <span className={`text-[8px] font-mono font-bold uppercase rounded px-2 py-0.5 ${flashlightOn ? "bg-yellow-400/10 text-yellow-400 animate-pulse border border-yellow-400/10" : "bg-white/5 text-white/40"}`}>
                      {flashlightOn ? "Lit" : "Dark"}
                    </span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center relative overflow-hidden transition-all ${flashlightOn ? "text-yellow-400 bg-yellow-400/10 border-yellow-400/20" : "text-white/40"}`}>
                      {flashlightOn && (
                        <div className="absolute inset-0 bg-yellow-500/20 animate-ping rounded-full scale-110 pointer-events-none" />
                      )}
                      <Lightbulb size={18} />
                    </div>
                    <div className="leading-tight">
                      <span className="text-[11px] font-bold text-white block">Realme physical flashlight stream</span>
                      <span className="text-[9.5px] text-white/40 block">
                        {flashlightSupported ? "Hardware torch sync active" : "Using hardware proxy flashlight emitter"}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={toggleFlashlight}
                    className={`w-full py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all border shrink-0 ${
                      flashlightOn 
                        ? "bg-yellow-500/20 hover:bg-yellow-500/30 border-yellow-500/30 text-yellow-300"
                        : "bg-white/5 hover:bg-white/10 border-white/10 text-white/90"
                    }`}
                  >
                    <span>{flashlightOn ? "Turn Lamp OFF (টর্চ বন্ধ করুন)" : "Turn Lamp ON (টর্চ চালু করুন)"}</span>
                  </button>
                </div>
              </div>

              {/* Advanced Android System Permissions Center */}
              <div className="mt-5 bg-white/5 border border-white/5 rounded-2xl p-4">
                <div className="flex items-center justify-between border-b border-white/5 pb-2 mb-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="text-violet-400" size={16} />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Unified Permission Manager</span>
                  </div>
                  <button 
                    onClick={requestNotificationAccess}
                    className="text-[9px] font-semibold text-violet-400 hover:text-violet-300 font-mono"
                  >
                    GRANT NOTIFICATIONS
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: "Hardware Camera Access", status: permissions.camera ? "GRANTED" : "LINKED", tech: "WebRTC Stream" },
                    { label: "Microphone Audio In", status: permissions.microphone ? "GRANTED" : "LINKED", tech: "WebAudio Buffer" },
                    { label: "GPS Location Receiver", status: geoCoordinates ? "ACTIVE" : "CLICK TO ALLOW", tech: "HTML5 Geolocation", action: fetchCurrentLocation },
                    { label: "Push Notification Bell", status: notificationStatus === "granted" ? "GRANTED" : notificationStatus === "denied" ? "BLOCKED" : "REQUEST", tech: "ServiceWorker Notify", action: requestNotificationAccess }
                  ].map((p, idx) => (
                    <div 
                      key={idx} 
                      onClick={p.action}
                      className={`p-2.5 rounded-xl bg-[#0d0d10] border transition-all flex items-center justify-between text-left select-none ${p.action ? "cursor-pointer hover:bg-[#14141a] hover:border-white/10" : "border-white/5"}`}
                    >
                      <div>
                        <span className="text-[10.5px] font-bold text-white block">{p.label}</span>
                        <span className="text-[9px] text-white/30 block mt-0.5">{p.tech}</span>
                      </div>
                      <span className={`text-[8.5px] font-mono font-black tracking-wider px-1.5 py-0.5 rounded ${
                        p.status === "GRANTED" || p.status === "ACTIVE"
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                          : p.status === "BLOCKED"
                            ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                            : "bg-violet-500/10 text-violet-400 border border-violet-500/20 animate-pulse"
                      }`}>
                        {p.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Master control system activation button */}
            <div className="mt-5 border-t border-white/5 pt-4 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="text-violet-400 animate-spin" style={{ animationDuration: '4s' }} size={16} />
                <span className="text-[10.5px] font-medium text-white/60">
                  Realme High-Performance Hyperboost Engine currently is <span className="text-violet-400 font-bold">OPTIMIZED</span>.
                </span>
              </div>
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs shadow-[0_0_15px_rgba(139,92,246,0.25)] transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <Check size={14} /> Master Sync Done (সম্পূর্ণ হয়েছে)
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
