import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, X, Hand, MousePointer, HelpCircle, RefreshCw, Camera, Check, AlertCircle } from "lucide-react";

interface HandGestureTutorialProps {
  isOpen: boolean;
  onClose: () => void;
  isGestureActive: boolean;
  onToggleGestures?: () => void;
  cameraStream: MediaStream | null;
}

export const HandGestureTutorial: React.FC<HandGestureTutorialProps> = ({
  isOpen,
  onClose,
  isGestureActive,
  onToggleGestures,
  cameraStream
}) => {
  const [activeTab, setActiveTab] = useState<"tutorial" | "sandbox">("tutorial");
  const [practiceClicks, setPracticeClicks] = useState(0);
  const [hoverCount, setHoverCount] = useState(0);
  const [hasSucceeded, setHasSucceeded] = useState(false);

  const handlePracticeClick = () => {
    setPracticeClicks(prev => {
      const next = prev + 1;
      if (next >= 3) {
        setHasSucceeded(true);
      }
      return next;
    });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4 md:p-6 overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: "spring", duration: 0.5 }}
          className="relative w-full max-w-4xl bg-gradient-to-b from-[#0e0e12] to-[#040406] border border-cyan-500/30 rounded-[2.5rem] shadow-[0_0_50px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col md:flex-row"
        >
          {/* Top aesthetic progress glow */}
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-cyan-500 via-violet-500 to-fuchsia-500" />

          {/* Lateral Column: Graphic & Live Camera Status */}
          <div className="w-full md:w-[35%] bg-black/30 p-8 border-b md:border-b-0 md:border-r border-white/5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <Hand size={16} />
                </div>
                <span className="text-[10px] uppercase tracking-[0.25em] text-cyan-400 font-mono font-extrabold drop-shadow-[0_0_8px_rgba(34,211,238,0.3)]">
                  Neural Interface Unit
                </span>
              </div>

              <h2 className="text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r from-white via-cyan-100 to-cyan-300 tracking-tight leading-tight">
                Mimi Hand Gesture Guide
              </h2>
              <p className="text-xs text-white/60 mt-3 leading-relaxed">
                শুন্যে হাত নাড়িয়ে মিমির ভার্চুয়াল কার্সার কন্ট্রোল করুন এবং নোড সিলেক্ট করতে চমৎকার পিঞ্চ অঙ্গভঙ্গি ব্যবহার করুন।
              </p>
            </div>

            {/* Live Feed Simulator or State */}
            <div className="mt-8 md:mt-0 p-5 rounded-3xl bg-white/5 border border-white/5 relative overflow-hidden backdrop-blur-md">
              <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-cyan-500/10 blur-xl rounded-full" />
              
              <span className="text-[10px] font-mono text-cyan-400/80 font-bold block mb-2 uppercase">Camera Stream Status</span>
              <div className="flex items-center gap-3">
                <div className={`w-3.5 h-3.5 rounded-full ${cameraStream ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.7)]' : 'bg-red-500 animate-pulse'} `} />
                <span className="text-sm font-bold text-white leading-none">
                  {cameraStream ? "System online" : "Camera inactive"}
                </span>
              </div>

              <p className="text-[11px] text-white/50 mt-3.5 leading-snug">
                {cameraStream 
                  ? "আপনার ক্যামেরা সফলভাবে চালু আছে। নীচের ট্রায়াল জোনে হাত পরীক্ষা করুন।" 
                  : "ক্যামেরা চালু না থাকলে কার্সার ট্র্যাক হবে না। মেইন স্ক্রিনে Camera আইকন দিয়ে ভিডিও কল শুরু করুন।"}
              </p>

              {onToggleGestures && (
                <button
                  onClick={onToggleGestures}
                  className={`mt-4 w-full py-2 px-3 rounded-xl border text-xs font-bold font-mono uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    isGestureActive 
                      ? "bg-cyan-500/20 border-cyan-400 text-cyan-300"
                      : "bg-white/5 border-white/10 text-white/70 hover:bg-white/10"
                  }`}
                >
                  <Camera size={14} />
                  {isGestureActive ? "Disable Gestures" : "Enable Gestures"}
                </button>
              )}
            </div>
          </div>

          {/* Right Column: Menu Tabs & Training SandBox */}
          <div className="flex-1 p-6 md:p-8 flex flex-col justify-between">
            {/* Nav Close & Tabs selector */}
            <div className="flex justify-between items-center mb-6">
              <div className="flex bg-white/5 border border-white/10 p-1 rounded-2xl relative z-10 shrink-0">
                <button
                  onClick={() => setActiveTab("tutorial")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    activeTab === "tutorial" 
                      ? "bg-gradient-to-r from-cyan-500 to-violet-500 text-white shadow-md shadow-cyan-500/10" 
                      : "text-white/60 hover:text-white"
                  }`}
                >
                  Gestures (অঙ্গভঙ্গি)
                </button>
                <button
                  onClick={() => setActiveTab("sandbox")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeTab === "sandbox" 
                      ? "bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-md shadow-violet-500/10" 
                      : "text-white/60 hover:text-white"
                  }`}
                >
                  <Sparkles size={12} className={activeTab === "sandbox" ? "animate-spin text-white" : ""} />
                   بنگالی টেস্ট জোন
                </button>
              </div>

              <button
                onClick={onClose}
                className="p-2 bg-white/5 hover:bg-white/10 rounded-full border border-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
                title="Close"
              >
                <X size={18} />
              </button>
            </div>

            {/* TAB CONTENT */}
            <div className="flex-1 flex flex-col justify-center select-none">
              <AnimatePresence mode="wait">
                {activeTab === "tutorial" ? (
                  <motion.div
                    key="tutorial"
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-6 py-2"
                  >
                    {/* Gesture Card 1: Pointer */}
                    <div className="p-6 rounded-3xl bg-neutral-900/60 border border-white/5 shadow-xl hover:border-cyan-500/20 transition-all group relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 blur-xl group-hover:bg-cyan-500/10 transition-all rounded-full" />
                      
                      <div className="w-12 h-12 bg-cyan-500/10 rounded-2xl flex items-center justify-center text-cyan-400 mb-4 border border-cyan-500/20 group-hover:scale-110 transition-transform">
                        <MousePointer size={22} className="animate-pulse" />
                      </div>

                      <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 block mb-1">Gesture Phase 01</span>
                      <h3 className="text-base font-black text-white">
                        Move cursor (কার্সার মুভমেন্ট)
                      </h3>
                      
                      {/* SVG Animation for point */}
                      <div className="h-32 my-4 bg-black/40 rounded-2xl relative flex items-center justify-center overflow-hidden border border-white/5">
                        <motion.div
                          animate={{
                            x: [ -40, 40, -10, -40 ],
                            y: [ -10, 20, -30, -10 ]
                          }}
                          transition={{
                            duration: 6,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className="absolute flex flex-col items-center justify-center"
                        >
                          {/* Point indicator aura */}
                          <div className="w-8 h-8 rounded-full border border-cyan-400/40 bg-cyan-400/10 flex items-center justify-center animate-ping absolute -top-4" />
                          <div className="w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)] absolute -top-2" />
                          <svg className="w-12 h-12 text-white/80 fill-none stroke-current" strokeWidth="1.5" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M10.05 11.25H4.5m1.5-6h1.5a3 3 0 110 6H6m10.05-6V15a3 3 0 01-3 3h-3a3 3 0 01-3-3V5.25" />
                          </svg>
                        </motion.div>
                      </div>

                      <p className="text-xs text-white/70 leading-relaxed font-semibold">
                        ক্যামেরার সামনে আপনার <span className="text-cyan-400">তর্জনী আঙুল (Index Finger)</span> সোজা করে ধরুন এবং হাত ডানে-বামে নাড়ান। মিমির স্ক্রিনে একটি কণার মতো কার্সার আপনার হাতের সাথে ঘুরবে।
                      </p>
                    </div>

                    {/* Gesture Card 2: Pinch Action */}
                    <div className="p-6 rounded-3xl bg-neutral-900/60 border border-white/5 shadow-xl hover:border-violet-500/20 transition-all group relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-violet-500/5 blur-xl group-hover:bg-violet-500/10 transition-all rounded-full" />
                      
                      <div className="w-12 h-12 bg-violet-500/10 rounded-2xl flex items-center justify-center text-violet-400 mb-4 border border-violet-500/20 group-hover:scale-110 transition-transform">
                        <Sparkles size={22} className="text-violet-400" />
                      </div>

                      <span className="text-[10px] font-mono uppercase tracking-wider text-violet-400 block mb-1">Gesture Phase 02</span>
                      <h3 className="text-base font-black text-white">
                        Pinch to Click (ক্লিক করতে পিঞ্চ)
                      </h3>

                      {/* SVG Animation for pinch */}
                      <div className="h-32 my-4 bg-black/40 rounded-2xl relative flex items-center justify-center overflow-hidden border border-white/5">
                        {/* Interactive Click Sparkle */}
                        <motion.div
                          animate={{
                            scale: [ 1, 1.3, 0.8, 1 ],
                            opacity: [1, 0.2, 1, 1]
                          }}
                          transition={{ duration: 2.2, repeat: Infinity }}
                          className="absolute bg-white/5 w-20 h-20 rounded-full border border-violet-500/20 flex items-center justify-center"
                        />
                        <motion.div
                          animate={{
                            scale: [ 0, 1.8, 0, 0 ],
                            opacity: [ 0, 1, 0, 0 ]
                          }}
                          transition={{ duration: 2.2, repeat: Infinity }}
                          className="absolute w-12 h-12 rounded-full bg-violet-500/30 blur-sm pointer-events-none"
                        />
                        <motion.div
                          animate={{
                            scale: [ 1, 0.85, 1, 1 ],
                            y: [ 0, 5, 0, 0 ]
                          }}
                          transition={{ duration: 2.2, repeat: Infinity }}
                          className="relative flex flex-col items-center justify-center text-white/80"
                        >
                          <svg className="w-12 h-12 fill-none stroke-current" strokeWidth="1.5" viewBox="0 0 24 24">
                            {/* Simple dynamic hand illustration that pinches */}
                            <motion.path 
                              animate={{ d: [ 
                                "M8.5 14.5A2.5 2.5 0 0011 12c1.38 0 2.5 1.12 2.5 2.5", // Open path
                                "M11 11a1.5 1.5 0 011.5 1.5c0 .83-.67 1.5-1.5 1.5",   // Closed pinch path
                                "M8.5 14.5A2.5 2.5 0 0011 12c1.38 0 2.5 1.12 2.5 2.5",
                                "M8.5 14.5A2.5 2.5 0 0011 12c1.38 0 2.5 1.12 2.5 2.5"
                              ]}}
                              transition={{ duration: 2.2, repeat: Infinity }}
                              strokeLinecap="round" 
                              strokeLinejoin="round" 
                            />
                            {/* Thumb & Index meeting */}
                            <motion.path 
                              animate={{ d: [
                                "M4 6c1.5 0 2 2.5 2 4M14 6c-1.5 0-2 2.5-2 4",
                                "M4 6c2 1 2.5 3.5 4 4M14 6c-2 1-2.5 3.5-4 4",
                                "M4 6c1.5 0 2 2.5 2 4M14 6c-1.5 0-2 2.5-2 4",
                                "M4 6c1.5 0 2 2.5 2 4M14 6c-1.5 0-2 2.5-2 4"
                              ]}}
                              transition={{ duration: 2.2, repeat: Infinity }}
                              strokeLinecap="round"
                            />
                          </svg>
                        </motion.div>
                      </div>

                      <p className="text-xs text-white/70 leading-relaxed font-semibold">
                        অ্যাকশন বা বাটন ট্রিগার করতে আপনার <span className="text-violet-400">বৃদ্ধাঙ্গুলি (Thumb)</span> এবং <span className="text-violet-400">তর্জনী (Index Finger)</span> এর মাথাকে একত্রে কাছাকাছি আনুন। পিঞ্চ করলে Mimi সেখানে ক্লিক করবে।
                      </p>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="sandbox"
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className="flex flex-col gap-6 py-2 h-full"
                  >
                    <div className="bg-[#121216] border border-white/5 rounded-3xl p-6 relative overflow-hidden flex-1 flex flex-col justify-between">
                      {/* Grid background on sandbox */}
                      <div className="absolute inset-0 bg-[radial-gradient(#333_1px,transparent_1px)] [background-size:16px_16px] opacity-25 pointer-events-none" />

                      <div className="relative z-10">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono text-cyan-400 font-black tracking-widest uppercase">
                            Mimi Interactive Laboratory
                          </span>
                          <span className="text-[10px] bg-cyan-500/10 text-cyan-300 font-mono px-2 py-0.5 rounded border border-cyan-500/20">
                            PROTOTYPE STATUS: LIVE
                          </span>
                        </div>
                        <h3 className="text-lg font-black text-white">
                          হ্যান্ড জেসচার প্র্যাকটিস প্যাড (Bengali Sandbox)
                        </h3>
                        <p className="text-xs text-white/50 mt-1 lines-relaxed">
                          নীচের বাটনটিকে লক্ষ্য করে আপনার কার্সার আনুন এবং বৃদ্ধাঙ্গুলি ও তর্জনী দিয়ে একটি পিঞ্চ (Pinch) করুন। আপনি সরাসরি মাউস দিয়েও টার্গেটটি টেস্ট করতে পারেন।
                        </p>
                      </div>

                      {/* Interactive Sandbox Target Box */}
                      <div 
                        onMouseEnter={() => setHoverCount(prev => prev + 1)}
                        className="my-6 min-h-[160px] bg-black/50 border-2 border-dashed border-cyan-500/20 hover:border-cyan-500/40 rounded-2xl flex flex-col items-center justify-center p-6 transition-all duration-300 relative group"
                      >
                        {hasSucceeded && (
                          <div className="absolute inset-0 bg-cyan-950/90 backdrop-blur-md flex flex-col items-center justify-center text-center p-4 z-20 rounded-2xl animate-fade-in border border-cyan-400/30">
                            <div className="w-12 h-12 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 mb-2 animate-bounce">
                              <Check size={24} />
                            </div>
                            <h4 className="text-sm font-black text-white">উৎকৃষ্ট অনুশীলন! সফলভাবে সংযোগ সম্পন্ন।</h4>
                            <p className="text-[11px] text-white/70 mt-1">
                              আপনি Mimi Hand Gestures এর প্রাথমিক টেকনিক রপ্ত করেছেন।
                            </p>
                            <button
                              onClick={() => {
                                setPracticeClicks(0);
                                setHasSucceeded(false);
                              }}
                              className="mt-3 px-3 py-1 text-[10px] font-mono bg-cyan-500/20 text-cyan-300 rounded-lg hover:bg-cyan-500/35 border border-cyan-500/30 flex items-center gap-1 cursor-pointer"
                            >
                              <RefreshCw size={10} />
                              পুনরায় শুরু করুন
                            </button>
                          </div>
                        )}

                        <div className="flex gap-4">
                          <button
                            onClick={handlePracticeClick}
                            className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-violet-500 text-white hover:shadow-[0_0_20px_rgba(34,211,238,0.4)] transition-all font-black px-6 py-3.5 rounded-2xl border border-white/20 active:scale-95 shadow-xl text-xs flex items-center gap-2 cursor-pointer pointer-events-auto"
                          >
                            <Sparkles size={14} className="text-yellow-300 animate-pulse" />
                            পিঞ্চ অথবা প্রেস করুন (Target 01)
                          </button>
                        </div>

                        {/* Real-time statistics badge */}
                        <div className="flex gap-6 mt-6">
                          <div className="text-center">
                            <span className="block text-[10px] font-mono text-cyan-400 font-bold uppercase tracking-wider">Hover Count</span>
                            <span className="text-lg font-black text-white font-mono">{hoverCount}</span>
                          </div>
                          <div className="text-center border-l border-white/10 pl-6">
                            <span className="block text-[10px] font-mono text-violet-400 font-bold uppercase tracking-wider">Click Hits</span>
                            <span className="text-lg font-black text-white font-mono">{practiceClicks} / 3</span>
                          </div>
                        </div>

                        {/* Live instruction line */}
                        <p className="text-[10px] text-white/40 mt-4 italic font-sans flex items-center gap-1.5 justify-center">
                          <AlertCircle size={10} className="text-cyan-400" />
                          আপনার ল্যাপটপের ফ্রন্ট ক্যামেরা থেকে হাতের দূরত্ব প্রায় ২-৩ ফুট রাখুন।
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Bottom Panel Actions */}
            <div className="mt-6 pt-5 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
              <span className="text-[11px] text-white/40 flex items-center gap-2 font-mono">
                <HelpCircle size={14} className="text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
                System v2.4a · Neural Tracking Engine Live
              </span>

              <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
                {activeTab === "tutorial" ? (
                  <button
                    onClick={() => setActiveTab("sandbox")}
                    className="w-full sm:w-auto px-5 py-2.5 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-400/20 text-cyan-300 rounded-2xl text-xs font-bold transition-all cursor-pointer"
                  >
                    টেস্ট জোন ওপেন করুন (Open Sandbox)
                  </button>
                ) : (
                  <button
                    onClick={() => setActiveTab("tutorial")}
                    className="w-full sm:w-auto px-5 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 rounded-2xl text-xs font-bold transition-all cursor-pointer"
                  >
                    নির্দেশাবলী দেখুন (Learn more)
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-bold rounded-2xl text-xs hover:shadow-[0_0_15px_rgba(99,102,241,0.4)] active:scale-95 transition-all text-center cursor-pointer"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
