import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, Code, Cpu, ShieldCheck, Zap } from "lucide-react";

export type ActivityType = "idle" | "searching" | "coding" | "repairing" | "thinking";

export interface ActivityState {
  type: ActivityType;
  detail: string;
}

interface ActivityMonitorProps {
  activity: ActivityState;
  skin: "Tech" | "Minimal" | "Matrix";
}

export const ActivityMonitor: React.FC<ActivityMonitorProps> = ({ activity, skin }) => {
  if (activity.type === "idle") return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center">
      <AnimatePresence mode="wait">
        <motion.div
          key={activity.type + activity.detail}
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 1.05 }}
          className="bg-black/80 backdrop-blur-xl border border-cyan-500/30 p-6 rounded-3xl shadow-[0_0_50px_rgba(6,182,212,0.2)] flex flex-col items-center gap-4 max-w-sm text-center"
        >
          {/* Icon Animation */}
          <div className="relative">
            <div className="absolute inset-0 bg-cyan-500/20 blur-xl rounded-full animate-pulse" />
            <div className="relative p-4 bg-cyan-500/10 rounded-2xl border border-cyan-500/20 text-cyan-400">
              {activity.type === "searching" && <Search size={32} className="animate-bounce" />}
              {activity.type === "coding" && <Code size={32} className="animate-pulse" />}
              {activity.type === "repairing" && <ShieldCheck size={32} className="animate-spin" />}
              {activity.type === "thinking" && <Cpu size={32} className="animate-pulse" />}
            </div>
          </div>

          <div className="space-y-1">
            <h3 className="text-cyan-400 text-xs font-bold uppercase tracking-widest">
              {activity.type === "searching" ? "Kimi Neural Search" : 
               activity.type === "coding" ? "Kimi Auto-Coding" : 
               activity.type === "repairing" ? "Kimi Self-Healing" : "Processing"}
            </h3>
            <p className="text-white text-sm font-medium leading-relaxed italic">
              "{activity.detail}"
            </p>
          </div>

          {/* Progress Bar (Visual only) */}
          <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden mt-2">
            <motion.div 
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 2, repeat: Infinity }}
              className="h-full bg-cyan-500 shadow-[0_0_10px_#06b6d4]"
            />
          </div>

          {skin === "Matrix" && (
            <div className="absolute -inset-20 overflow-hidden opacity-10 pointer-events-none">
               <div className="whitespace-nowrap text-[8px] text-cyan-500 leading-none font-mono">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div key={i} className="animate-marquee">
                      010110101010101011010101010101010101101010101010110101010101010101011010101010101
                    </div>
                  ))}
               </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Decorative Corner Accents */}
      <div className="absolute top-10 left-10 w-24 h-24 border-t-2 border-l-2 border-cyan-500/20 rounded-tl-3xl" />
      <div className="absolute bottom-10 right-10 w-24 h-24 border-b-2 border-r-2 border-cyan-500/20 rounded-br-3xl" />
    </div>
  );
};
