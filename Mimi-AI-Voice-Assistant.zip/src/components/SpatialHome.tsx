import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  MessageSquare,
  Mail,
  MessageCircle,
  Image as ImageIcon,
  MapPin,
  Settings,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  X,
  LogIn,
  User as UserIcon,
  RefreshCcw,
  Layers,
  Cpu,
  Trash2,
  Sparkles,
} from "lucide-react";
import { User } from "firebase/auth";
import { HeroOrb3D, OrbAssistantState } from "./HeroOrb3D";
import { MimiWhatsAppWeb } from "./MimiWhatsAppWeb";
import { MimiYouTubePlayer } from "./MimiYouTubePlayer";
import { MimiChromeBrowser } from "./MimiChromeBrowser";
import { LiveConnectionStatus } from "../services/liveService";
import { ThemeSwitcherButton, HomeThemeMode } from "./ThemeSwitcherButton";
import { MapsModal } from "./MapsModal";

export interface SpatialChatMessage {
  id: string;
  sender: "user" | "mimi";
  text: string;
  url?: string;
  urlType?: "youtube" | "google" | "whatsapp" | "generic";
  query?: string;
  appName?: string;
  whatsappRecipient?: string;
  whatsappPhone?: string;
  whatsappMessage?: string;
}

interface SpatialHomeProps {
  appState: OrbAssistantState;
  isSessionActive: boolean;
  connectionStatus: LiveConnectionStatus;
  isMuted: boolean;
  messages: SpatialChatMessage[];
  user: User | null;
  preferences: Record<string, any>;
  onToggleListening: () => void;
  onToggleMute: () => void;
  onSendText: (text: string) => void;
  onClearChat: () => void;
  onOpenGmail: () => void;
  onOpenPhotos: () => void;
  onOpenSettings: () => void;
  onOpenWorkspaceHub: () => void;
  onOpenSensingHub: () => void;
  onLogin: () => void;
  onLogout: () => void;
  onHardReboot: () => void;
  onSelectTheme: (theme: HomeThemeMode) => void;
}

interface OrbitFeatureDef {
  id: "chat" | "gmail" | "whatsapp" | "photos" | "maps" | "settings";
  label: string;
  subtitle: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  image: string;
  accentHex: string;
  glowRgba: string;
  borderClass: string;
  iconBgClass: string;
  textAccentClass: string;
  onSelect: () => void;
}

const IMAGE_ASSETS = {
  cyberServer: "/src/assets/images/cyber_server_3d_1782212696592.jpg",
  quantumCore: "/src/assets/images/quantum_server_core_1782213904440.jpg",
  colorfulCore: "/src/assets/images/colorful_3d_core_1782217293823.jpg",
  smartStep: "/src/assets/images/gemini_smart_step_3d_1795524240426.jpg",
};

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState<boolean>(() => {
    if (typeof window === "undefined" || !window.matchMedia) return false;
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  });

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  return reduced;
}

interface OrbitFeatureCardProps {
  feature: OrbitFeatureDef;
  index: number;
  reducedMotion: boolean;
  isDesktopOrbit: boolean;
  orbitStyle?: React.CSSProperties;
  onHoverChange?: (hovered: boolean) => void;
}

const OrbitFeatureCard: React.FC<OrbitFeatureCardProps> = ({
  feature,
  index,
  reducedMotion,
  isDesktopOrbit,
  orbitStyle,
  onHoverChange,
}) => {
  const cardRef = useRef<HTMLButtonElement | null>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0, active: false });

  const Icon = feature.icon;

  const updatePointerTilt = (clientX: number, clientY: number) => {
    const el = cardRef.current;
    if (!el || reducedMotion) return;
    const rect = el.getBoundingClientRect();
    const nx = ((clientX - rect.left) / Math.max(rect.width, 1)) * 2 - 1;
    const ny = ((clientY - rect.top) / Math.max(rect.height, 1)) * 2 - 1;
    setTilt({
      rx: -ny * 13,
      ry: nx * 13,
      active: true,
    });
  };

  const resetTilt = () => {
    setTilt({ rx: 0, ry: 0, active: false });
    onHoverChange?.(false);
  };

  const transformString = reducedMotion
    ? "none"
    : tilt.active
      ? `perspective(850px) rotateX(${tilt.rx.toFixed(2)}deg) rotateY(${tilt.ry.toFixed(2)}deg) translateZ(24px) scale(1.06)`
      : "perspective(850px) rotateX(0deg) rotateY(0deg) translateZ(0px) scale(1)";

  return (
    <motion.div
      initial={reducedMotion ? false : { opacity: 0, scale: 0.78, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={
        reducedMotion
          ? { duration: 0 }
          : {
              delay: 0.42 + index * 0.085,
              duration: 0.55,
              ease: [0.22, 1, 0.36, 1],
            }
      }
      style={isDesktopOrbit ? orbitStyle : undefined}
      className={isDesktopOrbit ? "absolute z-20 -translate-x-1/2 -translate-y-1/2" : "w-full"}
    >
      <button
        ref={cardRef}
        type="button"
        onClick={feature.onSelect}
        onPointerEnter={(e) => {
          onHoverChange?.(true);
          updatePointerTilt(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => updatePointerTilt(e.clientX, e.clientY)}
        onPointerLeave={resetTilt}
        onTouchStart={(e) => {
          onHoverChange?.(true);
          if (e.touches[0]) {
            updatePointerTilt(e.touches[0].clientX, e.touches[0].clientY);
          }
        }}
        onTouchEnd={resetTilt}
        style={{
          transform: transformString,
          boxShadow: tilt.active
            ? `0 18px 42px rgba(2, 6, 23, 0.75), 0 0 28px ${feature.glowRgba}, inset 0 1px 1px rgba(255,255,255,0.28)`
            : `0 10px 26px rgba(2, 6, 23, 0.65), 0 0 16px rgba(15, 23, 42, 0.4), inset 0 1px 1px rgba(255,255,255,0.14)`,
        }}
        className={`group relative overflow-hidden rounded-2xl border ${feature.borderClass} bg-[#080d24]/70 backdrop-blur-xl text-left transition-[transform,box-shadow,border-color] duration-200 ease-out focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 cursor-pointer select-none ${
          isDesktopOrbit ? "w-44 px-3.5 py-3" : "w-full min-h-[66px] px-3 py-2.5"
        }`}
      >
        {/* Subtle layered 3D asset artwork with dark glass contrast scrim */}
        <img
          src={feature.image}
          alt=""
          aria-hidden="true"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-22 group-hover:opacity-38 transition-opacity duration-300 pointer-events-none scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#060a1e]/85 via-[#070b22]/75 to-[#0b102e]/85 pointer-events-none" />
        <div
          className="absolute -right-5 -top-5 w-20 h-20 rounded-full blur-2xl opacity-30 group-hover:opacity-65 transition-opacity duration-300 pointer-events-none"
          style={{ backgroundColor: feature.accentHex }}
        />

        <div className="relative z-10 flex items-center gap-3">
          <div
            className={`w-10 h-10 shrink-0 rounded-xl border border-white/15 flex items-center justify-center shadow-inner transition-transform duration-300 group-hover:scale-110 ${feature.iconBgClass}`}
          >
            <Icon size={19} className={feature.textAccentClass} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-bold tracking-wide text-white leading-tight truncate">
              {feature.label}
            </div>
            <div className="text-[11px] font-medium text-slate-300/85 truncate mt-0.5">
              {feature.subtitle}
            </div>
          </div>
        </div>
      </button>
    </motion.div>
  );
};

export const SpatialHome: React.FC<SpatialHomeProps> = ({
  appState,
  isSessionActive,
  connectionStatus,
  isMuted,
  messages,
  user,
  preferences,
  onToggleListening,
  onToggleMute,
  onSendText,
  onClearChat,
  onOpenGmail,
  onOpenPhotos,
  onOpenSettings,
  onOpenWorkspaceHub,
  onOpenSensingHub,
  onLogin,
  onLogout,
  onHardReboot,
  onSelectTheme,
}) => {
  const reducedMotion = usePrefersReducedMotion();
  const stageRef = useRef<HTMLDivElement | null>(null);

  const [stageSize, setStageSize] = useState({ width: 1200, height: 800 });
  const [orbitAngle, setOrbitAngle] = useState(0);
  const [isAnyCardHovered, setIsAnyCardHovered] = useState(false);

  // Feature modal states for Chat, WhatsApp & Maps
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatDraft, setChatDraft] = useState("");
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);

  const [isMapsOpen, setIsMapsOpen] = useState(false);

  // Track stage dimensions for responsive orbital ring placement
  useEffect(() => {
    const updateSize = () => {
      if (stageRef.current) {
        setStageSize({
          width: stageRef.current.clientWidth,
          height: stageRef.current.clientHeight,
        });
      } else {
        setStageSize({ width: window.innerWidth, height: window.innerHeight });
      }
    };
    updateSize();
    window.addEventListener("resize", updateSize);
    return () => window.removeEventListener("resize", updateSize);
  }, []);

  const isDesktopOrbit = stageSize.width >= 768 && stageSize.height >= 600;

  // Smooth slow orbital ring rotation on desktop (paused on hover or reduced-motion)
  useEffect(() => {
    if (!isDesktopOrbit || reducedMotion || isAnyCardHovered) return;
    let rafId = 0;
    let prev = performance.now();

    const step = (now: number) => {
      const dt = Math.min((now - prev) / 1000, 0.05);
      prev = now;
      setOrbitAngle((a) => (a + dt * 0.075) % (Math.PI * 2));
      rafId = requestAnimationFrame(step);
    };

    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [isDesktopOrbit, reducedMotion, isAnyCardHovered]);

  // Scroll chat drawer to bottom when opened or new messages arrive
  useEffect(() => {
    if (isChatOpen) {
      chatBottomRef.current?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth" });
    }
  }, [isChatOpen, messages, reducedMotion]);

  const features: OrbitFeatureDef[] = useMemo(
    () => [
      {
        id: "chat",
        label: "Chat",
        subtitle: `${messages.length} messages`,
        icon: MessageSquare,
        image: IMAGE_ASSETS.smartStep,
        accentHex: "#00f0ff",
        glowRgba: "rgba(0, 240, 255, 0.36)",
        borderClass: "border-cyan-400/35 hover:border-cyan-300/80",
        iconBgClass: "bg-cyan-500/20",
        textAccentClass: "text-cyan-300",
        onSelect: () => setIsChatOpen(true),
      },
      {
        id: "gmail",
        label: "Gmail",
        subtitle: "Inbox & Mail Hub",
        icon: Mail,
        image: IMAGE_ASSETS.colorfulCore,
        accentHex: "#ff2a85",
        glowRgba: "rgba(255, 42, 133, 0.36)",
        borderClass: "border-pink-400/35 hover:border-pink-300/80",
        iconBgClass: "bg-pink-500/20",
        textAccentClass: "text-pink-300",
        onSelect: onOpenGmail,
      },
      {
        id: "whatsapp",
        label: "WhatsApp",
        subtitle: "Direct Messaging",
        icon: MessageCircle,
        image: IMAGE_ASSETS.quantumCore,
        accentHex: "#10ff9c",
        glowRgba: "rgba(16, 255, 156, 0.34)",
        borderClass: "border-emerald-400/35 hover:border-emerald-300/80",
        iconBgClass: "bg-emerald-500/20",
        textAccentClass: "text-emerald-300",
        onSelect: () => setIsWhatsAppOpen(true),
      },
      {
        id: "photos",
        label: "Photos",
        subtitle: "Media & Albums",
        icon: ImageIcon,
        image: IMAGE_ASSETS.cyberServer,
        accentHex: "#ffb800",
        glowRgba: "rgba(255, 184, 0, 0.34)",
        borderClass: "border-amber-400/35 hover:border-amber-300/80",
        iconBgClass: "bg-amber-500/20",
        textAccentClass: "text-amber-300",
        onSelect: onOpenPhotos,
      },
      {
        id: "maps",
        label: "Maps",
        subtitle: "Routes & Places",
        icon: MapPin,
        image: IMAGE_ASSETS.smartStep,
        accentHex: "#38bdf8",
        glowRgba: "rgba(56, 189, 248, 0.36)",
        borderClass: "border-sky-400/35 hover:border-sky-300/80",
        iconBgClass: "bg-sky-500/20",
        textAccentClass: "text-sky-300",
        onSelect: () => setIsMapsOpen(true),
      },
      {
        id: "settings",
        label: "Settings",
        subtitle: "Voice & Core",
        icon: Settings,
        image: IMAGE_ASSETS.quantumCore,
        accentHex: "#8b5cf6",
        glowRgba: "rgba(139, 92, 246, 0.38)",
        borderClass: "border-violet-400/35 hover:border-violet-300/80",
        iconBgClass: "bg-violet-500/20",
        textAccentClass: "text-violet-300",
        onSelect: onOpenSettings,
      },
    ],
    [messages.length, onOpenGmail, onOpenPhotos, onOpenSettings]
  );

  // Elliptical orbital radii for desktop ring
  const rx = Math.min(370, Math.max(245, stageSize.width * 0.31));
  const ry = Math.min(205, Math.max(150, stageSize.height * 0.25));

  // Connection badge styling
  const connBadge =
    connectionStatus === "connected"
      ? {
          label: "Connected",
          dotClass: "bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.95)]",
          pillClass: "border-emerald-400/35 bg-emerald-950/50 text-emerald-200",
        }
      : connectionStatus === "connecting"
        ? {
            label: "Connecting",
            dotClass: "bg-amber-400 shadow-[0_0_10px_rgba(251,191,36,0.95)]",
            pillClass: "border-amber-400/35 bg-amber-950/50 text-amber-200",
          }
        : {
            label: "Disconnected",
            dotClass: "bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.95)]",
            pillClass: "border-red-400/35 bg-red-950/50 text-red-200",
          };

  const stateLabel =
    appState === "listening"
      ? "Listening — Speak freely"
      : appState === "processing"
        ? "Thinking — Neural Core active"
        : appState === "speaking"
          ? "Speaking — Live Audio"
          : appState === "upgrading"
            ? "Upgrading Core"
            : "Ready — Tap Mic to talk";

  const latestMessage = messages.length > 0 ? messages[messages.length - 1] : null;
  const latestWhatsAppMsg = [...messages].reverse().find((m) => m.urlType === "whatsapp");

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatDraft.trim()) return;
    onSendText(chatDraft.trim());
    setChatDraft("");
  };

  return (
    <div className="relative h-[100dvh] w-screen overflow-hidden bg-[#040716] text-white select-none flex flex-col justify-between">
      {/* Deep Navy-Black Slowly Moving Gradient & Layered Visual Depth */}
      <div aria-hidden="true" className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute -inset-24 spatial-nebula-a opacity-55"
          style={{
            background:
              "radial-gradient(circle at 22% 28%, rgba(0, 240, 255, 0.16), transparent 46%), radial-gradient(circle at 78% 72%, rgba(139, 92, 246, 0.22), transparent 50%)",
          }}
        />
        <div
          className="absolute -inset-24 spatial-nebula-b opacity-45"
          style={{
            background:
              "radial-gradient(circle at 75% 24%, rgba(255, 42, 133, 0.15), transparent 44%), radial-gradient(circle at 28% 78%, rgba(255, 184, 0, 0.12), transparent 48%)",
          }}
        />
        {/* Soft translucent local 3D core background shimmer */}
        <img
          src={IMAGE_ASSETS.cyberServer}
          alt=""
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-[0.06] mix-blend-screen scale-105"
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,#030512_92%)]" />
      </div>

      {/* Top Glass Header Bar */}
      <header className="relative z-30 w-full flex items-center justify-between gap-3 px-4 py-3 md:px-8 md:py-4 bg-gradient-to-b from-[#030512]/80 to-transparent backdrop-blur-[3px] shrink-0">
        {/* Brand Emblem */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative w-10 h-10 md:w-11 md:h-11 rounded-xl p-[2px] bg-gradient-to-tr from-cyan-400 via-pink-500 to-amber-400 shadow-[0_0_20px_rgba(0,240,255,0.35)] shrink-0">
            <div className="w-full h-full rounded-[10px] overflow-hidden bg-[#060a1f]">
              <img
                src={IMAGE_ASSETS.colorfulCore}
                alt="Mimi 3D Neural Core"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
          <div className="min-w-0">
            <h1 className="text-lg md:text-xl font-black tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 via-violet-300 to-amber-300 leading-none">
              MIMI 3D
            </h1>
            <p className="text-[11px] font-mono text-slate-300/75 tracking-wider truncate mt-0.5">
              {preferences.name ? `Hi, ${preferences.name}` : "Spatial Neural Core"}
            </p>
          </div>
        </div>

        {/* Top-Right Controls & Connection Indicator */}
        <div className="flex items-center gap-2 md:gap-2.5 shrink-0">
          {/* Small Connection Indicator in Top Corner (Green/Yellow/Red + Text Label) */}
          <div
            role="status"
            aria-label={`Voice connection status: ${connBadge.label}`}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full border backdrop-blur-md text-xs font-semibold tracking-wide shadow-md ${connBadge.pillClass}`}
          >
            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${connBadge.dotClass}`} />
            <span>{connBadge.label}</span>
          </div>

          {/* Switch Theme Dropdown (Classic / Neural 3D / Claude Style) */}
          <ThemeSwitcherButton
            currentTheme="3d"
            onSelectTheme={onSelectTheme}
            variant="space"
          />

          {/* Login / Profile */}
          {user ? (
            <button
              type="button"
              onClick={onLogout}
              title="Signed in — click to logout"
              className="min-h-[40px] min-w-[40px] p-1.5 rounded-full bg-white/8 hover:bg-white/15 border border-violet-400/35 flex items-center gap-2 transition-colors cursor-pointer"
            >
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || "Profile"}
                  className="w-7 h-7 rounded-full object-cover"
                />
              ) : (
                <UserIcon size={17} className="text-violet-300 mx-1" />
              )}
            </button>
          ) : (
            <button
              type="button"
              onClick={onLogin}
              className="min-h-[40px] px-3 py-1.5 rounded-xl bg-white/8 hover:bg-white/15 border border-white/15 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <LogIn size={15} className="text-cyan-300" />
              <span className="hidden sm:inline">Login</span>
            </button>
          )}

          <button
            type="button"
            onClick={onHardReboot}
            title="Reboot Neural Link"
            aria-label="Reboot Neural Link"
            className="hidden sm:flex min-h-[40px] min-w-[40px] items-center justify-center rounded-full bg-white/8 hover:bg-white/15 border border-white/15 text-cyan-300 transition-colors cursor-pointer"
          >
            <RefreshCcw size={16} />
          </button>
        </div>
      </header>

      {/* Main Spatial Hero Stage */}
      <main
        ref={stageRef}
        className="relative flex-1 w-full flex flex-col items-center justify-center overflow-hidden"
      >
        {/* 3D Hero Orb Layer */}
        <div
          className={
            isDesktopOrbit
              ? "absolute inset-0 pointer-events-none"
              : "relative w-full h-[38vh] min-h-[210px] max-h-[300px] shrink-0 pointer-events-none"
          }
        >
          <HeroOrb3D appState={appState} reducedMotion={reducedMotion} />

          {/* Soft SVG Orbital Ring Guide on Desktop */}
          {isDesktopOrbit && (
            <svg
              aria-hidden="true"
              className="absolute inset-0 w-full h-full pointer-events-none opacity-45"
            >
              <defs>
                <linearGradient id="spatialRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00f0ff" stopOpacity="0.55" />
                  <stop offset="35%" stopColor="#8b5cf6" stopOpacity="0.45" />
                  <stop offset="70%" stopColor="#ff2a85" stopOpacity="0.45" />
                  <stop offset="100%" stopColor="#ffb800" stopOpacity="0.55" />
                </linearGradient>
              </defs>
              <ellipse
                cx={stageSize.width / 2}
                cy={stageSize.height * 0.47}
                rx={rx}
                ry={ry}
                fill="none"
                stroke="url(#spatialRingGrad)"
                strokeWidth="1.25"
                strokeDasharray="6 8"
              />
            </svg>
          )}
        </div>

        {/* Live Status Pill (top-center of stage, out of orb's way) */}
        <div
          className={`${
            isDesktopOrbit ? "absolute top-2 left-1/2 -translate-x-1/2" : "relative -mt-2 mb-2"
          } z-20 flex flex-col items-center gap-1.5 pointer-events-none px-4`}
        >
          <div className="px-4 py-1.5 rounded-full bg-[#090f2b]/75 border border-white/15 backdrop-blur-xl shadow-lg flex items-center gap-2 text-xs font-semibold text-slate-100">
            <Sparkles
              size={14}
              className={
                appState === "listening"
                  ? "text-emerald-300"
                  : appState === "processing"
                    ? "text-pink-300"
                    : appState === "speaking"
                      ? "text-amber-300"
                      : "text-cyan-300"
              }
            />
            <span>{stateLabel}</span>
          </div>
          {latestMessage && (
            <p className="max-w-md text-center text-xs text-slate-200/90 bg-[#060a1e]/70 border border-white/10 rounded-xl px-3.5 py-1.5 backdrop-blur-md line-clamp-1">
              <span className="text-cyan-300 font-semibold mr-1.5">
                {latestMessage.sender === "mimi" ? "Mimi:" : "You:"}
              </span>
              {latestMessage.text}
            </p>
          )}
        </div>

        {/* 6 Orbiting Glassmorphism Feature Cards */}
        {isDesktopOrbit ? (
          <div className="absolute inset-0 pointer-events-none">
            {features.map((feat, idx) => {
              const angle = orbitAngle + (idx * Math.PI * 2) / features.length - Math.PI / 2;
              const cx = stageSize.width / 2 + Math.cos(angle) * rx;
              const cy = stageSize.height * 0.47 + Math.sin(angle) * ry;
              return (
                <div key={feat.id} className="pointer-events-auto">
                  <OrbitFeatureCard
                    feature={feat}
                    index={idx}
                    reducedMotion={reducedMotion}
                    isDesktopOrbit={true}
                    orbitStyle={{ left: `${cx}px`, top: `${cy}px` }}
                    onHoverChange={setIsAnyCardHovered}
                  />
                </div>
              );
            })}
          </div>
        ) : (
          <div className="relative z-20 w-full max-w-md px-4 pb-2 overflow-y-auto scrollbar-hide">
            <div className="grid grid-cols-2 gap-2.5">
              {features.map((feat, idx) => (
                <OrbitFeatureCard
                  key={feat.id}
                  feature={feat}
                  index={idx}
                  reducedMotion={reducedMotion}
                  isDesktopOrbit={false}
                />
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Bottom Center Microphone Dock */}
      <footer className="relative z-30 w-full flex flex-col items-center justify-center pb-5 pt-2 px-4 shrink-0">
        <div className="flex items-center justify-center gap-3 md:gap-5 px-5 py-2.5 rounded-full bg-[#070c22]/75 border border-white/15 backdrop-blur-2xl shadow-[0_12px_40px_rgba(0,0,0,0.65)]">
          {/* Quick Chat Drawer Trigger */}
          <button
            type="button"
            onClick={() => setIsChatOpen(true)}
            aria-label="Open Chat Drawer"
            title="Chat with Mimi"
            className="min-h-[44px] min-w-[44px] rounded-full bg-white/8 hover:bg-cyan-500/20 border border-white/15 hover:border-cyan-400/50 flex items-center justify-center text-cyan-300 transition-colors cursor-pointer"
          >
            <MessageSquare size={19} />
          </button>

          {/* Mute / Unmute */}
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={isMuted ? "Unmute voice output" : "Mute voice output"}
            title={isMuted ? "Unmute Audio" : "Mute Audio"}
            className={`min-h-[44px] min-w-[44px] rounded-full border flex items-center justify-center transition-colors cursor-pointer ${
              isMuted
                ? "bg-red-500/20 border-red-400/45 text-red-300"
                : "bg-white/8 hover:bg-white/15 border-white/15 text-slate-200"
            }`}
          >
            {isMuted ? <VolumeX size={19} /> : <Volume2 size={19} />}
          </button>

          {/* Large Round Bottom-Center Microphone Button with Pulsing Ring while Listening */}
          <div className="relative flex items-center justify-center mx-1">
            {(isSessionActive || appState === "listening") && !reducedMotion && (
              <>
                <span
                  aria-hidden="true"
                  className="absolute -inset-2 rounded-full border-2 border-emerald-400/70 animate-ping"
                  style={{ animationDuration: "1.8s" }}
                />
                <span
                  aria-hidden="true"
                  className="absolute -inset-3.5 rounded-full border border-cyan-400/45 animate-pulse"
                />
              </>
            )}
            <button
              type="button"
              onClick={onToggleListening}
              aria-label={isSessionActive ? "Stop voice conversation" : "Start voice conversation"}
              title={isSessionActive ? "End Voice Session" : "Start Voice Session"}
              className={`relative z-10 w-16 h-16 md:w-[72px] md:h-[72px] rounded-full flex items-center justify-center border-2 transition-all duration-300 active:scale-95 cursor-pointer ${
                isSessionActive
                  ? "bg-gradient-to-tr from-emerald-500 via-cyan-500 to-teal-400 border-white/60 text-slate-950 shadow-[0_0_34px_rgba(16,255,156,0.6)]"
                  : "bg-gradient-to-tr from-cyan-500 via-violet-500 to-fuchsia-500 border-white/35 text-white shadow-[0_0_28px_rgba(139,92,246,0.5)] hover:scale-105"
              }`}
            >
              {isSessionActive ? <MicOff size={26} /> : <Mic size={26} />}
            </button>
          </div>

          {/* Sensing Hub (Camera / Screen / Video Call) */}
          <button
            type="button"
            onClick={onOpenSensingHub}
            aria-label="Open Camera & Screen Sensing Hub"
            title="Camera, Screen & Video Call"
            className="min-h-[44px] min-w-[44px] rounded-full bg-white/8 hover:bg-violet-500/20 border border-white/15 hover:border-violet-400/50 flex items-center justify-center text-violet-300 transition-colors cursor-pointer"
          >
            <Cpu size={19} />
          </button>

          {/* Workspace Hub */}
          <button
            type="button"
            onClick={onOpenWorkspaceHub}
            aria-label="Open Workspace Hub"
            title="Workspace Hub"
            className="min-h-[44px] min-w-[44px] rounded-full bg-white/8 hover:bg-pink-500/20 border border-white/15 hover:border-pink-400/50 flex items-center justify-center text-pink-300 transition-colors cursor-pointer"
          >
            <Layers size={19} />
          </button>
        </div>
      </footer>

      {/* 1. Interactive Chat Glass Drawer */}
      <AnimatePresence>
        {isChatOpen && (
          <motion.div
            initial={reducedMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-end p-3 md:p-6"
            onClick={() => setIsChatOpen(false)}
          >
            <motion.div
              initial={reducedMotion ? false : { x: 40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={reducedMotion ? undefined : { x: 40, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md h-[85vh] rounded-3xl bg-[#070c22]/92 border border-cyan-400/30 backdrop-blur-2xl shadow-[0_24px_64px_rgba(0,0,0,0.85)] flex flex-col overflow-hidden"
            >
              <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
                    <MessageSquare size={18} />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white leading-tight">Mimi Neural Chat</h2>
                    <p className="text-xs text-slate-300/75">Ask questions, search, or launch commands</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {messages.length > 0 && (
                    <button
                      type="button"
                      onClick={onClearChat}
                      title="Clear conversation"
                      aria-label="Clear conversation"
                      className="min-h-[38px] min-w-[38px] rounded-xl bg-white/5 hover:bg-red-500/20 border border-white/10 text-slate-300 hover:text-red-300 flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <Trash2 size={15} />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setIsChatOpen(false)}
                    aria-label="Close Chat Drawer"
                    className="min-h-[38px] min-w-[38px] rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-slate-200 flex items-center justify-center transition-colors cursor-pointer"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-hide">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center px-6 gap-3">
                    <img
                      src={IMAGE_ASSETS.smartStep}
                      alt="Mimi AI Core"
                      className="w-24 h-24 rounded-2xl object-cover border border-cyan-400/35 shadow-lg"
                      referrerPolicy="no-referrer"
                    />
                    <p className="text-sm font-semibold text-white">Start a conversation with Mimi</p>
                    <p className="text-xs text-slate-300/80">
                      Type below or tap the center microphone button to speak naturally.
                    </p>
                  </div>
                ) : (
                  messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${
                        msg.sender === "user" ? "items-end" : "items-start"
                      }`}
                    >
                      <div
                        className={`max-w-[88%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed border ${
                          msg.sender === "user"
                            ? "bg-gradient-to-br from-cyan-500/25 to-violet-500/25 border-cyan-400/35 text-white"
                            : "bg-white/8 border-white/12 text-slate-100"
                        }`}
                      >
                        <p className="whitespace-pre-wrap">{msg.text}</p>
                        {msg.url && msg.urlType === "youtube" && msg.query && (
                          <div className="mt-2">
                            <MimiYouTubePlayer query={msg.query} url={msg.url} />
                          </div>
                        )}
                        {msg.url && msg.urlType === "google" && msg.query && (
                          <div className="mt-2">
                            <MimiChromeBrowser query={msg.query} url={msg.url} />
                          </div>
                        )}
                        {msg.url && msg.urlType === "whatsapp" && (
                          <div className="mt-2">
                            <MimiWhatsAppWeb
                              recipient={msg.whatsappRecipient || "Contact"}
                              phone={msg.whatsappPhone}
                              message={msg.whatsappMessage || ""}
                              url={msg.url}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
                <div ref={chatBottomRef} />
              </div>

              <form
                onSubmit={handleChatSubmit}
                className="p-3 border-t border-white/10 bg-[#050819]/90 flex items-center gap-2"
              >
                <input
                  type="text"
                  value={chatDraft}
                  onChange={(e) => setChatDraft(e.target.value)}
                  placeholder="Message Mimi..."
                  className="flex-1 min-h-[44px] rounded-xl bg-white/8 border border-white/15 px-3.5 text-sm text-white placeholder:text-slate-400 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="submit"
                  disabled={!chatDraft.trim()}
                  aria-label="Send message"
                  className="min-h-[44px] min-w-[44px] rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-500 disabled:opacity-45 text-white flex items-center justify-center shadow-md cursor-pointer"
                >
                  <Send size={17} />
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. WhatsApp Hub Modal (hosts existing MimiWhatsAppWeb cleanly) */}
      <AnimatePresence>
        {isWhatsAppOpen && (
          <motion.div
            initial={reducedMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-3 md:p-6"
            onClick={() => setIsWhatsAppOpen(false)}
          >
            <motion.div
              initial={reducedMotion ? false : { scale: 0.94, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={reducedMotion ? undefined : { scale: 0.94, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-4xl max-h-[88vh] rounded-3xl bg-[#070c22]/95 border border-emerald-400/35 backdrop-blur-2xl shadow-[0_24px_70px_rgba(0,0,0,0.85)] flex flex-col overflow-hidden"
            >
              <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
                    <MessageCircle size={18} />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white leading-tight">Mimi WhatsApp Hub</h2>
                    <p className="text-xs text-slate-300/75">Smart messaging & voice-assisted replies</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsWhatsAppOpen(false)}
                  aria-label="Close WhatsApp Hub"
                  className="min-h-[38px] min-w-[38px] rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-slate-200 flex items-center justify-center cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-3 md:p-4">
                <MimiWhatsAppWeb
                  recipient={latestWhatsAppMsg?.whatsappRecipient || "Kaushik Roy"}
                  phone={latestWhatsAppMsg?.whatsappPhone || "9876543210"}
                  message={latestWhatsAppMsg?.whatsappMessage || ""}
                  url={latestWhatsAppMsg?.url || "https://web.whatsapp.com"}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. Maps Navigator Modal */}
      <MapsModal
        isOpen={isMapsOpen}
        onClose={() => setIsMapsOpen(false)}
        onAskDirections={(place) => onSendText(`open google maps for ${place}`)}
        themeVariant="space"
      />
    </div>
  );
};
