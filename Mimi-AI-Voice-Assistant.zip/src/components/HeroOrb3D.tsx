import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { audioStreamer } from "../services/audioStreamer";

export type OrbAssistantState = "idle" | "listening" | "processing" | "speaking" | "upgrading";

interface HeroOrb3DProps {
  appState: OrbAssistantState;
  reducedMotion?: boolean;
  liveAudioLevelRef?: React.MutableRefObject<number>;
}

interface TargetVisualProfile {
  colorA: THREE.Color;
  colorB: THREE.Color;
  rimColor: THREE.Color;
  ringColor: THREE.Color;
  spinSpeed: number;
  waveSpeed: number;
  waveAmp: number;
  baseScale: number;
}

const PROFILES: Record<"idle" | "listening" | "thinking" | "speaking", TargetVisualProfile> = {
  idle: {
    colorA: new THREE.Color("#00c8ff"),
    colorB: new THREE.Color("#6d28d9"),
    rimColor: new THREE.Color("#38bdf8"),
    ringColor: new THREE.Color("#8b5cf6"),
    spinSpeed: 0.24,
    waveSpeed: 1.15,
    waveAmp: 0.065,
    baseScale: 1.0,
  },
  listening: {
    colorA: new THREE.Color("#00a8ff"), // Flowing Blue
    colorB: new THREE.Color("#00ff9d"), // Emerald Green
    rimColor: new THREE.Color("#34ffd2"),
    ringColor: new THREE.Color("#00e5ff"),
    spinSpeed: 0.45,
    waveSpeed: 2.35,
    waveAmp: 0.11,
    baseScale: 1.05,
  },
  thinking: {
    colorA: new THREE.Color("#7c3aed"), // Electric Violet
    colorB: new THREE.Color("#ff2a85"), // Neon Pink / Magenta
    rimColor: new THREE.Color("#f472b6"),
    ringColor: new THREE.Color("#a855f7"),
    spinSpeed: 0.36,
    waveSpeed: 1.55,
    waveAmp: 0.085,
    baseScale: 1.02,
  },
  speaking: {
    colorA: new THREE.Color("#ffb800"), // Radiant Gold
    colorB: new THREE.Color("#ff5a00"), // Fiery Orange
    rimColor: new THREE.Color("#fde047"),
    ringColor: new THREE.Color("#fb923c"),
    spinSpeed: 0.62,
    waveSpeed: 2.9,
    waveAmp: 0.135,
    baseScale: 1.08,
  },
};

const CORE_VERTEX_SHADER = `
  uniform float uTime;
  uniform float uWaveSpeed;
  uniform float uWaveAmp;
  uniform float uAudioLevel;
  uniform float uMotion;

  varying vec3 vNormal;
  varying vec3 vWorldPos;
  varying float vDisplacement;

  // Smooth multi-harmonic wave displacement
  float computeWave(vec3 p, float t) {
    float w1 = sin(p.x * 3.1 + t * 1.4) * cos(p.y * 2.8 - t * 1.1);
    float w2 = sin(p.z * 3.6 - t * 1.7) * cos(p.x * 2.3 + t * 0.9);
    float w3 = sin((p.x + p.y + p.z) * 2.7 + t * 2.0);
    return (w1 * 0.45 + w2 * 0.35 + w3 * 0.2);
  }

  void main() {
    float t = uTime * uWaveSpeed * uMotion;
    float wave = computeWave(position, t);
    float amp = uWaveAmp + uAudioLevel * 0.24;
    float disp = wave * amp * (0.4 + 0.6 * uMotion) + uAudioLevel * 0.14;

    vDisplacement = disp;
    vec3 displaced = position + normal * disp;

    vec4 worldPosition = modelMatrix * vec4(displaced, 1.0);
    vWorldPos = worldPosition.xyz;
    vNormal = normalize(mat3(modelMatrix) * normal);

    gl_Position = projectionMatrix * viewMatrix * worldPosition;
  }
`;

const CORE_FRAGMENT_SHADER = `
  uniform vec3 uColorA;
  uniform vec3 uColorB;
  uniform vec3 uRimColor;
  uniform float uTime;
  uniform float uAudioLevel;
  uniform float uMotion;

  varying vec3 vNormal;
  varying vec3 vWorldPos;
  varying float vDisplacement;

  void main() {
    vec3 viewDir = normalize(cameraPosition - vWorldPos);
    vec3 normal = normalize(vNormal);

    float fresnel = pow(1.0 - max(dot(viewDir, normal), 0.0), 2.35);
    float flow = sin(vWorldPos.y * 2.8 - uTime * 1.35 * uMotion + vWorldPos.x * 1.9) * 0.5 + 0.5;
    float band = clamp(flow + vDisplacement * 2.4, 0.0, 1.0);

    vec3 baseColor = mix(uColorA, uColorB, band);
    // Deep luminous core glow
    vec3 innerGlow = mix(baseColor, vec3(1.0), 0.14 + uAudioLevel * 0.22);
    // Neon rim highlights
    vec3 finalColor = mix(innerGlow, uRimColor, clamp(fresnel * 1.15, 0.0, 1.0));
    finalColor += uRimColor * (fresnel * (0.55 + uAudioLevel * 0.75));

    float alpha = clamp(0.84 + fresnel * 0.16, 0.0, 1.0);
    gl_FragColor = vec4(finalColor, alpha);
  }
`;

function createSoftParticleTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0, "rgba(255,255,255,1)");
    grad.addColorStop(0.28, "rgba(255,255,255,0.82)");
    grad.addColorStop(0.65, "rgba(255,255,255,0.22)");
    grad.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function detectLowPowerDevice(): boolean {
  if (typeof navigator === "undefined" || typeof window === "undefined") return false;
  const cores = navigator.hardwareConcurrency || 8;
  const mem = (navigator as unknown as { deviceMemory?: number }).deviceMemory || 8;
  const isSmallScreen = window.innerWidth < 640;
  return cores <= 4 || mem <= 4 || isSmallScreen;
}

export const HeroOrb3D: React.FC<HeroOrb3DProps> = ({
  appState,
  reducedMotion = false,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const stateRef = useRef<OrbAssistantState>(appState);
  const reducedMotionRef = useRef<boolean>(reducedMotion);
  const [webglUnavailable, setWebglUnavailable] = useState(false);

  useEffect(() => {
    stateRef.current = appState;
  }, [appState]);

  useEffect(() => {
    reducedMotionRef.current = reducedMotion;
  }, [reducedMotion]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer | null = null;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
      });
    } catch {
      setWebglUnavailable(true);
      return;
    }

    const gl = renderer.getContext();
    let isSoftwareGl = false;
    try {
      const dbg = gl.getExtension("WEBGL_debug_renderer_info");
      if (dbg) {
        const rendererName = String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || "").toLowerCase();
        isSoftwareGl =
          rendererName.includes("swiftshader") ||
          rendererName.includes("llvmpipe") ||
          rendererName.includes("software");
      }
    } catch {
      // Ignore WebGL debug extension restriction
    }

    const isLowPower = detectLowPowerDevice() || isSoftwareGl;
    const maxDpr = isLowPower ? 1.25 : 2;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr));
    renderer.setSize(width, height);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setClearColor(0x000000, 0);

    container.innerHTML = "";
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    const updateCameraDistance = (w: number, h: number) => {
      const aspect = w / Math.max(h, 1);
      camera.aspect = aspect;
      // Keep orb comfortably framed on portrait mobile and wide desktop
      camera.position.z = aspect < 0.85 ? 7.4 : aspect < 1.2 ? 6.4 : 5.75;
      camera.position.y = aspect < 0.85 ? 0.35 : 0.0;
      camera.updateProjectionMatrix();
    };
    updateCameraDistance(width, height);

    // Subtle studio lighting & PMREM environment reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTarget = pmrem.fromScene(new RoomEnvironment(), 0.04);
    scene.environment = envTarget.texture;
    scene.environmentIntensity = 0.65;

    const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x0a0d24, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
    keyLight.position.set(4, 5, 6);
    scene.add(keyLight);

    const rimLight = new THREE.PointLight(0x8b5cf6, 4.5, 18);
    rimLight.position.set(-3.5, -2.5, 3.0);
    scene.add(rimLight);

    // Core Group — rises smoothly from the dark on load
    const coreGroup = new THREE.Group();
    coreGroup.position.y = reducedMotionRef.current ? 0 : -2.35;
    coreGroup.scale.setScalar(reducedMotionRef.current ? 1 : 0.72);
    scene.add(coreGroup);

    // 1. Inner Shader Plasma Sphere
    const coreDetail = isLowPower ? 32 : 52;
    const coreGeo = new THREE.IcosahedronGeometry(1.06, coreDetail);
    const uniforms = {
      uTime: { value: 0 },
      uWaveSpeed: { value: PROFILES.idle.waveSpeed },
      uWaveAmp: { value: PROFILES.idle.waveAmp },
      uAudioLevel: { value: 0 },
      uMotion: { value: reducedMotionRef.current ? 0.0 : 1.0 },
      uColorA: { value: PROFILES.idle.colorA.clone() },
      uColorB: { value: PROFILES.idle.colorB.clone() },
      uRimColor: { value: PROFILES.idle.rimColor.clone() },
    };

    const coreMat = new THREE.ShaderMaterial({
      uniforms,
      vertexShader: CORE_VERTEX_SHADER,
      fragmentShader: CORE_FRAGMENT_SHADER,
      transparent: true,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    coreGroup.add(coreMesh);

    // 2. Outer Geodesic Wireframe Lattice
    const latticeGeo = new THREE.IcosahedronGeometry(1.34, 2);
    const latticeMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.16,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const latticeMesh = new THREE.Mesh(latticeGeo, latticeMat);
    coreGroup.add(latticeMesh);

    // 3. Three Tilted Luminous Halo Rings
    const ringMat = new THREE.MeshPhysicalMaterial({
      color: 0x1e293b,
      emissive: 0x8b5cf6,
      emissiveIntensity: 0.95,
      roughness: 0.18,
      metalness: 0.78,
      clearcoat: 1.0,
      transparent: true,
      opacity: 0.72,
    });

    const ringGeo1 = new THREE.TorusGeometry(1.56, 0.015, 16, isLowPower ? 64 : 112);
    const ringGeo2 = new THREE.TorusGeometry(1.74, 0.012, 16, isLowPower ? 64 : 112);
    const ringGeo3 = new THREE.TorusGeometry(1.92, 0.009, 16, isLowPower ? 64 : 112);

    const ring1 = new THREE.Mesh(ringGeo1, ringMat);
    ring1.rotation.set(Math.PI * 0.34, Math.PI * 0.18, 0);

    const ring2 = new THREE.Mesh(ringGeo2, ringMat);
    ring2.rotation.set(-Math.PI * 0.28, Math.PI * 0.42, 0.35);

    const ring3 = new THREE.Mesh(ringGeo3, ringMat);
    ring3.rotation.set(Math.PI * 0.48, -Math.PI * 0.25, -0.4);

    coreGroup.add(ring1, ring2, ring3);

    // 4. Orbiting Micro-Nodes along the outer shell
    const nodeGeo = new THREE.SphereGeometry(0.036, 12, 12);
    const nodeMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const nodeOffsets = [
      { radius: 1.56, speed: 0.85, phase: 0.0, tiltX: Math.PI * 0.34, tiltY: Math.PI * 0.18 },
      { radius: 1.56, speed: 0.85, phase: Math.PI, tiltX: Math.PI * 0.34, tiltY: Math.PI * 0.18 },
      { radius: 1.74, speed: -0.68, phase: 1.1, tiltX: -Math.PI * 0.28, tiltY: Math.PI * 0.42 },
      { radius: 1.92, speed: 0.54, phase: 2.3, tiltX: Math.PI * 0.48, tiltY: -Math.PI * 0.25 },
    ];
    const orbitNodes = nodeOffsets.map(() => {
      const m = new THREE.Mesh(nodeGeo, nodeMat);
      coreGroup.add(m);
      return m;
    });

    // 5. Soft Floating Background Particle Field (adaptive count for weak phones)
    const particleCount = isLowPower ? 68 : 210;
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);
    const particleSpeeds = new Float32Array(particleCount);

    const palette = [
      new THREE.Color("#00f0ff"), // Neon Cyan
      new THREE.Color("#ff2a85"), // Magenta
      new THREE.Color("#8b5cf6"), // Electric Violet
      new THREE.Color("#ffb800"), // Gold
    ];

    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      particlePositions[i3] = (Math.random() - 0.5) * 14.5;
      particlePositions[i3 + 1] = (Math.random() - 0.5) * 9.5;
      particlePositions[i3 + 2] = -1.6 - Math.random() * 5.8;

      const c = palette[i % palette.length];
      particleColors[i3] = c.r;
      particleColors[i3 + 1] = c.g;
      particleColors[i3 + 2] = c.b;

      particleSpeeds[i] = 0.25 + Math.random() * 0.55;
    }

    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute("position", new THREE.BufferAttribute(particlePositions, 3));
    particleGeo.setAttribute("color", new THREE.BufferAttribute(particleColors, 3));

    const particleTex = createSoftParticleTexture();
    const particleMat = new THREE.PointsMaterial({
      size: isLowPower ? 0.13 : 0.11,
      map: particleTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.72,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Pre-allocated animation temporaries (zero per-frame allocations)
    const _euler = new THREE.Euler();
    const _vec = new THREE.Vector3();
    let smoothedAudio = 0;
    let smoothedWaveSpeed = PROFILES.idle.waveSpeed;
    let smoothedWaveAmp = PROFILES.idle.waveAmp;
    let smoothedSpinSpeed = PROFILES.idle.spinSpeed;
    let currentY = reducedMotionRef.current ? 0 : -2.35;
    let currentScale = reducedMotionRef.current ? 1 : 0.72;
    let spinAccumulator = 0;
    let lastTime = performance.now();
    let rafId = 0;
    let isContextLost = false;

    const handleContextLost = (e: Event) => {
      e.preventDefault();
      isContextLost = true;
      setWebglUnavailable(true);
    };
    const handleContextRestored = () => {
      isContextLost = false;
      setWebglUnavailable(false);
    };
    renderer.domElement.addEventListener("webglcontextlost", handleContextLost);
    renderer.domElement.addEventListener("webglcontextrestored", handleContextRestored);

    const resizeObserver = new ResizeObserver((entries) => {
      if (!renderer || !entries.length) return;
      const { width: w, height: h } = entries[0].contentRect;
      if (w <= 0 || h <= 0) return;
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr));
      renderer.setSize(w, h);
      updateCameraDistance(w, h);
    });
    resizeObserver.observe(container);

    const animate = (now: number) => {
      rafId = requestAnimationFrame(animate);
      if (isContextLost || !renderer) return;

      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      const activeState = stateRef.current;
      const isReduced = reducedMotionRef.current;
      const motionScale = isReduced ? 0.0 : 1.0;

      const profileKey =
        activeState === "listening"
          ? "listening"
          : activeState === "processing" || activeState === "upgrading"
            ? "thinking"
            : activeState === "speaking"
              ? "speaking"
              : "idle";
      const target = PROFILES[profileKey];

      // Real audio frequency energy from audioStreamer.getFrequencyData()
      let targetAudio = 0;
      if (activeState === "speaking") {
        const freqData = audioStreamer.getFrequencyData(24);
        let energySum = 0;
        let peak = 0;
        for (let i = 0; i < freqData.length; i++) {
          energySum += freqData[i];
          if (freqData[i] > peak) peak = freqData[i];
        }
        const avgNorm = energySum / (freqData.length * 255);
        const peakNorm = peak / 255;
        targetAudio = Math.min(1.0, avgNorm * 1.5 + peakNorm * 0.45);
        // Gentle minimum harmonic breathing only when speaking state is active and buffer is ramping
        if (targetAudio < 0.06 && !isReduced) {
          targetAudio = 0.08 + 0.05 * Math.sin(now * 0.008);
        }
      } else if (activeState === "listening") {
        targetAudio = isReduced ? 0.04 : 0.06 + 0.04 * Math.sin(now * 0.004);
      }

      smoothedAudio = THREE.MathUtils.damp(smoothedAudio, targetAudio, 12, dt);
      smoothedWaveSpeed = THREE.MathUtils.damp(smoothedWaveSpeed, target.waveSpeed, 4.5, dt);
      smoothedWaveAmp = THREE.MathUtils.damp(smoothedWaveAmp, target.waveAmp, 4.5, dt);
      smoothedSpinSpeed = THREE.MathUtils.damp(smoothedSpinSpeed, target.spinSpeed, 4.0, dt);

      // Smoothly damp shader colors & state uniforms
      const colorDamp = Math.min(1, dt * 4.5);
      uniforms.uColorA.value.lerp(target.colorA, colorDamp);
      uniforms.uColorB.value.lerp(target.colorB, colorDamp);
      uniforms.uRimColor.value.lerp(target.rimColor, colorDamp);
      uniforms.uTime.value += dt;
      uniforms.uWaveSpeed.value = smoothedWaveSpeed;
      uniforms.uWaveAmp.value = smoothedWaveAmp;
      uniforms.uAudioLevel.value = smoothedAudio;
      uniforms.uMotion.value = THREE.MathUtils.damp(uniforms.uMotion.value, motionScale, 6, dt);

      // Update lattice, rings & rim light color smoothly
      latticeMat.color.lerp(target.rimColor, colorDamp);
      ringMat.emissive.lerp(target.ringColor, colorDamp);
      rimLight.color.lerp(target.colorB, colorDamp);

      // Entrance choreography: core rises slowly out of the dark
      if (isReduced) {
        currentY = 0;
        currentScale = target.baseScale;
      } else {
        currentY = THREE.MathUtils.damp(currentY, 0, 2.2, dt);
        const targetScl = target.baseScale + smoothedAudio * 0.28;
        currentScale = THREE.MathUtils.damp(currentScale, targetScl, 9.0, dt);
      }

      coreGroup.position.y = currentY + (isReduced ? 0 : Math.sin(uniforms.uTime.value * 0.9) * 0.045);
      coreGroup.scale.setScalar(currentScale);

      if (!isReduced) {
        spinAccumulator += dt * smoothedSpinSpeed;
        coreMesh.rotation.y = spinAccumulator * 0.65;
        coreMesh.rotation.x = Math.sin(spinAccumulator * 0.45) * 0.18;

        latticeMesh.rotation.y = -spinAccumulator * 0.45;
        latticeMesh.rotation.z = spinAccumulator * 0.22;

        ring1.rotation.z += dt * (0.28 + smoothedSpinSpeed * 0.6);
        ring2.rotation.z -= dt * (0.22 + smoothedSpinSpeed * 0.5);
        ring3.rotation.y += dt * (0.18 + smoothedSpinSpeed * 0.4);

        // Orbit micro-nodes around the tilted rings
        for (let i = 0; i < orbitNodes.length; i++) {
          const cfg = nodeOffsets[i];
          const angle = uniforms.uTime.value * cfg.speed * (0.8 + smoothedSpinSpeed) + cfg.phase;
          _vec.set(Math.cos(angle) * cfg.radius, Math.sin(angle) * cfg.radius, 0);
          _euler.set(cfg.tiltX, cfg.tiltY, 0);
          _vec.applyEuler(_euler);
          orbitNodes[i].position.copy(_vec);
        }

        // Softly float background particles
        const posAttr = particleGeo.getAttribute("position") as THREE.BufferAttribute;
        const arr = posAttr.array as Float32Array;
        for (let i = 0; i < particleCount; i++) {
          const i3 = i * 3;
          arr[i3 + 1] += dt * particleSpeeds[i] * 0.14;
          arr[i3] += Math.sin(uniforms.uTime.value * 0.4 + i) * dt * 0.03;
          if (arr[i3 + 1] > 4.8) {
            arr[i3 + 1] = -4.8;
          }
        }
        posAttr.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };

    rafId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(rafId);
      resizeObserver.disconnect();
      if (renderer) {
        renderer.domElement.removeEventListener("webglcontextlost", handleContextLost);
        renderer.domElement.removeEventListener("webglcontextrestored", handleContextRestored);
      }

      coreGeo.dispose();
      coreMat.dispose();
      latticeGeo.dispose();
      latticeMat.dispose();
      ringGeo1.dispose();
      ringGeo2.dispose();
      ringGeo3.dispose();
      ringMat.dispose();
      nodeGeo.dispose();
      nodeMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      particleTex.dispose();
      envTarget.dispose();
      pmrem.dispose();

      if (renderer) {
        renderer.dispose();
        if (renderer.domElement.parentNode === container) {
          container.removeChild(renderer.domElement);
        }
      }
    };
  }, []);

  if (webglUnavailable) {
    const fallbackGrad =
      appState === "listening"
        ? "from-cyan-400 via-teal-400 to-emerald-400 shadow-[0_0_90px_rgba(16,255,156,0.45)]"
        : appState === "processing" || appState === "upgrading"
          ? "from-violet-500 via-fuchsia-500 to-pink-500 shadow-[0_0_90px_rgba(236,72,153,0.45)]"
          : appState === "speaking"
            ? "from-amber-400 via-orange-400 to-yellow-300 shadow-[0_0_100px_rgba(255,184,0,0.5)]"
            : "from-cyan-400 via-violet-500 to-fuchsia-500 shadow-[0_0_80px_rgba(139,92,246,0.4)]";

    return (
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div
          className={`w-48 h-48 md:w-64 md:h-64 rounded-full bg-gradient-to-tr ${fallbackGrad} opacity-85 blur-[1px] transition-all duration-700`}
        />
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      aria-hidden="true"
      className="absolute inset-0 w-full h-full pointer-events-none"
    />
  );
};
