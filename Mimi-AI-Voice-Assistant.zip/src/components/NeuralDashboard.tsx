import React, { useState, useEffect } from "react";
import { 
  Cpu, 
  Brain, 
  Activity, 
  Check, 
  Sparkles, 
  RefreshCw, 
  Shield, 
  Network, 
  Server, 
  Radio, 
  Terminal, 
  Database,
  BarChart2,
  Flame,
  Binary,
  Layers,
  Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Beautiful interactive 3D Tactile Toggle Switch Component
interface ThreeDToggleProps {
  checked: boolean;
  onChange: () => void;
  activeColorClass?: string; // e.g. "bg-cyan-500 shadow-[0_0_15px_#22d3ee]"
  glowColor?: string; // color of the LED when active
}

const ThreeDToggle: React.FC<ThreeDToggleProps> = ({ 
  checked, 
  onChange, 
  activeColorClass = "bg-cyan-400 shadow-[0_0_12px_rgba(34,211,238,0.85)]",
  glowColor = "rgba(34,211,238,0.8)"
}) => {
  return (
    <button
      type="button"
      onClick={onChange}
      className={`relative w-16 h-8 rounded-full p-0.5 select-none cursor-pointer transition-all duration-300 outline-none flex items-center ${
        checked 
          ? "bg-[#101018] shadow-[inset_0_2px_6px_rgba(0,0,0,0.9),_0_1px_0px_rgba(255,255,255,0.05)] border border-white/10" 
          : "bg-[#08080c] shadow-[inset_0_2px_6px_rgba(0,0,0,0.95)] border border-white/[0.03]"
      }`}
      style={{ perspective: "1000px" }}
    >
      {/* Visual background slide colors */}
      <span 
        className={`absolute inset-0.5 rounded-full transition-all duration-500 ease-in-out opacity-20 ${
          checked ? "bg-cyan-500 blur-sm" : "bg-transparent"
        }`} 
      />

      {/* 3D Tactile Sliding Handle */}
      <div
        className={`absolute top-1 bottom-1 w-6 rounded-full transition-all duration-305 ease-out flex items-center justify-center ${
          checked 
            ? "left-8.5 bg-gradient-to-b from-neutral-50 via-neutral-200 to-neutral-400 shadow-[0_4px_10px_rgba(0,0,0,0.75),_inset_0_1.5px_1.5px_rgba(255,255,255,0.9)]" 
            : "left-1 bg-gradient-to-b from-neutral-700 via-neutral-800 to-neutral-900 shadow-[0_3px_5px_rgba(0,0,0,0.85),_inset_0_1px_1px_rgba(255,255,255,0.12)] border border-neutral-600/20"
        }`}
      >
        {/* Ridge-grip lines inside toggle button handle for tactile grip aesthetic */}
        <div className="flex gap-0.5">
          <span className={`w-[1px] h-3 rounded ${checked ? "bg-neutral-300" : "bg-neutral-500"}`} />
          <span className={`w-[1px] h-3 rounded ${checked ? "bg-neutral-300" : "bg-neutral-500"}`} />
        </div>
      </div>

      {/* Micro-LED glowing indication light */}
      <div 
        className={`absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full transition-all duration-300 ${
          checked 
            ? `${activeColorClass}` 
            : "left-3 bg-red-900/40 shadow-[0_0_1px_rgba(239,68,68,0.1)]"
        }`}
        style={checked ? { boxShadow: `0 0 10px ${glowColor}, 0 0 4px ${glowColor}` } : {}}
      />
    </button>
  );
};

interface NeuralEngine {
  id: string;
  name: string;
  developer: string;
  version: string;
  coreFocus: string;
  contextWindow: string;
  latency: number;
  health: number;
  status: "ONLINE" | "DEGRADED" | "OFFLINE";
  region: string;
  capabilities: string[];
  // Beautiful colourful styling variables:
  colorThemeClass: string; // The active theme label of choice
  cardBorderClass: string; // Dynamic outer ring
  bgStyleClass: string; // Vibrant background gradients
  glowColorHex: string; // Radial custom glow shadow
  iconBgGradient: string; // Colored 3D icon box
  iconColorClass: string; // Font colors
  icon: React.ComponentType<any>;
}

interface NeuralDashboardProps {
  preferences: Record<string, any>;
  onUpdatePreference: (key: string, value: any) => void;
  onUpgradeSystem?: () => void;
}

export default function NeuralDashboard({ preferences, onUpdatePreference, onUpgradeSystem }: NeuralDashboardProps) {
  const currentCore = preferences.neuralCore || "Gemini";
  const isAutoRouting = preferences.autoRouting ?? true;
  const isMultiAi = preferences.multiAiCollaboration ?? false;
  const isFailover = preferences.failoverProtection ?? true;
  const isAdvancedReasoning = preferences.advancedReasoning ?? false;

  const [calibrating, setCalibrating] = useState(false);
  const [activeTab, setActiveTab] = useState<"engines" | "performance" | "routing">("engines");

  // State for simulated live latencies to show real-time changes
  const [latencies, setLatencies] = useState<Record<string, number>>({
    ChatGPT: 48,
    Claude: 74,
    Gemini: 32,
    DeepSeek: 120,
    Grok: 55,
    MetaAI: 35,
    Copilot: 42,
    Kimi: 62,
    Perplexity: 88,
  });

  // Recent routing and failover events
  const [routingLogs, setRoutingLogs] = useState<Array<{
    time: string;
    prompt: string;
    detectedTask: string;
    routedTo: string;
    status: string;
    latency: string;
  }>>([
    { time: "07:02:14", prompt: "Explain Einstein's photoelectric effect", detectedTask: "Scientific Reasoning", routedTo: "DeepSeek", status: "Auto-Routed Successfully", latency: "115ms" },
    { time: "06:58:33", prompt: "Write an elegant React state hook", detectedTask: "Software Engineering", routedTo: "Kimi", status: "Auto-Routed Successfully", latency: "58ms" },
    { time: "06:45:12", prompt: "Summarize top tech news from today", detectedTask: "Factual Web Research", routedTo: "Perplexity", status: "Auto-Routed Successfully", latency: "92ms" },
    { time: "06:12:05", prompt: "Say something extremely sassy to me", detectedTask: "Banters & Jokes", routedTo: "Grok", status: "Auto-Routed Successfully", latency: "51ms" },
    { time: "05:54:19", prompt: "Check server connection nodes", detectedTask: "Diagnostic Commands", routedTo: "Gemini", status: "Auto-Routed Successfully", latency: "34ms" },
  ]);

  // Simulate subtle real-time latency ticks to create an alive "Dashboard"
  useEffect(() => {
    const timer = setInterval(() => {
      setLatencies(prev => {
        const next = { ...prev };
        Object.keys(next).forEach(key => {
          const delta = Math.floor(Math.random() * 5) - 2;
          next[key] = Math.max(10, Math.min(250, next[key] + delta));
        });
        return next;
      });
    }, 4500);

    return () => clearInterval(timer);
  }, []);

  const runCalibration = () => {
    setCalibrating(true);
    setTimeout(() => {
      setLatencies({
        ChatGPT: Math.floor(Math.random() * 20) + 35,
        Claude: Math.floor(Math.random() * 30) + 55,
        Gemini: Math.floor(Math.random() * 15) + 21,
        DeepSeek: Math.floor(Math.random() * 40) + 85,
        Grok: Math.floor(Math.random() * 20) + 40,
        MetaAI: Math.floor(Math.random() * 15) + 22,
        Copilot: Math.floor(Math.random() * 20) + 30,
        Kimi: Math.floor(Math.random() * 25) + 38,
        Perplexity: Math.floor(Math.random() * 30) + 55,
      });
      setCalibrating(false);
      const timeStr = new Date().toLocaleTimeString("en-US", { hour12: false });
      setRoutingLogs(prev => [
        {
          time: timeStr,
          prompt: "CALIBRATE_SYSTEM_CORE_HANDSHAKE",
          detectedTask: "Edge Telemetry Ping Test",
          routedTo: "All Cores Checked",
          status: "Recalibrated Latency Thresholds",
          latency: "Avg 42ms"
        },
        ...prev.slice(0, 5)
      ]);
    }, 1200);
  };

  const engines: NeuralEngine[] = [
    {
      id: "Gemini",
      name: "Gemini 4 Hydrogen",
      developer: "Google DeepMind",
      version: "Gemini 4 Hydrogen / 3.8 Live",
      coreFocus: "Next-gen Intelligence & Real-Time Live Audio",
      contextWindow: "2,000,000 Tokens",
      latency: latencies.Gemini,
      health: 99.9,
      status: "ONLINE",
      region: "us-central1-gcp",
      capabilities: ["Extreme Context", "Fast Speech", "Smart Orchestration"],
      colorThemeClass: "text-cyan-400",
      cardBorderClass: "border-cyan-500/40 shadow-[0_0_25px_rgba(6,182,212,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-cyan-950/20 via-[#0a111a]/95 to-neutral-950/98",
      glowColorHex: "rgba(34,211,238,0.25)",
      iconBgGradient: "bg-gradient-to-br from-cyan-400 via-sky-500 to-blue-600 shadow-[0_4px_12px_rgba(6,182,212,0.45)]",
      iconColorClass: "text-cyan-400",
      icon: Brain
    },
    {
      id: "ChatGPT",
      name: "ChatGPT",
      developer: "OpenAI",
      version: "GPT-6 (Latest Stable / Omniverse)",
      coreFocus: "Logic, multi-turn dialogue structures & essays",
      contextWindow: "256,000 Tokens",
      latency: latencies.ChatGPT,
      health: 99.7,
      status: "ONLINE",
      region: "us-east4-azure",
      capabilities: ["Logic Formatting", "Multi-turn Dialogue", "Essay Synthesis"],
      colorThemeClass: "text-emerald-400",
      cardBorderClass: "border-emerald-500/40 shadow-[0_0_25px_rgba(16,185,129,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-emerald-950/20 via-[#061510]/95 to-neutral-950/98",
      glowColorHex: "rgba(52,211,153,0.25)",
      iconBgGradient: "bg-gradient-to-br from-emerald-400 via-teal-500 to-green-600 shadow-[0_4px_12px_rgba(16,185,129,0.45)]",
      iconColorClass: "text-emerald-400",
      icon: Terminal
    },
    {
      id: "Claude",
      name: "Claude",
      developer: "Anthropic",
      version: "Claude 3.8 (Latest Sonnet / Epic)",
      coreFocus: "Extensively commented complex coding",
      contextWindow: "200,000 Tokens",
      latency: latencies.Claude,
      health: 99.4,
      status: "ONLINE",
      region: "us-west2-aws",
      capabilities: ["Pragmatic Code", "Thorough Analysis", "Commented Logic"],
      colorThemeClass: "text-amber-500",
      cardBorderClass: "border-amber-500/40 shadow-[0_0_25px_rgba(245,158,11,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-amber-950/20 via-[#1a110b]/95 to-neutral-950/98",
      glowColorHex: "rgba(245,158,11,0.25)",
      iconBgGradient: "bg-gradient-to-br from-amber-400 via-amber-550 to-orange-600 shadow-[0_4px_12px_rgba(245,158,11,0.45)]",
      iconColorClass: "text-amber-400",
      icon: Layers
    },
    {
      id: "DeepSeek",
      name: "DeepSeek-R1",
      developer: "DeepSeek Tech",
      version: "R2 800B (Latest Reasoning Engine)",
      coreFocus: "Mathematical chain-of-thought calculation",
      contextWindow: "128,000 Tokens",
      latency: latencies.DeepSeek,
      health: 98.9,
      status: "ONLINE",
      region: "cn-hangzhou-datacenter",
      capabilities: ["Chain-of-Thought", "Complex Math", "Logical Audits"],
      colorThemeClass: "text-blue-400",
      cardBorderClass: "border-blue-500/40 shadow-[0_0_25px_rgba(37,99,235,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-blue-950/20 via-[#070e1d]/95 to-neutral-950/98",
      glowColorHex: "rgba(96,165,250,0.25)",
      iconBgGradient: "bg-gradient-to-br from-blue-400 via-indigo-500 to-blue-700 shadow-[0_4px_12px_rgba(37,99,235,0.45)]",
      iconColorClass: "text-blue-400",
      icon: Flame
    },
    {
      id: "Grok",
      name: "Grok",
      developer: "xAI",
      version: "Grok 4 (Latest Rebel Engine)",
      coreFocus: "Unfiltered real-time trends, sarcasm, humor",
      contextWindow: "131,072 Tokens",
      latency: latencies.Grok,
      health: 99.2,
      status: "ONLINE",
      region: "us-central-colossus",
      capabilities: ["Real-time Info", "Witty Banter", "Bold Humor"],
      colorThemeClass: "text-orange-400",
      cardBorderClass: "border-orange-500/40 shadow-[0_0_25px_rgba(249,115,22,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-orange-950/20 via-[#1d1007]/95 to-neutral-950/98",
      glowColorHex: "rgba(251,146,60,0.25)",
      iconBgGradient: "bg-gradient-to-br from-orange-400 via-amber-550 to-red-650 shadow-[0_4px_12px_rgba(249,115,22,0.45)]",
      iconColorClass: "text-orange-400",
      icon: Radio
    },
    {
      id: "MetaAI",
      name: "Meta AI",
      developer: "Meta",
      version: "Llama 4 (Latest Llama Model)",
      coreFocus: "Creative tasks, friendly localized slang",
      contextWindow: "128,000 Tokens",
      latency: latencies.MetaAI,
      health: 99.8,
      status: "ONLINE",
      region: "eu-dublin-meta",
      capabilities: ["Llama Creative", "Local Slang", "Ultra Fast Response"],
      colorThemeClass: "text-indigo-400",
      cardBorderClass: "border-indigo-500/40 shadow-[0_0_25px_rgba(99,102,241,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-indigo-950/20 via-[#100923]/95 to-neutral-950/98",
      glowColorHex: "rgba(129,140,248,0.25)",
      iconBgGradient: "bg-gradient-to-br from-indigo-400 via-fuchsia-500 to-pink-600 shadow-[0_4px_12px_rgba(99,102,241,0.45)]",
      iconColorClass: "text-indigo-400",
      icon: Network
    },
    {
      id: "Copilot",
      name: "Microsoft Copilot",
      developer: "Microsoft",
      version: "Copilot Enterprise (Latest AI Engine)",
      coreFocus: "Productivity spreadsheets & automation math",
      contextWindow: "128,000 Tokens",
      latency: latencies.Copilot,
      health: 99.6,
      status: "ONLINE",
      region: "us-central-azure",
      capabilities: ["Spreadsheet Math", "Word Automation", "Template Logic"],
      colorThemeClass: "text-violet-400",
      cardBorderClass: "border-violet-500/40 shadow-[0_0_25px_rgba(139,92,246,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-violet-950/20 via-[#140823]/95 to-neutral-950/98",
      glowColorHex: "rgba(167,139,250,0.25)",
      iconBgGradient: "bg-gradient-to-br from-violet-400 via-purple-550 to-indigo-650 shadow-[0_4px_12px_rgba(139,92,246,0.45)]",
      iconColorClass: "text-violet-400",
      icon: Shield
    },
    {
      id: "Kimi",
      name: "Kimi AI",
      developer: "Moonshot AI",
      version: "Moonshot-v2 (Latest Kimi Model)",
      coreFocus: "Self-repair, code patches & neural logic",
      contextWindow: "200,000 Tokens",
      latency: latencies.Kimi,
      health: 99.5,
      status: "ONLINE",
      region: "cn-beijing-cloud",
      capabilities: ["Autonomous Code", "Dynamic Patches", "Self-Repair"],
      colorThemeClass: "text-pink-400",
      cardBorderClass: "border-pink-500/40 shadow-[0_0_25px_rgba(236,72,153,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-pink-950/20 via-[#220716]/95 to-neutral-950/98",
      glowColorHex: "rgba(244,114,182,0.25)",
      iconBgGradient: "bg-gradient-to-br from-pink-400 via-pink-550 to-rose-600 shadow-[0_4px_12px_rgba(236,72,153,0.45)]",
      iconColorClass: "text-pink-400",
      icon: Cpu
    },
    {
      id: "Perplexity",
      name: "Perplexity AI",
      developer: "Perplexity",
      version: "Perplexity Ultra (Latest Search & Reasoning)",
      coreFocus: "Factual search reports with formal citations",
      contextWindow: "32,000 Tokens",
      latency: latencies.Perplexity,
      health: 99.1,
      status: "ONLINE",
      region: "us-west1-gcp",
      capabilities: ["Formal Citations", "Deep Web Search", "Sourced Reports"],
      colorThemeClass: "text-yellow-500",
      cardBorderClass: "border-yellow-500/40 shadow-[0_0_25px_rgba(234,179,8,0.15)]",
      bgStyleClass: "bg-gradient-to-br from-yellow-950/20 via-[#181a07]/95 to-neutral-950/98",
      glowColorHex: "rgba(253,224,71,0.25)",
      iconBgGradient: "bg-gradient-to-br from-yellow-400 via-amber-500 to-yellow-600 shadow-[0_4px_12px_rgba(234,179,8,0.45)]",
      iconColorClass: "text-yellow-500",
      icon: Server
    }
  ];

  return (
    <div className="space-y-6">
      {/* 1. Header with Core Telemetry Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-neutral-900/40 border border-white/5 p-5 rounded-3xl gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-cyan-400">
            <Cpu size={16} className="animate-spin-slow" />
            <span className="text-[10px] font-bold font-mono tracking-widest uppercase">PRIMARY NEURAL INTERFACE</span>
          </div>
          <h2 className="text-lg font-black text-white">Choose Primary Neural Engine</h2>
          <p className="text-[11px] text-white/50 leading-relaxed max-w-xl">
            Configure, recalibrate, or auto-route across 9 state-of-the-art AI engines. Mimi will synchronize her contextual memory and personality styles dynamically with the active cluster.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <button
            onClick={runCalibration}
            disabled={calibrating}
            className="px-4 py-2.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 hover:border-cyan-500 text-xs font-bold font-mono uppercase rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2 select-none active:scale-95 disabled:opacity-40 w-full sm:w-auto"
          >
            {calibrating ? (
              <RefreshCw size={12} className="animate-spin text-cyan-400" />
            ) : (
              <Activity size={12} className="text-cyan-400" />
            )}
            <span>{calibrating ? "Pinging Nodes..." : "Calibrate Telemetry"}</span>
          </button>
          
          {onUpgradeSystem && (
            <button
              onClick={onUpgradeSystem}
              className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-orange-650 hover:from-amber-400 hover:to-orange-500 text-white shadow-[0_4px_15px_rgba(245,158,11,0.3)] hover:shadow-[0_4px_22px_rgba(245,158,11,0.5)] border border-amber-400/30 text-xs font-bold font-mono uppercase rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2 select-none active:scale-95 w-full sm:w-auto animate-pulse"
              style={{ animationDuration: "3s" }}
            >
              <Zap size={12} className="text-white shrink-0" />
              <span>Full System Upgrade</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. Sub-Tabs selection */}
      <div className="flex border-b border-white/5">
        {[
          { id: "engines", label: "Supported Engines (9)", icon: Cpu },
          { id: "performance", label: "Performance Dashboard", icon: BarChart2 },
          { id: "routing", label: "Smart Routing & Policies", icon: Network }
        ].map((t) => {
          const Icon = t.icon;
          const isActive = activeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`pb-3 px-5 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
                isActive 
                  ? "border-cyan-400 text-cyan-400" 
                  : "border-transparent text-white/40 hover:text-white"
              }`}
            >
              <Icon size={13} />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Pages */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -5 }}
          transition={{ duration: 0.15 }}
          className="space-y-6"
        >
          {/* TAB A: SUPPORTED ENGINES LIST */}
          {activeTab === "engines" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {engines.map((engine) => {
                  const Icon = engine.icon;
                  const isCurrent = currentCore === engine.id;

                  return (
                    <div
                      key={engine.id}
                      onClick={() => onUpdatePreference("neuralCore", engine.id)}
                      className={`relative overflow-hidden p-5 rounded-3xl text-left cursor-pointer transition-all duration-300 ${
                        isCurrent 
                          ? `${engine.cardBorderClass} ${engine.bgStyleClass} ring-1 ring-white/10 scale-[1.02]` 
                          : "border border-white/5 bg-neutral-950/20 hover:bg-neutral-900/30 hover:border-white/10"
                      }`}
                      style={{
                        boxShadow: isCurrent ? `0 10px 30px -10px ${engine.glowColorHex}` : "none"
                      }}
                    >
                      {/* 3D dynamic mesh glow gradient in background */}
                      {isCurrent && (
                        <div 
                          className="absolute -top-12 -right-12 w-28 h-28 blur-2xl rounded-full opacity-35"
                          style={{ background: engine.glowColorHex }}
                        />
                      )}

                      {/* Top Header Row */}
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-3">
                          {/* Beautiful colorful 3D floating icon badge */}
                          <div 
                            className={`p-2.5 rounded-2xl border transition-all duration-300 ${
                              isCurrent 
                                ? `${engine.iconBgGradient} text-white border-white/20 scale-110` 
                                : `bg-white/5 border-white/5 ${engine.iconColorClass} opacity-70`
                            }`}
                          >
                            <Icon size={18} className={isCurrent ? "animate-pulse" : ""} />
                          </div>
                          <div>
                            <h3 className="text-sm font-black text-white flex items-center gap-1.5 font-sans tracking-wide">
                              {engine.name}
                              {isCurrent && (
                                <span className="flex h-2 w-2 relative">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                                </span>
                              )}
                            </h3>
                            <p className="text-[10px] text-white/40 block leading-none font-semibold mt-0.5">{engine.developer}</p>
                          </div>
                        </div>

                        {/* Connection Latency Badge */}
                        <div className="flex flex-col items-end">
                          <span className={`text-xs font-mono font-bold ${isCurrent ? "text-white" : "text-white/60"}`}>
                            {engine.latency}ms
                          </span>
                          <span className="text-[8px] text-white/30 uppercase font-mono tracking-wider font-bold mt-0.5">LATENCY</span>
                        </div>
                      </div>

                      {/* Capabilities pills with matching custom accent colors */}
                      <div className="flex flex-wrap gap-1.5 mt-4">
                        {engine.capabilities.map((cap) => (
                          <span 
                            key={cap} 
                            className={`text-[8px] font-black uppercase tracking-wider px-2 py-0.5 rounded-lg ${
                              isCurrent 
                                ? "bg-white/10 border border-white/15 text-white shadow-sm"
                                : "bg-white/5 border border-white/5 text-white/40"
                            }`}
                          >
                            {cap}
                          </span>
                        ))}
                      </div>

                      {/* Model Version detail */}
                      <div className="border-t border-white/5 pt-3 mt-4 space-y-1 text-[10px] font-mono leading-tight">
                        <div className="flex justify-between text-white/40">
                          <span>Focus:</span>
                          <span className="text-white/70 text-right truncate max-w-[150px] font-semibold">{engine.coreFocus}</span>
                        </div>
                        <div className="flex justify-between text-white/40">
                          <span>Version:</span>
                          <span className="text-white/70 truncate text-right max-w-[130px] font-semibold">{engine.version}</span>
                        </div>
                        {isCurrent && (
                          <div className="flex justify-between text-white/40 border-t border-white/5 pt-1.5 mt-1.5">
                            <span className="text-white/50">Hosting Node:</span>
                            <span className="text-cyan-400 font-bold uppercase">{engine.region}</span>
                          </div>
                        )}
                      </div>

                      {/* Active click badge with 3D checkmark style */}
                      {isCurrent && (
                        <div className="absolute bottom-3 right-3 flex items-center justify-center p-1 rounded-full bg-white text-neutral-950 shadow-md">
                          <Check size={10} strokeWidth={3.5} />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Engine Selection Explainer */}
              <div className="p-4 bg-[#09090c]/60 rounded-2xl border border-white/5 flex gap-3 text-[11px] text-white/50 leading-relaxed text-left">
                <Shield size={16} className="text-cyan-400 shrink-0 mt-0.5 animate-pulse" />
                <div>
                  <strong className="text-white/80 block mb-0.5">Neural Failover Protocols</strong>
                  If your chosen primary engine undergoes connection failures, rate limit spikes, or returns server exceptions, Mimi's built-in <span className="text-cyan-400 font-bold uppercase font-mono">Failover Daemon</span> automatically hot-swaps to Gemini Pro within 45ms to ensure zero conversation interruption.
                </div>
              </div>
            </div>
          )}

          {/* TAB B: PERFORMANCE DASHBOARD */}
          {activeTab === "performance" && (
            <div className="space-y-6">
              {/* Telemetry charts row */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* 1. Real-Time Latency Bars */}
                <div className="lg:col-span-2 bg-neutral-950/40 p-5 rounded-3xl border border-white/5 space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <BarChart2 size={16} className="text-cyan-400" />
                      <h3 className="text-xs font-black uppercase tracking-wider text-white">Relative Real-Time Latency (ms)</h3>
                    </div>
                    <span className="text-[10px] bg-cyan-400/10 font-mono text-cyan-400 px-2 py-0.5 rounded font-bold uppercase">LIVE</span>
                  </div>

                  <div className="space-y-2.5 pt-2">
                    {engines.map((eng) => {
                      const isCurrent = currentCore === eng.id;
                      const maxLat = 220;
                      const widthPct = Math.min(100, Math.max(10, (eng.latency / maxLat) * 100));

                      return (
                        <div key={eng.id} className="space-y-1">
                          <div className="flex justify-between text-[11px] font-mono">
                            <span className={`font-bold flex items-center gap-1.5 ${isCurrent ? "text-cyan-400" : "text-white/70"}`}>
                              {eng.name}
                              {isCurrent && <span className="text-[9px] bg-cyan-400/15 border border-cyan-400/35 px-1 py-px rounded text-cyan-300 font-bold uppercase">ACTIVE</span>}
                            </span>
                            <span className={isCurrent ? "text-cyan-400 font-bold" : "text-white/40"}>
                              {eng.latency} ms
                            </span>
                          </div>
                          <div className="w-full bg-[#111116] h-2 rounded-full overflow-hidden border border-white/[0.02]">
                            <div 
                              className={`h-full rounded-full transition-all duration-700 ${
                                isCurrent 
                                  ? "bg-gradient-to-r from-cyan-400 to-indigo-500" 
                                  : "bg-white/10"
                              }`} 
                              style={{ width: `${widthPct}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Neural health statistics doughnut columns */}
                <div className="bg-neutral-950/40 p-5 rounded-3xl border border-white/5 space-y-4 flex flex-col justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Shield size={16} className="text-cyan-400" />
                      <h3 className="text-xs font-black uppercase tracking-wider text-white">System Integrity Metrics</h3>
                    </div>
                    <p className="text-[10px] text-white/40 font-semibold leading-relaxed">Real-time load balancing, edge validation rates, and frame alignment thresholds.</p>
                  </div>

                  <div className="space-y-4 pt-2">
                    {[
                      { label: "Active Nodes Operational", value: "9 / 9 Online", color: "text-emerald-400", sub: "GCP, AWS, Azure, local hybrid" },
                      { label: "Failover Status Ready", value: "A+ Priority", color: "text-cyan-400", sub: "45ms switch buffer hot-reserve" },
                      { label: "Sync Alignment Ratio", value: "99.98% True", color: "text-indigo-400", sub: "1024-byte packet delta verification" },
                      { label: "Avg Execution Speed", value: "42.5ms", color: "text-violet-400", sub: "Throughput optimized response cycles" }
                    ].map((stat, i) => (
                      <div key={i} className="p-3 bg-[#0c0c11] rounded-2xl border border-white/5 space-y-0.5">
                        <span className="text-[9px] text-white/30 block uppercase font-mono font-bold">{stat.label}</span>
                        <div className="flex justify-between items-center pt-0.5">
                          <span className={`text-sm font-black tracking-wide ${stat.color}`}>{stat.value}</span>
                          <span className="text-[9px] text-white/40 font-medium font-mono">{stat.sub}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Live Telemetry Router Log Stream */}
              <div className="bg-neutral-950/40 border border-white/5 p-5 rounded-3xl space-y-4 text-left">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Terminal size={14} className="text-cyan-400" />
                    <h3 className="text-xs font-black uppercase tracking-wider text-white font-mono">Routing Telemetry Event Stream</h3>
                  </div>
                  <span className="text-[9px] font-mono text-white/45 bg-white/5 border border-white/10 px-2 py-0.5 rounded">AUTOSTREAM ACTIVE</span>
                </div>

                <div className="font-mono text-[10px] leading-relaxed border border-white/5 bg-[#09090c] rounded-2xl divide-y divide-white/5 overflow-hidden">
                  {routingLogs.map((log, index) => (
                    <div key={index} className="p-3 hover:bg-neutral-900/40 transition-all flex flex-col md:flex-row justify-between md:items-center gap-2">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <span className="text-cyan-400 font-bold shrink-0">{log.time}</span>
                        <div className="truncate min-w-0">
                          <span className="text-white/80 block truncate font-bold">"{log.prompt}"</span>
                          <span className="text-white/30 font-medium block mt-0.5">Detected: <span className="text-cyan-400/80 font-bold">{log.detectedTask}</span></span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 shrink-0 justify-between md:justify-end border-t border-white/[0.04] md:border-transparent pt-1 md:pt-0">
                        <span className="text-[9px] bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 text-indigo-400 rounded font-bold uppercase">{log.routedTo}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span className="text-emerald-400 font-bold">{log.status}</span>
                        </div>
                        <span className="text-white/40 block min-w-[50px] text-right font-bold">{log.latency}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB C: ROUTING POLICIES */}
          {activeTab === "routing" && (
            <div className="space-y-6 text-left">
              
              {/* Live Toggles Grid with 3D Switches */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Switch 1: Adaptive Router */}
                <div className="p-5 rounded-3xl bg-neutral-950/40 border border-white/5 flex justify-between items-center gap-4 hover:border-white/10 transition-all">
                  <div className="space-y-1 max-w-[280px]">
                    <div className="flex items-center gap-2 text-cyan-400">
                      <Network size={16} />
                      <h4 className="text-xs font-black uppercase tracking-wider font-sans">Adaptive Core Auto-Routing</h4>
                    </div>
                    <p className="text-[11px] text-white/50 leading-relaxed font-semibold">
                      Automatically redirects queries to the best suited AI core based on prompt analysis (e.g. Claude 3.8 for complex system math, Grok 4 for trend banter).
                    </p>
                  </div>
                  <div>
                    <ThreeDToggle 
                      checked={isAutoRouting} 
                      onChange={() => onUpdatePreference("autoRouting", !isAutoRouting)} 
                      activeColorClass="bg-cyan-400 shadow-[0_0_12px_rgba(34,211,238,0.95)]"
                      glowColor="rgba(34,211,238,0.9)"
                    />
                  </div>
                </div>

                {/* Switch 2: Smart Failover */}
                <div className="p-5 rounded-3xl bg-neutral-950/40 border border-white/5 flex justify-between items-center gap-4 hover:border-white/10 transition-all">
                  <div className="space-y-1 max-w-[280px]">
                    <div className="flex items-center gap-2 text-emerald-400">
                      <Shield size={16} />
                      <h4 className="text-xs font-black uppercase tracking-wider font-sans">Active Failover Protection</h4>
                    </div>
                    <p className="text-[11px] text-white/50 leading-relaxed font-semibold">
                      Ensures dual-tier redundancies. If any high-tier API server registers lag above 300ms or drops connection entirely, Mimi automatically cascades queries to secondary clusters.
                    </p>
                  </div>
                  <div>
                    <ThreeDToggle 
                      checked={isFailover} 
                      onChange={() => onUpdatePreference("failoverProtection", !isFailover)} 
                      activeColorClass="bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.95)]"
                      glowColor="rgba(52,211,153,0.9)"
                    />
                  </div>
                </div>

                {/* Switch 3: Multi-AI Collaboration */}
                <div className="p-5 rounded-3xl bg-neutral-950/40 border border-white/5 flex justify-between items-center gap-4 hover:border-white/10 transition-all">
                  <div className="space-y-1 max-w-[280px]">
                    <div className="flex items-center gap-2 text-pink-400">
                      <Sparkles size={16} />
                      <h4 className="text-xs font-black uppercase tracking-wider font-sans">Multi-AI Collaboration Mode</h4>
                    </div>
                    <p className="text-[11px] text-white/50 leading-relaxed font-semibold">
                      When active, Mimi asks every model that has an API key at the same time and merges their best parts into one answer. Add keys under Settings, AI keys &amp; server.
                    </p>
                  </div>
                  <div>
                    <ThreeDToggle 
                      checked={isMultiAi} 
                      onChange={() => onUpdatePreference("multiAiCollaboration", !isMultiAi)} 
                      activeColorClass="bg-pink-400 shadow-[0_0_12px_rgba(244,114,182,0.95)]"
                      glowColor="rgba(244,114,182,0.9)"
                    />
                  </div>
                </div>

                {/* Switch 4: Advanced Reasoning Mode */}
                <div className="p-5 rounded-3xl bg-neutral-950/40 border border-white/5 flex justify-between items-center gap-4 hover:border-white/10 transition-all">
                  <div className="space-y-1 max-w-[280px]">
                    <div className="flex items-center gap-2 text-orange-400">
                      <Binary size={16} />
                      <h4 className="text-xs font-black uppercase tracking-wider font-sans">Advanced Reasoning Mode</h4>
                    </div>
                    <p className="text-[11px] text-white/50 leading-relaxed font-semibold">
                      Generates extremely thorough, logical calculations. Deep reasoning prompts &lt;think&gt; blocks natively inside chats to show you recursive processing before printing final reports.
                    </p>
                  </div>
                  <div>
                    <ThreeDToggle 
                      checked={isAdvancedReasoning} 
                      onChange={() => onUpdatePreference("advancedReasoning", !isAdvancedReasoning)} 
                      activeColorClass="bg-orange-400 shadow-[0_0_12px_rgba(251,146,60,0.95)]"
                      glowColor="rgba(251,146,60,0.9)"
                    />
                  </div>
                </div>

              </div>

              {/* Memory Synchronization segment info */}
              <div className="bg-neutral-950/40 border border-white/5 p-5 rounded-3xl space-y-4">
                <div className="flex items-center gap-2 text-violet-400">
                  <Database size={15} />
                  <h4 className="text-xs font-black uppercase tracking-wider">Unified Memory Synchronization</h4>
                </div>
                <p className="text-[11px] text-white/50 leading-relaxed font-semibold">
                  Every AI engine shares the exact same biographical log profile (Mimi's consolidated synapses) stored securely in your private cloud profile. When you swap neural cores, Mimi transfers relevant facts natively, ensuring ChatGPT, Grok, and Claude know you precisely, recognizing your tastes, name, and favorite projects without discrepancy.
                </p>
                <div className="flex flex-wrap gap-2 pt-1 font-mono text-[9px] text-[#eab308]">
                  <span className="p-1 px-2.5 rounded-lg bg-yellow-500/5 border border-yellow-500/20 font-bold">Name: Authorized Node</span>
                  <span className="p-1 px-2.5 rounded-lg bg-yellow-500/5 border border-yellow-500/20 font-bold">Biographical Fact Index: Active</span>
                  <span className="p-1 px-2.5 rounded-lg bg-yellow-500/5 border border-yellow-500/20 font-bold">Preferences Hash: {preferences.name ? "Verified Sync" : "No Name Declared"}</span>
                </div>
              </div>

            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
