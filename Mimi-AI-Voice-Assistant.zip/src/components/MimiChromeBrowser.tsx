import React, { useState, useEffect } from "react";
import { Monitor, Search, RefreshCw, Volume2, ArrowLeft, ArrowRight, ExternalLink } from "lucide-react";

interface MimiChromeBrowserProps {
  query: string;
  url: string;
}

export const MimiChromeBrowser: React.FC<MimiChromeBrowserProps> = ({ query, url }) => {
  const [loading, setLoading] = useState(true);
  const [speaking, setSpeaking] = useState(false);
  const [scrapedText, setScrapedText] = useState<string | null>(null);
  const [scrapedTitle, setScrapedTitle] = useState<string | null>(null);
  const [isCustomSite, setIsCustomSite] = useState(false);

  useEffect(() => {
    const isGoogle = !url || url.includes("google.com");
    setIsCustomSite(!isGoogle);

    if (!isGoogle && url) {
      setLoading(true);
      fetch("/api/scrape", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error("Proxy response failed");
      })
      .then(data => {
        if (data.text) {
          // Clean up multiple newlines/whitespace
          const cleanedText = data.text.replace(/\s+/g, ' ').substring(0, 5000).trim();
          setScrapedText(cleanedText);
          const firstLine = data.text.trim().split("\n")[0]?.substring(0, 80);
          setScrapedTitle(firstLine || url.replace(/^https?:\/\/(www\.)?/, ""));
        } else {
          setScrapedText("Could not extract main textual body from this page. Standard external frame recommended.");
        }
        setLoading(false);
      })
      .catch(err => {
        console.error("Web scraping error:", err);
        setScrapedText("Failed to scrape live text directly due to CORS/Protection. Landing frame cached.");
        setLoading(false);
      });
    } else {
      setLoading(true);
      const timer = setTimeout(() => {
        setLoading(false);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [url]);

  // Read results aloud in soft natural Bengali/English fallback
  const handleVocalize = () => {
    try {
      if (typeof window === "undefined" || !window.speechSynthesis) {
        console.warn("Speech synthesis is not supported or is blocked in this environment.");
        return;
      }
      if (speaking) {
        try {
          window.speechSynthesis.cancel();
        } catch (_) {}
        setSpeaking(false);
        return;
      }

      const readableText = getSpeakingSummary();
      const utterance = new SpeechSynthesisUtterance(readableText);
      
      // Automatically detect Bengali text or default to English
      if (/[\u0980-\u09FF]/.test(readableText)) {
        utterance.lang = "bn-IN";
      } else {
        utterance.lang = "en-US";
      }

      utterance.onend = () => setSpeaking(false);
      utterance.onerror = () => setSpeaking(false);
      
      setSpeaking(true);
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("Speech synthesis error captured:", e);
      setSpeaking(false);
    }
  };

  useEffect(() => {
    return () => {
      try {
        if (typeof window !== "undefined" && window.speechSynthesis) {
          window.speechSynthesis.cancel();
        }
      } catch (_) {}
    };
  }, []);

  // Generates customized search card results based on the search query or scraped text
  const getSearchResults = () => {
    if (isCustomSite && scrapedText) {
      const displayDomain = url.replace(/^https?:\/\/(www\.)?/, "").split("/")[0];
      return {
        title: scrapedTitle || displayDomain,
        snippet: scrapedText.substring(0, 850) + (scrapedText.length > 850 ? "..." : ""),
        extra: "Connected via Mimi Web Crawler • Reader Mode Active",
        source: displayDomain,
        voiceText: `আমি ${displayDomain} সাইটের মূল টেক্সট ওপেন করেছি। এখানে মূল বিষয়বস্তু হলো: ${scrapedText.substring(0, 300)}`
      };
    }

    const q = query.toLowerCase();
    
    if (q.includes("weather") || q.includes("আবহাওয়া") || q.includes("আবহাওয়া")) {
      return {
        title: "Kolkata, WB Weather - Weather Forecast & Summary",
        snippet: "আজকের আবহাওয়া অত্যন্ত মনোরম। তাপমাত্রা ২৫° সে. থেকে ৩২° সে.-এর মধ্যে বজায় থাকবে। আংশিক মেঘলা আকাশ এবং হালকা বৃষ্টির সম্ভাবনা রয়েছে। আর্দ্রতা ৭৫%।",
        extra: "Humidity: 74% | Wind: 12 km/h | Precipitation: 20%",
        source: "Weather.com",
        voiceText: "আজকের আবহাওয়া অত্যন্ত মনোরম। তাপমাত্রা ২৫ ডিগ্রি সেলসিয়াস থেকে ৩২ ডিগ্রি সেলসিয়াসের মধ্যে থাকবে। আংশিক মেঘলা আকাশ এবং হালকা বৃষ্টির সম্ভাবনা রয়েছে।"
      };
    }

    if (q.includes("news") || q.includes("খবর") || q.includes("সংবাদ")) {
      return {
        title: "Google News - Top Headlines & Current Events",
        snippet: "আজকের প্রধান সংবাদ: বিশ্ব অর্থনীতি শক্তিশালী প্রবৃদ্ধির পথে। প্রযুক্তি খাতের নতুন ঘোষণা বিপুল কর্মসংস্থানের সুযোগ তৈরি করছে। ক্রীড়াঙ্গনে আজকের ফাইনাল ম্যাচের টানটান উত্তেজনা।",
        extra: "Published 10 minutes ago • Technology & Finance section",
        source: "News.google.com",
        voiceText: "আজকের প্রধান সংবাদ: বিশ্ব অর্থনীতি শক্তিশালী প্রবৃদ্ধির পথে। প্রযুক্তি খাতের নতুন ঘোষণা বিপুল কর্মসংস্থানের সুযোগ তৈরি করছে এবং ক্রীড়াঙ্গনে আজকের ফাইনালে টানটান উত্তেজনা।"
      };
    }

    if (q.includes("kaushik") || q.includes("কৌশিক")) {
      return {
        title: "Kaushik Roy - System Director and Coordinator",
        snippet: "Kaushik Roy is an elite technology operator who manages Mimi's advanced visual configurations and Google Space links. Active terminal configurations logged from West Bengal, India.",
        extra: "Verified Identity • System Administrator Panel Active",
        source: "mimi.internal/database",
        voiceText: "Kaushik Roy is an elite technology operator who manages Mimi's advanced visual configurations and Google Space links. Verified identity."
      };
    }

    // Default response using the search term
    return {
      title: `${query} - Google Search Result`,
      snippet: `আমি আপনার জন্য গুগলে "${query}" সার্চ করেছি। অনুসন্ধানের ভিত্তিতে পাওয়া গেছে যে এটি অত্যন্ত গুরুত্বপূর্ণ তথ্যবহুল বিষয়। এর সাথে সম্পর্কিত বিবরণ নিচে লিঙ্কে পাওয়া যাবে।`,
      extra: `Search completed in 0.38 seconds • Integrated with Gemini Smart Core`,
      source: "Wikipedia.org",
      voiceText: `আমি আপনার জন্য গুগলে ${query} সার্চ করেছি। অনুসন্ধানের ভিত্তিতে পাওয়া গেছে যে এটি একটি অত্যন্ত গুরুত্বপূর্ণ তথ্যবহুল বিষয়।`
    };
  };

  const results = getSearchResults();

  const getSpeakingSummary = () => {
    return results.voiceText;
  };

  const currentHost = url ? url.replace(/^https?:\/\/(www\.)?/, "").split("/")[0] : "www.google.com";

  return (
    <div className="w-full rounded-2xl overflow-hidden border border-white/10 bg-[#0c0d0e]/95 shadow-2xl flex flex-col font-sans mb-3 text-white max-w-lg md:max-w-xl self-center mx-auto" id={`browser-frame-${(query || "url").substring(0,5)}`}>
      {/* Search Header / Chrome window frame */}
      <div className="px-4 py-2.5 bg-[#17181c] flex items-center justify-between border-b border-white/5 shrink-0 select-none">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 opacity-80 cursor-pointer hover:opacity-100" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500 opacity-80 cursor-pointer hover:opacity-100" />
          <span className="w-2.5 h-2.5 rounded-full bg-green-500 opacity-80 cursor-pointer hover:opacity-100" />
        </div>
        
        {/* Active Tab */}
        <div className="hidden sm:flex items-center gap-2 bg-[#202124] px-3.5 py-1 rounded-t-lg text-[10px] font-medium text-white/85 border-t border-x border-white/5 -mb-[11px] max-w-[150px] truncate">
          <Search size={10} className="text-cyan-400" />
          <span>{isCustomSite ? results.source : `Google: ${query}`}</span>
        </div>

        <div className="flex items-center gap-3">
          <Monitor size={12} className="text-white/40" />
          <span className="text-[10px] font-mono text-white/30 tracking-widest uppercase">Mimi Virtual Browser</span>
        </div>
      </div>

      {/* Navigation and URL Bar */}
      <div className="px-3 py-2 bg-[#202124] flex items-center gap-3 border-b border-white/5 shrink-0">
        <div className="flex items-center gap-1.5 text-white/50">
          <ArrowLeft size={13} className="hover:text-white cursor-pointer" />
          <ArrowRight size={13} className="opacity-35 cursor-not-allowed" />
          <RefreshCw size={12} className="hover:text-white cursor-pointer ml-1 animate-spin-once" />
        </div>

        {/* Dynamic Address Bar */}
        <div className="flex-1 px-3 py-1 bg-[#151618] rounded-full border border-white/5 flex items-center justify-between gap-2 overflow-hidden select-all">
          <div className="flex items-center gap-2 text-white/45 truncate text-[11px] font-mono">
            <span className={url?.startsWith("https") ? "text-green-400" : "text-yellow-400"}>{url?.startsWith("https") ? "https://" : "http://"}</span>
            <span className="text-white/80">{currentHost}</span>
            {!isCustomSite && <span>/search?q={encodeURIComponent(query)}</span>}
          </div>
          <Search size={10} className="text-white/30 shrink-0" />
        </div>
      </div>

      {/* Main Browser Content View */}
      <div className="p-4 bg-[#0a0a0d] min-h-[180px] flex flex-col justify-start relative scrollbar-hide">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3 flex-1">
            <div className="w-8 h-8 rounded-full border-2 border-cyan-500/20 border-t-cyan-400 animate-spin" />
            <p className="text-xs text-white/40 font-mono tracking-widest uppercase">Connecting to Web Server ...</p>
          </div>
        ) : (
          <div className="flex flex-col gap-4 animate-fade-in-up">
            {/* Browser Identity Line */}
            <div className="flex items-center gap-2 text-white/45 text-xs pb-1 border-b border-white/5">
              {isCustomSite ? (
                <>
                  <span className="font-bold text-violet-400 font-mono">📡</span>
                  <span className="text-[10px] opacity-70">Mimi Interactive Web Extractor Hub</span>
                </>
              ) : (
                <>
                  <span className="font-bold text-red-400">G</span>
                  <span className="font-bold text-blue-400">o</span>
                  <span className="font-bold text-yellow-400">o</span>
                  <span className="font-bold text-blue-400">g</span>
                  <span className="font-bold text-green-400">l</span>
                  <span className="font-bold text-red-400">e</span>
                  <span className="text-[10px] ml-1 opacity-70">Search Engine node</span>
                </>
              )}
            </div>

            {/* Custom Google or Webpage Card Result */}
            <div className="flex flex-col bg-white/[0.02] border border-white/5 p-4 rounded-xl shadow-lg hover:bg-white/[0.04] transition-all">
              <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest mb-1 block">{results.source}</span>
              <a 
                href={url || "#"} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-base font-medium text-cyan-300 hover:underline hover:text-cyan-200 transition-colors flex items-center gap-1.5"
              >
                {results.title}
                <ExternalLink size={12} className="opacity-50" />
              </a>
              <p className="text-xs text-white/75 mt-2 leading-relaxed font-sans max-h-48 overflow-y-auto scrollbar-hide">{results.snippet}</p>
              
              {results.extra && (
                <div className="mt-2 text-[10px] font-mono text-white/40 border-t border-white/5 pt-1.5">
                  {results.extra}
                </div>
              )}
            </div>

            {/* Live TTS vocal reader widget */}
            <div className="flex items-center justify-between border-t border-white/5 pt-3.5 mt-1 shrink-0">
              <div className="flex items-center gap-2.5">
                <button
                  onClick={handleVocalize}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md ${speaking ? 'bg-pink-600 border border-pink-500 text-white animate-pulse' : 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/25'}`}
                >
                  <Volume2 size={13} className={speaking ? "animate-bounce" : ""} />
                  {speaking ? "🔉 Stop Speaking" : "🔊 Listen (শুনুন)"}
                </button>
                <span className="text-[9px] font-mono text-white/30 truncate max-w-[150px] sm:max-w-xs">{speaking ? "Mimi is reading aloud..." : "Press to speak Bengali details"}</span>
              </div>

              {url && (
                <a
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-violet-600/30 hover:bg-violet-600/50 border border-violet-500/40 text-violet-200 transition-colors flex items-center gap-1.5 group cursor-pointer"
                >
                  <span>Browse Full Site</span>
                  <ExternalLink size={11} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
