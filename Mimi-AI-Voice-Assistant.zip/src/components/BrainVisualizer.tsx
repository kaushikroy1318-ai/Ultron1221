import React, { useRef, useEffect, useState, useMemo } from "react";
import * as THREE from "three";

interface BrainVisualizerProps {
  appState: "idle" | "connecting" | "listening" | "thinking" | "processing" | "speaking" | "upgrading";
  theme?: "crimson" | "forest" | "charcoal" | "violet" | "cyan" | "gold";
}

export const BrainVisualizer: React.FC<BrainVisualizerProps> = ({ 
  appState, 
  theme = "violet" 
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [useFallback2D, setUseFallback2D] = useState(false);

  // Theme palettes with vibrant primary and secondary colors
  const themePalette = useMemo(() => {
    switch (theme) {
      case "crimson":
        return {
          primaryHex: "#ef4444",
          secondaryHex: "#f43f5e",
          accentHex: "#fda4af",
          glowRgb: "239, 68, 68",
          threeColor: new THREE.Color("#ef4444"),
        };
      case "forest":
        return {
          primaryHex: "#10b981",
          secondaryHex: "#059669",
          accentHex: "#6ee7b7",
          glowRgb: "16, 185, 129",
          threeColor: new THREE.Color("#10b981"),
        };
      case "charcoal":
        return {
          primaryHex: "#38bdf8",
          secondaryHex: "#818cf8",
          accentHex: "#e2e8f0",
          glowRgb: "56, 189, 248",
          threeColor: new THREE.Color("#38bdf8"),
        };
      case "cyan":
        return {
          primaryHex: "#06b6d4",
          secondaryHex: "#3b82f6",
          accentHex: "#67e8f9",
          glowRgb: "6, 182, 212",
          threeColor: new THREE.Color("#06b6d4"),
        };
      case "gold":
        return {
          primaryHex: "#f59e0b",
          secondaryHex: "#ea580c",
          accentHex: "#fde68a",
          glowRgb: "245, 158, 11",
          threeColor: new THREE.Color("#f59e0b"),
        };
      case "violet":
      default:
        return {
          primaryHex: "#a855f7",
          secondaryHex: "#ec4899",
          accentHex: "#c084fc",
          glowRgb: "168, 85, 247",
          threeColor: new THREE.Color("#a855f7"),
        };
    }
  }, [theme]);

  // Safe WebGL Support Detector
  const isWebGLAvailable = () => {
    try {
      const probeCanvas = document.createElement("canvas");
      const gl = (probeCanvas.getContext("webgl2") || probeCanvas.getContext("webgl") || probeCanvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
      if (!gl) return false;
      const loseContext = gl.getExtension("WEBGL_lose_context");
      if (loseContext) loseContext.loseContext();
      return true;
    } catch {
      return false;
    }
  };

  // -------------------------------------------------------------
  // THREE.js WebGL Engine (when available and not blocked)
  // -------------------------------------------------------------
  useEffect(() => {
    if (useFallback2D) return;

    if (!isWebGLAvailable()) {
      console.warn("WebGL not supported or disabled in environment, activating 3D Canvas Fallback engine.");
      setUseFallback2D(true);
      return;
    }

    if (!containerRef.current) return;

    let renderer: THREE.WebGLRenderer | null = null;
    let scene: THREE.Scene | null = null;
    let camera: THREE.PerspectiveCamera | null = null;
    let points: THREE.Points | null = null;
    let lines: THREE.LineSegments | null = null;
    let animFrameId = 0;

    try {
      scene = new THREE.Scene();
      camera = new THREE.PerspectiveCamera(60, 1, 0.1, 1000);
      camera.position.z = 6;

      renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: false,
        powerPreference: "default",
        preserveDrawingBuffer: false,
      });

      const domElement = renderer.domElement;
      
      // Handle WebGL context loss gracefully so the page never blocks
      domElement.addEventListener("webglcontextlost", (e) => {
        e.preventDefault();
        console.warn("WebGL context lost event caught. Switching to 2D Fallback visualizer.");
        setUseFallback2D(true);
      }, false);

      renderer.setPixelRatio(1);
      const width = containerRef.current.clientWidth || 800;
      const height = containerRef.current.clientHeight || 600;
      renderer.setSize(width, height);
      containerRef.current.innerHTML = "";
      containerRef.current.appendChild(domElement);

      // Generate Dual-Lobe 3D Brain Geometry with Multi-color Particles
      const particleCount = 1200;
      const positions: number[] = [];
      const particleColors: number[] = [];
      const linePositions: number[] = [];
      const brainPoints: THREE.Vector3[] = [];

      const colPrimary = themePalette.threeColor;
      const colSecondary = new THREE.Color(themePalette.secondaryHex);
      const colAccent = new THREE.Color(themePalette.accentHex);

      for (let i = 0; i < particleCount; i++) {
        const lobe = i < particleCount / 2 ? -1 : 1;
        const u = Math.random();
        const v = Math.random();
        const theta = 2 * Math.PI * u;
        const phi = Math.acos(2 * v - 1);

        let x = 1.7 * Math.sin(phi) * Math.cos(theta);
        let y = 1.2 * Math.sin(phi) * Math.sin(theta);
        let z = 1.3 * Math.cos(phi);

        x += lobe * 1.05;
        const wave = Math.sin(x * 3.5) * Math.cos(y * 3.5) * Math.sin(z * 3.5);
        const factor = 1 + wave * 0.22;

        const p = new THREE.Vector3(x * factor, y * factor, z * factor);
        positions.push(p.x, p.y, p.z);
        brainPoints.push(p);

        // Gradient color across lobes
        const t = (p.x + 2.5) / 5.0;
        const c = Math.random() > 0.4 ? colPrimary.clone().lerp(colSecondary, t) : colAccent;
        particleColors.push(c.r, c.g, c.b);
      }

      // Connect near points with glowing synapses
      for (let i = 0; i < 280; i++) {
        const p1 = brainPoints[Math.floor(Math.random() * brainPoints.length)];
        const p2 = brainPoints[Math.floor(Math.random() * brainPoints.length)];
        if (p1.distanceTo(p2) < 0.95) {
          linePositions.push(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z);
        }
      }

      const pGeo = new THREE.BufferGeometry();
      pGeo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
      pGeo.setAttribute("color", new THREE.Float32BufferAttribute(particleColors, 3));

      const pMat = new THREE.PointsMaterial({
        size: 0.05,
        vertexColors: true,
        transparent: true,
        opacity: 0.8,
        blending: THREE.AdditiveBlending,
      });

      points = new THREE.Points(pGeo, pMat);
      scene.add(points);

      const lGeo = new THREE.BufferGeometry();
      lGeo.setAttribute("position", new THREE.Float32BufferAttribute(linePositions, 3));
      const lMat = new THREE.LineBasicMaterial({
        color: themePalette.threeColor,
        transparent: true,
        opacity: 0.25,
        blending: THREE.AdditiveBlending,
      });

      lines = new THREE.LineSegments(lGeo, lMat);
      scene.add(lines);

      const handleResize = () => {
        if (!containerRef.current || !camera || !renderer) return;
        const w = containerRef.current.clientWidth;
        const h = containerRef.current.clientHeight;
        if (w === 0 || h === 0) return;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };

      window.addEventListener("resize", handleResize);

      // Animation Loop
      const animate = () => {
        if (!renderer || !scene || !camera || !points || !lines) return;
        animFrameId = requestAnimationFrame(animate);

        const time = Date.now() * 0.001;
        const rotationSpeed = (appState === "processing" || appState === "thinking" || appState === "connecting") ? 0.6 : 0.25;
        points.rotation.y = time * rotationSpeed;
        points.rotation.x = Math.sin(time * 0.2) * 0.15;
        lines.rotation.copy(points.rotation);

        const pulseFreq = appState === "speaking" ? 6 : appState === "listening" ? 4 : 2;
        const pulseAmp = appState === "speaking" ? 0.06 : 0.03;
        const s = 1 + Math.sin(time * pulseFreq) * pulseAmp;
        points.scale.set(s, s, s);
        lines.scale.set(s, s, s);

        renderer.render(scene, camera);
      };

      animate();

      return () => {
        window.removeEventListener("resize", handleResize);
        if (animFrameId) cancelAnimationFrame(animFrameId);
        if (renderer && renderer.domElement && renderer.domElement.parentNode) {
          renderer.domElement.parentNode.removeChild(renderer.domElement);
        }
        pGeo.dispose();
        pMat.dispose();
        lGeo.dispose();
        lMat.dispose();
        renderer?.dispose();
      };
    } catch (err) {
      console.error("Three.js init failed safely, falling back to 2D Canvas:", err);
      setUseFallback2D(true);
    }
  }, [useFallback2D, themePalette, appState]);

  // -------------------------------------------------------------
  // High-Performance 2D Canvas 3D-Projected Brain Fallback Engine
  // -------------------------------------------------------------
  useEffect(() => {
    if (!useFallback2D || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId = 0;
    const particleCount = 450;
    interface Point3D {
      x: number;
      y: number;
      z: number;
      color: string;
      size: number;
    }

    const points: Point3D[] = [];
    const colorsList = [
      themePalette.primaryHex,
      themePalette.secondaryHex,
      themePalette.accentHex,
      "#ffffff",
    ];

    for (let i = 0; i < particleCount; i++) {
      const lobe = i < particleCount / 2 ? -1 : 1;
      const u = Math.random();
      const v = Math.random();
      const theta = 2 * Math.PI * u;
      const phi = Math.acos(2 * v - 1);

      let x = 1.6 * Math.sin(phi) * Math.cos(theta);
      let y = 1.1 * Math.sin(phi) * Math.sin(theta);
      let z = 1.3 * Math.cos(phi);

      x += lobe * 1.0;
      const wave = Math.sin(x * 3) * Math.cos(y * 3) * Math.sin(z * 3);
      const factor = 1 + wave * 0.2;

      points.push({
        x: x * factor,
        y: y * factor,
        z: z * factor,
        color: colorsList[Math.floor(Math.random() * colorsList.length)],
        size: Math.random() * 2 + 1.2,
      });
    }

    let angleY = 0;
    let angleX = 0;

    const render = () => {
      animId = requestAnimationFrame(render);
      const w = (canvas.width = canvas.clientWidth || 800);
      const h = (canvas.height = canvas.clientHeight || 600);
      ctx.clearRect(0, 0, w, h);

      const rotSpeed = (appState === "processing" || appState === "thinking" || appState === "connecting") ? 0.025 : 0.008;
      angleY += rotSpeed;
      angleX = Math.sin(angleY * 0.5) * 0.2;

      const cosY = Math.cos(angleY);
      const sinY = Math.sin(angleY);
      const cosX = Math.cos(angleX);
      const sinX = Math.sin(angleX);

      const fov = 350;
      const cx = w / 2;
      const cy = h / 2;

      const projected: { px: number; py: number; pz: number; pt: Point3D }[] = [];

      for (const p of points) {
        // Rotate around Y
        let x1 = p.x * cosY - p.z * sinY;
        let z1 = p.z * cosY + p.x * sinY;

        // Rotate around X
        let y2 = p.y * cosX - z1 * sinX;
        let z2 = z1 * cosX + p.y * sinX + 5.0; // Distance

        if (z2 > 0.1) {
          const scale = fov / z2;
          const px = cx + x1 * scale;
          const py = cy + y2 * scale;
          projected.push({ px, py, pz: z2, pt: p });
        }
      }

      // Sort by depth for correct opacity blending
      projected.sort((a, b) => b.pz - a.pz);

      // Draw synaptic connections between nearby points
      ctx.lineWidth = 0.8;
      for (let i = 0; i < projected.length; i += 3) {
        for (let j = i + 1; j < Math.min(i + 8, projected.length); j++) {
          const dx = projected[i].px - projected[j].px;
          const dy = projected[i].py - projected[j].py;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 45) {
            const alpha = (1 - dist / 45) * 0.25;
            ctx.strokeStyle = `rgba(${themePalette.glowRgb}, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(projected[i].px, projected[i].py);
            ctx.lineTo(projected[j].px, projected[j].py);
            ctx.stroke();
          }
        }
      }

      // Draw particles
      for (const p of projected) {
        const radius = Math.max(0.8, (p.pt.size * fov) / (p.pz * 60));
        const alpha = Math.min(1, Math.max(0.2, 1 - (p.pz - 3.5) / 4));

        ctx.fillStyle = p.pt.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.px, p.py, radius, 0, Math.PI * 2);
        ctx.fill();

        // Extra glow on closer nodes
        if (p.pz < 4.8) {
          ctx.shadowColor = themePalette.primaryHex;
          ctx.shadowBlur = 6;
        } else {
          ctx.shadowBlur = 0;
        }
      }
      ctx.globalAlpha = 1.0;
      ctx.shadowBlur = 0;
    };

    render();

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [useFallback2D, themePalette, appState]);

  return (
    <div className="w-full h-full absolute inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Three.js Container */}
      {!useFallback2D && (
        <div ref={containerRef} className="w-full h-full absolute inset-0 opacity-80" />
      )}

      {/* 2D Canvas Fallback */}
      {useFallback2D && (
        <canvas ref={canvasRef} className="w-full h-full absolute inset-0 opacity-80" />
      )}
    </div>
  );
};
export default BrainVisualizer;
