import React, { useCallback, useEffect, useState } from "react";
import { AlertCircle, Check, ChevronDown, Loader2 } from "lucide-react";
import {
  clearServerConnection,
  getAccessToken,
  getServerUrl,
  isNativeApp,
  saveServerConnection,
  testServerConnection,
} from "../lib/apiBase";

interface ProviderStatus {
  id: string;
  label: string;
  kind: string;
  configured: boolean;
  source: "app" | "server" | "none";
  keyHint: string;
  model: string;
  defaultModel: string;
  baseUrl: string;
  defaultBaseUrl: string;
}

interface Draft {
  apiKey: string;
  model: string;
  baseUrl: string;
}

interface Props {
  preferences: Record<string, any>;
  onUpdatePreference: (key: string, value: any) => void;
}

const MAIN_MODELS = ["gemini", "claude", "chatgpt", "kimi"];
const MORE_MODELS = ["grok", "deepseek", "mistral", "qwen"];

const card = "rounded-3xl border border-white/5 bg-neutral-950/40";
const input =
  "w-full rounded-xl bg-white/5 border border-white/10 px-3.5 py-3 text-sm text-white placeholder-white/30 outline-none focus:border-violet-400/60 focus:ring-2 focus:ring-violet-400/20";
const smallBtn =
  "rounded-xl px-4 py-2.5 text-sm font-semibold transition-colors disabled:opacity-50 active:scale-[0.98]";

function Switch({ on, onChange, label }: { on: boolean; onChange: () => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onChange}
      className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${on ? "bg-violet-500" : "bg-white/15"}`}
    >
      <span className={`absolute top-1 h-5 w-5 rounded-full bg-white transition-all ${on ? "left-6" : "left-1"}`} />
    </button>
  );
}

export default function ApiKeysPanel({ preferences, onUpdatePreference }: Props) {
  // ---- server connection
  const [serverUrl, setServerUrl] = useState(getServerUrl());
  const [token, setToken] = useState(getAccessToken());
  const [connBusy, setConnBusy] = useState(false);
  const [connMsg, setConnMsg] = useState<{ ok: boolean; text: string } | null>(null);

  // ---- models
  const [providers, setProviders] = useState<ProviderStatus[]>([]);
  const [canSaveKeys, setCanSaveKeys] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [busy, setBusy] = useState<Record<string, string>>({});
  const [rowMsg, setRowMsg] = useState<Record<string, { ok: boolean; text: string }>>({});

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError("");
    try {
      const res = await fetch("/api/ensemble/status");
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setProviders([]);
        setLoadError(data?.error || `The server answered with an error (${res.status}).`);
      } else {
        setProviders(data.providers || []);
        setCanSaveKeys(Boolean(data.canSaveKeys));
      }
    } catch {
      setProviders([]);
      setLoadError("Could not reach the server. Check the address above.");
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const saveConnection = async () => {
    setConnBusy(true);
    setConnMsg(null);
    const result = await testServerConnection(serverUrl || window.location.origin, token);
    setConnMsg({ ok: result.ok, text: result.message });
    if (result.ok) {
      saveServerConnection(serverUrl, token);
      await load();
    }
    setConnBusy(false);
  };

  const resetConnection = () => {
    clearServerConnection();
    setServerUrl("");
    setToken("");
    setConnMsg({ ok: true, text: "Connection cleared." });
    if (isNativeApp()) window.location.reload();
  };

  const toggleRow = (p: ProviderStatus) => {
    if (open === p.id) {
      setOpen(null);
      return;
    }
    setDrafts((d) => ({
      ...d,
      [p.id]: {
        apiKey: "",
        model: p.model === p.defaultModel ? "" : p.model,
        baseUrl: p.baseUrl === p.defaultBaseUrl ? "" : p.baseUrl,
      },
    }));
    setOpen(p.id);
  };

  const setDraft = (id: string, patch: Partial<Draft>) =>
    setDrafts((d) => ({ ...d, [id]: { ...(d[id] || { apiKey: "", model: "", baseUrl: "" }), ...patch } }));

  const post = async (path: string, body: any) => {
    const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json().catch(() => ({}));
    return { res, data };
  };

  const save = async (p: ProviderStatus) => {
    const d = drafts[p.id] || { apiKey: "", model: "", baseUrl: "" };
    setBusy((b) => ({ ...b, [p.id]: "save" }));
    setRowMsg((m) => ({ ...m, [p.id]: undefined as any }));
    try {
      const { res, data } = await post("/api/ensemble/keys", {
        provider: p.id,
        apiKey: d.apiKey,
        model: d.model,
        ...(p.kind === "openai" ? { baseUrl: d.baseUrl } : {}),
      });
      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setRowMsg((m) => ({ ...m, [p.id]: { ok: true, text: "Saved. Tap Test to check it works." } }));
      setDraft(p.id, { apiKey: "" });
      await load();
    } catch (e: any) {
      setRowMsg((m) => ({ ...m, [p.id]: { ok: false, text: e?.message || "Could not save." } }));
    }
    setBusy((b) => ({ ...b, [p.id]: "" }));
  };

  const test = async (p: ProviderStatus) => {
    setBusy((b) => ({ ...b, [p.id]: "test" }));
    setRowMsg((m) => ({ ...m, [p.id]: undefined as any }));
    try {
      const { res, data } = await post("/api/ensemble/test", { provider: p.id });
      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setRowMsg((m) => ({
        ...m,
        [p.id]: data.ok
          ? { ok: true, text: `Works. Answered in ${(data.ms / 1000).toFixed(1)}s.` }
          : { ok: false, text: data.error || "The model did not answer." },
      }));
    } catch (e: any) {
      setRowMsg((m) => ({ ...m, [p.id]: { ok: false, text: e?.message || "Test failed." } }));
    }
    setBusy((b) => ({ ...b, [p.id]: "" }));
  };

  const remove = async (p: ProviderStatus) => {
    setBusy((b) => ({ ...b, [p.id]: "remove" }));
    try {
      const { res, data } = await post("/api/ensemble/keys", { provider: p.id, remove: true });
      if (!res.ok) throw new Error(data?.error || `Error ${res.status}`);
      setRowMsg((m) => ({ ...m, [p.id]: { ok: true, text: "Key removed from the server." } }));
      await load();
    } catch (e: any) {
      setRowMsg((m) => ({ ...m, [p.id]: { ok: false, text: e?.message || "Could not remove." } }));
    }
    setBusy((b) => ({ ...b, [p.id]: "" }));
  };

  // ---- fusion
  const fusionOn = Boolean(preferences?.multiAiCollaboration);
  const ready = providers.filter((p) => p.configured);
  const chosen: string[] = Array.isArray(preferences?.fusionModels) ? preferences.fusionModels : [];
  const isIncluded = (id: string) => chosen.length === 0 || chosen.includes(id);
  const toggleIncluded = (id: string) => {
    const base = chosen.length === 0 ? ready.map((p) => p.id) : chosen;
    const next = base.includes(id) ? base.filter((x) => x !== id) : [...base, id];
    onUpdatePreference("fusionModels", next.length === ready.length ? [] : next);
  };

  const renderRow = (id: string) => {
    const p = providers.find((x) => x.id === id);
    if (!p) return null;
    const d = drafts[p.id] || { apiKey: "", model: "", baseUrl: "" };
    const expanded = open === p.id;
    const working = busy[p.id];
    const msg = rowMsg[p.id];
    return (
      <div key={p.id} className={card}>
        <button
          type="button"
          onClick={() => toggleRow(p)}
          aria-expanded={expanded}
          className="flex w-full items-center justify-between gap-3 p-4 text-left"
        >
          <div className="min-w-0">
            <div className="text-[15px] font-bold text-white">{p.label}</div>
            <div className="mt-0.5 truncate text-xs text-white/45">
              {p.configured ? `${p.model} · key ${p.keyHint}` : "No key yet"}
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span
              className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                p.configured ? "bg-emerald-500/15 text-emerald-300" : "bg-white/8 text-white/50"
              }`}
            >
              {p.configured ? (p.source === "server" ? "Ready (server)" : "Ready") : "Not set"}
            </span>
            <ChevronDown size={16} className={`text-white/50 transition-transform ${expanded ? "rotate-180" : ""}`} />
          </div>
        </button>

        {expanded && (
          <div className="space-y-3 border-t border-white/5 p-4 pt-3">
            <div>
              <label className="mb-1 block text-xs font-semibold text-white/60" htmlFor={`k-${p.id}`}>
                API key
              </label>
              <input
                id={`k-${p.id}`}
                type="password"
                className={input}
                value={d.apiKey}
                onChange={(e) => setDraft(p.id, { apiKey: e.target.value })}
                placeholder={p.configured ? `Saved ${p.keyHint}. Paste a new key to replace it` : "Paste your API key"}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-white/60" htmlFor={`m-${p.id}`}>
                Model name
              </label>
              <input
                id={`m-${p.id}`}
                className={input}
                value={d.model}
                onChange={(e) => setDraft(p.id, { model: e.target.value })}
                placeholder={p.defaultModel || "Default"}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
              />
              <p className="mt-1 text-xs text-white/40">Leave empty to use the default. Providers rename models often, so change it here if a test fails.</p>
            </div>
            {p.kind === "openai" && (
              <div>
                <label className="mb-1 block text-xs font-semibold text-white/60" htmlFor={`u-${p.id}`}>
                  Endpoint
                </label>
                <input
                  id={`u-${p.id}`}
                  className={input}
                  value={d.baseUrl}
                  onChange={(e) => setDraft(p.id, { baseUrl: e.target.value })}
                  placeholder={p.defaultBaseUrl}
                  inputMode="url"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                />
              </div>
            )}

            <div className="flex flex-wrap gap-2 pt-1">
              <button
                type="button"
                onClick={() => save(p)}
                disabled={Boolean(working) || !canSaveKeys}
                className={`${smallBtn} bg-violet-500 text-white`}
              >
                {working === "save" ? "Saving…" : "Save"}
              </button>
              <button
                type="button"
                onClick={() => test(p)}
                disabled={Boolean(working) || !p.configured}
                className={`${smallBtn} bg-white/10 text-white`}
              >
                {working === "test" ? "Testing…" : "Test"}
              </button>
              {p.source === "app" && (
                <button
                  type="button"
                  onClick={() => remove(p)}
                  disabled={Boolean(working)}
                  className={`${smallBtn} bg-red-500/15 text-red-300`}
                >
                  Remove key
                </button>
              )}
            </div>

            {p.source === "server" && (
              <p className="text-xs text-white/40">This key comes from the server’s environment variables. Saving a new one here overrides it.</p>
            )}
            {msg && (
              <p role="status" className={`flex items-start gap-1.5 text-sm ${msg.ok ? "text-emerald-300" : "text-red-300"}`}>
                {msg.ok ? <Check size={16} className="mt-0.5 shrink-0" /> : <AlertCircle size={16} className="mt-0.5 shrink-0" />}
                <span>{msg.text}</span>
              </p>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      {/* 1. Server */}
      <section aria-labelledby="srv-h">
        <h3 id="srv-h" className="text-lg font-bold text-white">
          Server connection
        </h3>
        <p className="mt-1 text-sm leading-relaxed text-white/50">
          {isNativeApp()
            ? "Mimi’s brain runs on your server. Your AI keys are stored there, never on this phone."
            : "Leave the address empty to use the server that opened this page."}
        </p>
        <div className={`${card} mt-3 space-y-3 p-4`}>
          <div>
            <label className="mb-1 block text-xs font-semibold text-white/60" htmlFor="conn-url">
              Server address
            </label>
            <input
              id="conn-url"
              className={input}
              value={serverUrl}
              onChange={(e) => setServerUrl(e.target.value)}
              placeholder={isNativeApp() ? "https://your-mimi-server.onrender.com" : "Same as this website"}
              inputMode="url"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
            />
          </div>
          <div>
            <label className="mb-1 block text-xs font-semibold text-white/60" htmlFor="conn-token">
              Access token
            </label>
            <input
              id="conn-token"
              type="password"
              className={input}
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="MIMI_ACCESS_TOKEN from your server"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={saveConnection} disabled={connBusy} className={`${smallBtn} bg-violet-500 text-white`}>
              {connBusy ? "Checking…" : "Test and save"}
            </button>
            <button type="button" onClick={resetConnection} disabled={connBusy} className={`${smallBtn} bg-white/10 text-white`}>
              Clear
            </button>
          </div>
          {connMsg && (
            <p role="status" className={`text-sm ${connMsg.ok ? "text-emerald-300" : "text-red-300"}`}>
              {connMsg.text}
            </p>
          )}
        </div>
      </section>

      {/* 2. Models */}
      <section aria-labelledby="mdl-h">
        <h3 id="mdl-h" className="text-lg font-bold text-white">
          AI models
        </h3>
        <p className="mt-1 text-sm leading-relaxed text-white/50">
          Add a key for each model you want Mimi to use. A model with no key is simply skipped. If your host forgets saved keys after a restart (common on free plans), put them in the server’s environment variables instead.
        </p>

        {!canSaveKeys && !loading && !loadError && (
          <p className="mt-3 rounded-2xl border border-amber-400/20 bg-amber-400/10 p-3 text-sm text-amber-200">
            Saving keys from the app is off. Set MIMI_ACCESS_TOKEN on the server (or KEYSTORE_SECRET) to turn it on, or put the keys in the server’s environment variables.
          </p>
        )}

        {loading && (
          <p className="mt-4 flex items-center gap-2 text-sm text-white/50">
            <Loader2 size={16} className="animate-spin" /> Loading models…
          </p>
        )}
        {loadError && (
          <div className="mt-3 rounded-2xl border border-red-400/20 bg-red-400/10 p-3 text-sm text-red-200">
            <p>{loadError}</p>
            <button type="button" onClick={load} className={`${smallBtn} mt-2 bg-white/10 text-white`}>
              Try again
            </button>
          </div>
        )}

        {!loading && !loadError && (
          <div className="mt-3 space-y-2.5">
            {MAIN_MODELS.map(renderRow)}
            <details className="group pt-1">
              <summary className="cursor-pointer list-none rounded-2xl px-1 py-2 text-sm font-semibold text-white/60 hover:text-white">
                More models
              </summary>
              <div className="mt-2 space-y-2.5">{MORE_MODELS.map(renderRow)}</div>
            </details>
          </div>
        )}
      </section>

      {/* 3. Fusion */}
      <section aria-labelledby="fus-h">
        <h3 id="fus-h" className="text-lg font-bold text-white">
          Fusion mode
        </h3>
        <div className={`${card} mt-3 space-y-4 p-4`}>
          <div className="flex items-start justify-between gap-4">
            <p className="text-sm leading-relaxed text-white/60">
              Mimi asks every ready model at the same time, then merges the best parts into one answer and speaks it.
            </p>
            <Switch on={fusionOn} onChange={() => onUpdatePreference("multiAiCollaboration", !fusionOn)} label="Fusion mode" />
          </div>

          {fusionOn && ready.length < 2 && (
            <p className="text-sm text-amber-200">Fusion needs at least two models with keys. Until then Mimi answers with the one you have.</p>
          )}

          {fusionOn && ready.length >= 2 && (
            <div>
              <div className="mb-2 text-xs font-semibold text-white/60">Models in fusion</div>
              <div className="flex flex-wrap gap-2">
                {ready.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    aria-pressed={isIncluded(p.id)}
                    onClick={() => toggleIncluded(p.id)}
                    className={`rounded-full px-3.5 py-2 text-sm font-semibold transition-colors ${
                      isIncluded(p.id) ? "bg-violet-500 text-white" : "bg-white/8 text-white/50"
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
