import React, { useState, useEffect, useRef } from "react";
import { ArrowRight, Link, Zap, Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export interface TimelineItem {
  id: number;
  title: string;
  date: string;
  content: string;
  category: string;
  icon: React.ElementType;
  relatedIds: number[];
  status: "completed" | "in-progress" | "pending";
  energy: number;
}

interface RadialOrbitalTimelineProps {
  timelineData: TimelineItem[];
  themeColor?: string;
}

export default function RadialOrbitalTimeline({
  timelineData,
  themeColor = "violet",
}: RadialOrbitalTimelineProps) {
  const [expandedItems, setExpandedItems] = useState<Record<number, boolean>>(
    {}
  );
  const [viewMode] = useState<"orbital">("orbital");
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [pulseEffect, setPulseEffect] = useState<Record<number, boolean>>({});
  const [centerOffset] = useState<{ x: number; y: number }>({
    x: 0,
    y: 0,
  });
  const [activeNodeId, setActiveNodeId] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const orbitRef = useRef<HTMLDivElement>(null);
  const nodeRefs = useRef<Record<number, HTMLDivElement | null>>({});

  const [projections, setProjections] = useState<Record<number, string>>({});
  const [synthesizingId, setSynthesizingId] = useState<number | null>(null);

  const handleSynthesize = async (id: number, title: string) => {
    setSynthesizingId(id);
    try {
      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `You are the Mimi AI system. Give a brief, high-level, highly technical but humorous futuristic Bengali prediction (1-2 sentences, mix English/Bengali) about the progression of the milestone node: "${title}". End with a dynamic system sync phrase.`
        })
      });
      if (response.ok) {
        const data = await response.json();
        setProjections(prev => ({ ...prev, [id]: data.text }));
      } else {
        setProjections(prev => ({ ...prev, [id]: "সিস্টেম সংযোগ সাময়িক ওভারলোড। পুনরায় চেষ্টা করুন।" }));
      }
    } catch (e) {
      setProjections(prev => ({ ...prev, [id]: "কোর ব্রেইন সংযোগে সমস্যা ধরা পড়েছে।" }));
    } finally {
      setSynthesizingId(null);
    }
  };

  const handleContainerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === containerRef.current || e.target === orbitRef.current) {
      setExpandedItems({});
      setActiveNodeId(null);
      setPulseEffect({});
      setAutoRotate(true);
    }
  };

  const toggleItem = (id: number) => {
    setExpandedItems((prev) => {
      const newState = { ...prev };
      Object.keys(newState).forEach((key) => {
        if (parseInt(key) !== id) {
          newState[parseInt(key)] = false;
        }
      });

      newState[id] = !prev[id];

      if (!prev[id]) {
        setActiveNodeId(id);
        setAutoRotate(false);

        const relatedItems = getRelatedItems(id);
        const newPulseEffect: Record<number, boolean> = {};
        relatedItems.forEach((relId) => {
          newPulseEffect[relId] = true;
        });
        setPulseEffect(newPulseEffect);

        centerViewOnNode(id);
      } else {
        setActiveNodeId(null);
        setAutoRotate(true);
        setPulseEffect({});
      }

      return newState;
    });
  };

  useEffect(() => {
    let rotationTimer: any;

    if (autoRotate && viewMode === "orbital") {
      rotationTimer = setInterval(() => {
        setRotationAngle((prev) => {
          const newAngle = (prev + 0.3) % 360;
          return Number(newAngle.toFixed(3));
        });
      }, 50);
    }

    return () => {
      if (rotationTimer) {
        clearInterval(rotationTimer);
      }
    };
  }, [autoRotate, viewMode]);

  const centerViewOnNode = (nodeId: number) => {
    if (viewMode !== "orbital" || !nodeRefs.current[nodeId]) return;

    const nodeIndex = timelineData.findIndex((item) => item.id === nodeId);
    const totalNodes = timelineData.length;
    const targetAngle = (nodeIndex / totalNodes) * 360;

    setRotationAngle(270 - targetAngle);
  };

  const calculateNodePosition = (index: number, total: number) => {
    const angle = ((index / total) * 360 + rotationAngle) % 360;
    const radius = 200;
    const radian = (angle * Math.PI) / 180;

    const x = radius * Math.cos(radian) + centerOffset.x;
    const y = radius * Math.sin(radian) + centerOffset.y;

    const zIndex = Math.round(100 + 50 * Math.cos(radian));
    const opacity = Math.max(
      0.85,
      Math.min(1, 0.85 + 0.15 * ((1 + Math.sin(radian)) / 2))
    );

    return { x, y, angle, zIndex, opacity };
  };

  const getRelatedItems = (itemId: number): number[] => {
    const currentItem = timelineData.find((item) => item.id === itemId);
    return currentItem ? currentItem.relatedIds : [];
  };

  const isRelatedToActive = (itemId: number): boolean => {
    if (!activeNodeId) return false;
    const relatedItems = getRelatedItems(activeNodeId);
    return relatedItems.includes(itemId);
  };

  const getStatusStyles = (status: TimelineItem["status"]): string => {
    switch (status) {
      case "completed":
        return "text-white bg-black border-white";
      case "in-progress":
        return "text-black bg-white border-black";
      case "pending":
        return "text-white bg-black/40 border-white/50";
      default:
        return "text-white bg-black/40 border-white/50";
    }
  };

  const getTimelineThemeColors = (color: string) => {
    switch (color) {
      case "gold":
        return {
          centerGrad: "from-amber-500 via-orange-500 to-yellow-600",
          centerShadow: "shadow-[0_0_20px_rgba(245,158,11,0.6)]",
          orbitBorder: "border-amber-500/20 shadow-[0_0_20px_rgba(245,158,11,0.15)]",
          pingBorder1: "border-amber-500/40",
          pingBorder2: "border-orange-500/30",
          textCenter: "text-amber-500",
          activeBg: "bg-gradient-to-r from-amber-500 to-orange-500 text-black",
          activeBorder: "border-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.6)]",
          normalBg: "bg-slate-950 text-amber-300 border border-amber-500/40",
          itemBorder: "border-amber-500/40 hover:border-amber-300 animate-pulse",
          cardBorder: "border-amber-500/40 shadow-amber-500/25",
          connectorLine: "bg-amber-400",
          textActive: "text-amber-300 text-shadow-[0_0_8px_rgba(245,158,11,0.4)]"
        };
      case "cyan":
        return {
          centerGrad: "from-cyan-500 via-teal-500 to-blue-600",
          centerShadow: "shadow-[0_0_20px_rgba(6,182,212,0.6)]",
          orbitBorder: "border-cyan-500/25 shadow-[0_0_20px_rgba(6,182,212,0.1)]",
          pingBorder1: "border-cyan-500/40",
          pingBorder2: "border-blue-500/30",
          textCenter: "text-cyan-600",
          activeBg: "bg-gradient-to-r from-cyan-500 to-blue-500 text-black",
          activeBorder: "border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.6)]",
          normalBg: "bg-slate-950 text-cyan-300 border border-cyan-500/40",
          itemBorder: "border-cyan-500/40 hover:border-cyan-300 animate-pulse",
          cardBorder: "border-cyan-500/40 shadow-cyan-500/25",
          connectorLine: "bg-cyan-400",
          textActive: "text-cyan-300 text-shadow-[0_0_8px_rgba(6,182,212,0.4)]"
        };
      case "emerald":
        return {
          centerGrad: "from-emerald-500 via-green-500 to-teal-500",
          centerShadow: "shadow-[0_0_20px_rgba(16,185,129,0.6)]",
          orbitBorder: "border-emerald-500/25 shadow-[0_0_20px_rgba(16,185,129,0.1)]",
          pingBorder1: "border-emerald-500/40",
          pingBorder2: "border-teal-500/30",
          textCenter: "text-emerald-600",
          activeBg: "bg-gradient-to-r from-emerald-500 to-teal-500 text-black",
          activeBorder: "border-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.6)]",
          normalBg: "bg-slate-950 text-emerald-300 border border-emerald-500/40",
          itemBorder: "border-emerald-500/40 hover:border-emerald-300 animate-pulse",
          cardBorder: "border-emerald-500/40 shadow-emerald-500/25",
          connectorLine: "bg-emerald-400",
          textActive: "text-emerald-300 text-shadow-[0_0_8px_rgba(16,185,129,0.4)]"
        };
      case "crimson":
        return {
          centerGrad: "from-rose-500 via-pink-600 to-red-600",
          centerShadow: "shadow-[0_0_20px_rgba(244,63,94,0.6)]",
          orbitBorder: "border-rose-500/25 shadow-[0_0_20px_rgba(244,63,94,0.1)]",
          pingBorder1: "border-rose-500/40",
          pingBorder2: "border-red-500/30",
          textCenter: "text-rose-600",
          activeBg: "bg-gradient-to-r from-rose-500 to-red-500 text-white",
          activeBorder: "border-rose-300 shadow-[0_0_15px_rgba(244,63,94,0.6)]",
          normalBg: "bg-slate-950 text-rose-300 border border-rose-500/40",
          itemBorder: "border-rose-500/40 hover:border-rose-300 animate-pulse",
          cardBorder: "border-rose-500/40 shadow-rose-500/25",
          connectorLine: "bg-rose-400",
          textActive: "text-rose-300 text-shadow-[0_0_8px_rgba(244,63,94,0.4)]"
        };
      case "violet":
      default:
        return {
          centerGrad: "from-violet-500 via-cyan-500 to-fuchsia-500",
          centerShadow: "shadow-[0_0_20px_rgba(139,92,246,0.6)]",
          orbitBorder: "border-violet-500/25 shadow-[0_0_20px_rgba(139,92,246,0.1)]",
          pingBorder1: "border-violet-500/40",
          pingBorder2: "border-cyan-500/30",
          textCenter: "text-violet-600",
          activeBg: "bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white",
          activeBorder: "border-cyan-300 shadow-[0_0_15px_rgba(167,139,250,0.6)]",
          normalBg: "bg-slate-950 text-cyan-300 border border-cyan-500/40",
          itemBorder: "border-cyan-500/40 hover:border-cyan-300 animate-pulse",
          cardBorder: "border-violet-500/40 shadow-purple-500/20",
          connectorLine: "bg-violet-400",
          textActive: "text-cyan-300 text-shadow-[0_0_8px_rgba(34,211,238,0.4)]"
        };
    }
  };

  const t = getTimelineThemeColors(themeColor);

  return (
    <div
      className="w-full h-full flex flex-col items-center justify-center bg-transparent overflow-hidden relative"
      ref={containerRef}
      onClick={handleContainerClick}
    >
      <div className="relative w-full max-w-4xl h-[450px] flex items-center justify-center">
        <div
          className="absolute w-full h-full flex items-center justify-center"
          ref={orbitRef}
          style={{
            perspective: "1000px",
            transform: `translate(${centerOffset.x}px, ${centerOffset.y}px)`,
          }}
        >
          <div className={`absolute w-16 h-16 rounded-full bg-gradient-to-br ${t.centerGrad} animate-pulse flex items-center justify-center z-10 ${t.centerShadow} border border-white/20`}>
            <div className={`absolute w-20 h-20 rounded-full border ${t.pingBorder1} animate-ping opacity-70`}></div>
            <div
              className={`absolute w-24 h-24 rounded-full border ${t.pingBorder2} animate-ping opacity-60`}
              style={{ animationDelay: "0.5s" }}
            ></div>
            <div className={`w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-lg font-black ${t.textCenter} text-xs`}>M</div>
          </div>

          <div className={`absolute w-96 h-96 rounded-full border ${t.orbitBorder}`}></div>

          {timelineData.map((item, index) => {
            const position = calculateNodePosition(index, timelineData.length);
            const isExpanded = expandedItems[item.id];
            const isRelated = isRelatedToActive(item.id);
            const isPulsing = pulseEffect[item.id];
            const Icon = item.icon;

            const nodeStyle = {
              transform: `translate(${position.x}px, ${position.y}px)`,
              zIndex: isExpanded ? 200 : position.zIndex,
              opacity: isExpanded ? 1 : position.opacity,
            };

            return (
              <div
                key={item.id}
                ref={(el) => (nodeRefs.current[item.id] = el)}
                className="absolute transition-all duration-700 cursor-pointer flex flex-col items-center"
                style={nodeStyle}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleItem(item.id);
                }}
              >
                <div
                  className={`absolute rounded-full -inset-1 ${
                    isPulsing ? "animate-pulse duration-1000" : ""
                  }`}
                  style={{
                    background: `radial-gradient(circle, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0) 70%)`,
                    width: `${item.energy * 0.5 + 40}px`,
                    height: `${item.energy * 0.5 + 40}px`,
                    left: `-${(item.energy * 0.5 + 40 - 40) / 2}px`,
                    top: `-${(item.energy * 0.5 + 40 - 40) / 2}px`,
                  }}
                ></div>

                <div
                  className={`
                  w-10 h-10 rounded-full flex items-center justify-center
                  ${
                    isExpanded
                      ? t.activeBg
                      : isRelated
                      ? "bg-cyan-500 text-black font-extrabold"
                      : t.normalBg
                  }
                  border-2 
                  ${
                    isExpanded
                      ? t.activeBorder
                      : isRelated
                      ? "border-white animate-pulse"
                      : t.itemBorder
                  }
                  transition-all duration-300 transform
                  ${isExpanded ? "scale-125" : ""}
                `}
                >
                  <Icon size={16} />
                </div>

                <div
                  className={`
                  absolute top-12 whitespace-nowrap
                  text-xs font-bold tracking-wider
                  transition-all duration-300
                  ${isExpanded ? `${t.textActive} scale-125 font-black` : "text-white"}
                `}
                >
                  {item.title}
                </div>

                {isExpanded && (
                  <Card className={`absolute top-20 left-1/2 -translate-x-1/2 w-64 bg-slate-950/95 backdrop-blur-lg border text-white shadow-2xl overflow-visible z-[250] ${t.cardBorder}`}>
                    <div className={`absolute -top-3 left-1/2 -translate-x-1/2 w-px h-3 ${t.connectorLine}`}></div>
                    <CardHeader className="pb-2 p-4">
                      <div className="flex justify-between items-center">
                        <Badge
                          className={`px-2 py-0.5 text-[10px] font-bold border ${getStatusStyles(
                            item.status
                          )}`}
                        >
                          {item.status === "completed"
                            ? "COMPLETE"
                            : item.status === "in-progress"
                            ? "IN PROGRESS"
                            : "PENDING"}
                        </Badge>
                        <span className="text-[10px] font-mono text-white/50">
                          {item.date}
                        </span>
                      </div>
                      <CardTitle className="text-sm font-semibold text-slate-100 mt-2">
                        {item.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="text-xs text-slate-300 p-4 pt-0">
                      <p className="leading-normal">{item.content}</p>

                      {/* AI Projection Section */}
                      <div className="mt-3 p-2 rounded bg-cyan-950/20 border border-cyan-500/10 text-[11px]">
                        {projections[item.id] ? (
                          <div className="text-cyan-300 font-mono italic leading-normal">
                            <span className="text-amber-400 font-bold uppercase tracking-wider block text-[9px] mb-1">★ Live System Vision:</span>
                            {projections[item.id]}
                          </div>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleSynthesize(item.id, item.title);
                            }}
                            disabled={synthesizingId !== null}
                            className="w-full py-1 px-2 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5 font-bold text-[10px] cursor-pointer disabled:opacity-50"
                          >
                            {synthesizingId === item.id ? (
                              <>
                                <Loader2 size={10} className="animate-spin text-cyan-400" />
                                <span>ক্যালকুলেট হচ্ছে...</span>
                              </>
                            ) : (
                              <>
                                <Zap size={10} className="text-yellow-400 animate-pulse" />
                                <span>এআই ফিউচার প্রজেকশন রান করুন</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>

                      <div className="mt-4 pt-3 border-t border-white/10">
                        <div className="flex justify-between items-center text-xs mb-1">
                          <span className="flex items-center text-slate-400">
                            <Zap size={10} className="mr-1 text-yellow-400" />
                            Energy Level
                          </span>
                          <span className="font-mono text-slate-200">{item.energy}%</span>
                        </div>
                        <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
                            style={{ width: `${item.energy}%` }}
                          ></div>
                        </div>
                      </div>

                      {item.relatedIds.length > 0 && (
                        <div className="mt-4 pt-3 border-t border-white/10">
                          <div className="flex items-center mb-2">
                            <Link size={10} className="text-white/70 mr-1" />
                            <h4 className="text-[10px] uppercase tracking-wider font-semibold text-white/70">
                              Connected Nodes
                            </h4>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {item.relatedIds.map((relatedId) => {
                              const relatedItem = timelineData.find(
                                (i) => i.id === relatedId
                              );
                              return (
                                <Button
                                  key={relatedId}
                                  variant="outline"
                                  size="sm"
                                  className="flex items-center h-6 px-2 py-0 text-[10px] rounded-none border-white/10 bg-transparent hover:bg-white/10 text-white/80 hover:text-white transition-all cursor-pointer"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleItem(relatedId);
                                  }}
                                >
                                  {relatedItem?.title}
                                  <ArrowRight
                                    size={8}
                                    className="ml-1 text-white/60"
                                  />
                                </Button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
