import { Calendar, Code, FileText, User, Clock, Sparkles, RefreshCw } from "lucide-react";
import RadialOrbitalTimeline from "@/components/ui/radial-orbital-timeline";

export const timelineData = [
  {
    id: 1,
    title: "Core Activation",
    date: "Jan 2026",
    content: "Mimi AI Voice Assistant Core Initialized and active.",
    category: "Planning",
    icon: Calendar,
    relatedIds: [2],
    status: "completed" as const,
    energy: 100,
  },
  {
    id: 2,
    title: "Workspace Integration",
    date: "Feb 2026",
    content: "Connected Google Services including Gmail, Calendar, Drive, and Tasks.",
    category: "Design",
    icon: FileText,
    relatedIds: [1, 3],
    status: "completed" as const,
    energy: 90,
  },
  {
    id: 3,
    title: "Bengali Voice Synthesis",
    date: "Mar 2026",
    content: "Sassy, witty, and intelligent voice models configured.",
    category: "Development",
    icon: Code,
    relatedIds: [2, 4],
    status: "in-progress" as const,
    energy: 75,
  },
  {
    id: 4,
    title: "System Performance",
    date: "Apr 2026",
    content: "Low-latency diagnostic tracking and self-repairing cores.",
    category: "Testing",
    icon: User,
    relatedIds: [3, 5],
    status: "completed" as const,
    energy: 85,
  },
  {
    id: 5,
    title: "AI Studio Live Sync",
    date: "June 2026",
    content: "Live synchronization of models and dynamic path patching.",
    category: "Release",
    icon: RefreshCw,
    relatedIds: [4, 6],
    status: "completed" as const,
    energy: 95,
  },
  {
    id: 6,
    title: "Feature Synthesis",
    date: "Future Node",
    content: "Decentralized automated feature synthesis active with Gemini.",
    category: "Future",
    icon: Sparkles,
    relatedIds: [5],
    status: "in-progress" as const,
    energy: 60,
  },
];

export function RadialOrbitalTimelineDemo() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      <RadialOrbitalTimeline timelineData={timelineData} />
    </div>
  );
}

export default {
  RadialOrbitalTimelineDemo,
};
