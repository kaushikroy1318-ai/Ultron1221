import React, { useState } from "react";
import { getAccessToken, getServerUrl, saveServerConnection, testServerConnection } from "../lib/apiBase";

interface Props {
  onConnected: () => void;
}

/** First screen of the installed app: tell Mimi where its server is. */
export default function ServerSetupScreen({ onConnected }: Props) {
  const [url, setUrl] = useState(getServerUrl());
  const [token, setToken] = useState(getAccessToken());
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [failed, setFailed] = useState(false);

  const connect = async () => {
    if (!url.trim()) {
      setFailed(true);
      setMessage("Enter your server address first.");
      return;
    }
    setBusy(true);
    setFailed(false);
    setMessage("Checking the connection…");
    const result = await testServerConnection(url, token);
    setBusy(false);
    setMessage(result.message);
    setFailed(!result.ok);
    if (result.ok) {
      saveServerConnection(url, token);
      setTimeout(onConnected, 700);
    }
  };

  const field =
    "w-full rounded-2xl bg-white/5 border border-white/10 px-4 py-3.5 text-base text-white placeholder-white/30 outline-none focus:border-violet-400/60 focus:ring-2 focus:ring-violet-400/20";

  return (
    <div
      className="fixed inset-0 overflow-y-auto bg-[#020205] text-white"
      style={{ paddingTop: "env(safe-area-inset-top)", paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="mx-auto flex min-h-full max-w-md flex-col justify-center px-6 py-10">
        <div className="mb-8">
          <div className="mb-5 h-14 w-14 rounded-2xl bg-gradient-to-br from-violet-500 to-pink-500 shadow-[0_0_40px_rgba(139,92,246,0.45)]" />
          <h1 className="text-3xl font-bold tracking-tight">Connect Mimi to your server</h1>
          <p className="mt-3 text-[15px] leading-relaxed text-white/60">
            Mimi’s brain runs on your own server, so your AI keys stay off the phone. Enter its address and the access token you set there.
          </p>
        </div>

        <label className="mb-1.5 text-sm font-semibold text-white/80" htmlFor="srv">
          Server address
        </label>
        <input
          id="srv"
          className={field}
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://your-mimi-server.onrender.com"
          inputMode="url"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
        />

        <label className="mb-1.5 mt-5 text-sm font-semibold text-white/80" htmlFor="tok">
          Access token
        </label>
        <input
          id="tok"
          className={field}
          type="password"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="The MIMI_ACCESS_TOKEN from your server"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
        />

        <button
          onClick={connect}
          disabled={busy}
          className="mt-7 w-full rounded-2xl bg-gradient-to-r from-violet-500 to-pink-500 py-4 text-base font-bold shadow-lg shadow-violet-500/20 active:scale-[0.99] disabled:opacity-60"
        >
          {busy ? "Connecting…" : "Connect"}
        </button>

        {message && (
          <p role="status" className={`mt-4 text-sm leading-relaxed ${failed ? "text-red-300" : "text-emerald-300"}`}>
            {message}
          </p>
        )}
      </div>
    </div>
  );
}
