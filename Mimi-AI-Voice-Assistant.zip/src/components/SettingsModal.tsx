import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  X,
  Sliders,
  SlidersHorizontal,
  Sparkles,
  Zap,
  Heart,
  User,
  Trash2,
  Volume2,
  VolumeX,
  HeartHandshake,
  Gamepad2,
  Code2,
  Satellite,
  MousePointer2,
  Activity,
  Image as ImageIcon,
  Mail,
  HardDrive,
  MessageSquare,
  CheckSquare,
  Users,
  CheckCircle2,
  Globe,
  Mic,
  Link as LinkIcon,
  Link2,
  Plus,
  RefreshCw,
  Settings,
  Server,
  Brain,
  Search,
  Terminal,
  Shield,
  Bell,
  Cpu,
  Lock,
  History,
  Layers,
  Database,
  Info,
  Radio,
  UserCheck,
  Check,
  AlertCircle,
  Send,
  Monitor,
  Palette,
  Feather,
  Orbit,
  LayoutGrid,
  Key
} from "lucide-react";
import { aiStudioSyncService, AIPlatformState, SyncConfig } from "../services/aiStudioSyncService";
import NeuralDashboard from "./NeuralDashboard";
import ApiKeysPanel from "./ApiKeysPanel";

interface SettingsModalProps {
  onClose: () => void;
  preferences: {
    name?: string;
    relationshipType?: string;
    traits: {
      sassiness: number;
      wit: number;
      emotionality: number;
    };
    neuralCore?: string;
    voiceId?: string;
    isMuted?: boolean;
    autoGameMode?: boolean;
    autoCodeMode?: boolean;
    autoRecordingMode?: boolean;
    satelliteMode?: boolean;
    remoteControlMode?: boolean;
    showSystemMonitor?: boolean;
    displaySkin?: string;
    homeLayoutMode?: "classic" | "3d" | "claude";
    claudeDarkMode?: boolean;
    showMiniComments?: boolean;
    miniCommentTheme?: string;
    miniCommentAutoReply?: boolean;
    customSearchSites?: { id: string; name: string; url: string }[];
    serverLinks?: {
      id: string;
      name: string;
      url: string;
      type: string;
      autoReconnect?: boolean;
      autoUpdate?: boolean;
      enabled: boolean;
      version?: string;
      uptime?: string;
    }[];
    workspace?: {
      photoCategory?: string;
      photoAutoMatch?: boolean;
      gmailLimit?: number;
      gmailAutoRead?: boolean;
      driveSafetyLimit?: number;
      driveListFilter?: string;
      chatAutoResponse?: boolean;
      tasksSortStyle?: string;
      contactsSortStyle?: string;
    };
  };
  user?: any;
  accessToken?: string | null;
  onLogin?: () => Promise<void>;
  onLogout?: () => Promise<void>;
  onSave: (prefs: any) => void;
  onClearHistory: () => void;
  memories?: any[];
  searchHistory?: any[];
  conversations?: any[];
  currentConversationId?: string | null;
  onSelectConversation?: (id: string) => void;
  onStartNewConversation?: () => void;
  onDeleteConversation?: (id: string) => void;
  onAddMemory?: (fact: string) => void;
  onDeleteMemory?: (id: string) => void;
  onClearSearches?: () => void;
  voiceLogs?: any[];
  commandLogs?: any[];
  onClearVoiceLogs?: () => void;
  onClearCommandLogs?: () => void;
  onUpgradeSystem?: () => void;
  messages?: any[];
  onSendChatMessage?: (text: string) => Promise<void>;
  appState?: string;
}

const AVAILABLE_VOICES = [
  { id: "Kore", name: "Kore (Cheerful & Fast)" },
  { id: "Zephyr", name: "Zephyr (Bright & Natural)" },
  { id: "Puck", name: "Puck (Playful & Sassy)" },
  { id: "Charon", name: "Charon (Deep & Calm)" },
  { id: "Fenrir", name: "Fenrir (Strong & Authority)" },
];

export default function SettingsModal({
  onClose,
  preferences,
  user,
  accessToken,
  onLogin,
  onLogout,
  onSave,
  onClearHistory,
  memories = [],
  searchHistory = [],
  conversations = [],
  currentConversationId = null,
  onSelectConversation,
  onStartNewConversation,
  onDeleteConversation,
  onAddMemory,
  onDeleteMemory,
  onClearSearches,
  voiceLogs = [],
  commandLogs = [],
  onClearVoiceLogs,
  onClearCommandLogs,
  onUpgradeSystem,
  messages = [],
  onSendChatMessage,
  appState,
}: SettingsModalProps) {
  // Navigation active tab inside settings panel
  const [activeTab, setActiveTab] = useState<"dashboard" | "personality" | "workspace" | "smart_server" | "memory" | "security" | "neural" | "api_keys">("neural");
  const [isCompactChat, setIsCompactChat] = useState<boolean>(true);
  const [inputText, setInputText] = useState<string>("");
  const compactChatEndRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isCompactChat) {
      setTimeout(() => {
        compactChatEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
  }, [messages, isCompactChat]);

  const getQuickReplies = (): string[] => {
    if (!messages || messages.length === 0) {
      return ["Tell me more about yourself", "What can you do?", "Run system check"];
    }
    // Find the last message in the array from the assistant
    const assistantMessages = messages.filter(m => m.sender === "mimi");
    if (assistantMessages.length === 0) {
      return ["Explain capabilities", "Show Gmail integration", "System diagnostic"];
    }
    const lastMsg = assistantMessages[assistantMessages.length - 1];
    const text = lastMsg.text.toLowerCase();

    if (text.includes("gmail") || text.includes("email") || text.includes("inbox") || text.includes("mail")) {
      return ["Check my latest emails", "Summarize my unread emails", "Draft a quick email reply"];
    }
    if (text.includes("calendar") || text.includes("meeting") || text.includes("schedule") || text.includes("event") || text.includes("agenda")) {
      return ["What is my next meeting?", "Show my agenda for today", "Schedule a quick event"];
    }
    if (text.includes("sheet") || text.includes("spreadsheet") || text.includes("data") || text.includes("rows")) {
      return ["Read active spreadsheet", "Add row to my sheet", "Summarize sheet data"];
    }
    if (text.includes("drive") || text.includes("file") || text.includes("document") || text.includes("folder") || text.includes("upload")) {
      return ["List files in Google Drive", "Search my Drive docs", "Show recent Drive files"];
    }
    if (text.includes("task") || text.includes("todo") || text.includes("list") || text.includes("remind")) {
      return ["Show current task list", "Create high-priority task", "Mark first task complete"];
    }
    if (text.includes("voice") || text.includes("speaking") || text.includes("audio") || text.includes("mic") || text.includes("hear") || text.includes("vocal")) {
      return ["Let's try a voice command", "Change emotional voice profile", "Adjust vocal frequency"];
    }
    if (text.includes("personality") || text.includes("neural") || text.includes("trait") || text.includes("mimi") || text.includes("persona")) {
      return ["Enable formal manager persona", "Increase emotional intensity", "How do personality nodes work?"];
    }
    if (text.includes("error") || text.includes("fail") || text.includes("issue") || text.includes("fix") || text.includes("diagnostic")) {
      return ["Run diagnostic system check", "Show last system error logs", "Analyze network latencies"];
    }

    return ["Tell me more about this", "How can I configure this?", "Great, what's next?"];
  };

  // Local state for comments and answers
  const [comments, setComments] = useState<Record<string, { comment: string; answer: string; timestamp: string }[]>>(() => {
    const saved = localStorage.getItem("mimi_comments");
    return saved ? JSON.parse(saved) : {};
  });

  const handleAddComment = (id: string, text: string) => {
    if (!text.trim()) return;
    const isAutoReply = preferences.miniCommentAutoReply !== false;
    
    let mimiAnswer = "I've cataloged your feedback on this!";
    if (isAutoReply) {
      const answers = [
        "Noted! Mimi has archived this insight into our primary neural core.",
        "Excellent point, bondhu! I will recalibrate my response algorithm for this.",
        "Ah, I see! Your feedback helps optimize our neural pathways.",
        "That's exceptionally witty. I'm adding that directly to my memory bank!",
        "Understood. Mimi's cognitive node has successfully mapped your comment.",
        "Fascinating. I will run a parallel thread on this during my next update cycle."
      ];
      mimiAnswer = answers[Math.floor(Math.random() * answers.length)];
    }

    const newComments = {
      ...comments,
      [id]: [
        ...(comments[id] || []),
        {
          comment: text,
          answer: mimiAnswer,
          timestamp: new Date().toLocaleTimeString("en-IN", { hour: "numeric", minute: "numeric" })
        }
      ]
    };
    setComments(newComments);
    localStorage.setItem("mimi_comments", JSON.stringify(newComments));
  };

  // 3D Spatial interactive coordinate tracking states
  const [tilt3D, setTilt3D] = useState({ x: 0, y: 0 });

  const handleMouseMove3D = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const box = card.getBoundingClientRect();
    // Get mouse offset relative to center of the card
    const x = e.clientX - box.left - box.width / 2;
    const y = e.clientY - box.top - box.height / 2;
    // Cap rotation at a highly elegant 3.5 degrees to avoid motion sickness
    const rotateX = -(y / (box.height / 2)) * 3.5;
    const rotateY = (x / (box.width / 2)) * 3.5;
    setTilt3D({ x: rotateX, y: rotateY });
  };

  const handleMouseLeave3D = () => {
    setTilt3D({ x: 0, y: 0 });
  };

  const [localPrefs, setLocalPrefs] = useState(() => {
    const p = (preferences || {}) as any;
    const defaultWorkspace = {
      photoCategory: "all",
      photoAutoMatch: true,
      gmailLimit: 15,
      gmailAutoRead: true,
      driveSafetyLimit: 10,
      driveListFilter: "all",
      chatAutoResponse: false,
      tasksSortStyle: "dateCreated",
      contactsSortStyle: "first",
    };
    
    // Auto-migrate customSearchSites to serverLinks under type 'search'
    let migratedLinks = [...(p.serverLinks || [])];
    const existingUrls = new Set(migratedLinks.map((l: any) => l.url.toLowerCase().trim()));
    
    if (p.customSearchSites && p.customSearchSites.length > 0) {
      p.customSearchSites.forEach((site: any) => {
        const cleanUrl = site.url.toLowerCase().trim();
        if (!existingUrls.has(cleanUrl)) {
          migratedLinks.push({
            id: site.id || Date.now().toString() + Math.random().toString(),
            name: site.name,
            url: site.url,
            type: "search",
            autoReconnect: true,
            autoUpdate: true,
            enabled: true,
            version: "v1.0.0 (Indexed)",
            uptime: "99.9%"
          });
          existingUrls.add(cleanUrl);
        }
      });
    }

    return {
      ...p,
      workspace: { ...defaultWorkspace, ...(p.workspace || {}) },
      serverLinks: migratedLinks
    };
  });

  // State variables for Smart Server & Search Hub Form
  const [newHubName, setNewHubName] = useState("");
  const [historySubTab, setHistorySubTab] = useState<"conversations" | "memories" | "searches" | "commands" | "voice">("conversations");
  const [newMemoryText, setNewMemoryText] = useState("");
  const [newHubUrl, setNewHubUrl] = useState("");
  const [newHubType, setNewHubType] = useState<"api" | "mcp" | "websocket" | "custom" | "search" | "website">("api");
  const [newHubAutoReconnect, setNewHubAutoReconnect] = useState(true);
  const [newHubAutoUpdate, setNewHubAutoUpdate] = useState(true);
  const [editingHubId, setEditingHubId] = useState<string | null>(null);
  const [hubFormError, setHubFormError] = useState<string | null>(null);

  const [verifyingServer, setVerifyingServer] = useState(false);
  const [testingServerId, setTestingServerId] = useState<string | null>(null);

  // AI Twin / Studio Sync States
  const [syncConfig, setSyncConfig] = useState(() => aiStudioSyncService.getConfig());
  const [syncPlatforms, setSyncPlatforms] = useState(() => aiStudioSyncService.getPlatforms());
  const [syncAutoCorrectionCount, setSyncAutoCorrectionCount] = useState(() => aiStudioSyncService.getAutoCorrectionCount());
  const [syncLogs, setSyncLogs] = useState(() => aiStudioSyncService.getLogs());
  const [upgradingPlatformId, setUpgradingPlatformId] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = aiStudioSyncService.registerListener(() => {
      setSyncConfig(aiStudioSyncService.getConfig());
      setSyncPlatforms([...aiStudioSyncService.getPlatforms()]);
      setSyncAutoCorrectionCount(aiStudioSyncService.getAutoCorrectionCount());
      setSyncLogs([...aiStudioSyncService.getLogs()]);
    });
    return () => unsubscribe();
  }, []);

  const handleToggleSyncConfig = (key: keyof SyncConfig) => {
    const current = syncConfig[key];
    aiStudioSyncService.updateConfig({ [key]: !current });
  };

  const handleUpgradePlatform = async (platformId: string) => {
    setUpgradingPlatformId(platformId);
    await aiStudioSyncService.upgradePlatform(platformId);
    setUpgradingPlatformId(null);
  };
  
  // Real-time server/link statuses
  const [serverStatuses, setServerStatuses] = useState<Record<string, { 
    status: "connected" | "disconnected" | "connecting" | "failed"; 
    latency?: string; 
    error?: string;
    version?: string;
    uptime?: string;
    lastChecked?: string;
  }>>({});

  // Unified Verify & Connect function
  const handleTestConnection = async (link: any) => {
    setTestingServerId(link.id);
    setServerStatuses(prev => ({
      ...prev,
      [link.id]: { 
        ...prev[link.id],
        status: "connecting",
        lastChecked: new Date().toLocaleTimeString()
      }
    }));

    try {
      const response = await fetch("/api/server-link/ping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: link.url, type: link.type })
      });

      const latencyMs = Math.round(5 + Math.random() * 35) + "ms";

      if (response.ok) {
        const data = await response.json();
        if (data.status === "connected") {
          let simulatedVersion = link.version || "v2.4.9 (Stable)";
          if (link.type === "mcp") simulatedVersion = "v1.1.2 (Latest)";
          else if (link.type === "websocket") simulatedVersion = "v3.0.5 (Stable)";
          else if (link.type === "search" || link.type === "website") simulatedVersion = "v1.0.0 (Indexed)";

          setServerStatuses(prev => ({
            ...prev,
            [link.id]: { 
              status: "connected", 
              latency: data.latency || latencyMs,
              version: simulatedVersion,
              uptime: link.uptime || "99.98%",
              lastChecked: new Date().toLocaleTimeString(),
              error: undefined
            }
          }));
        } else {
          setServerStatuses(prev => ({
            ...prev,
            [link.id]: { 
              status: "failed", 
              error: data.error || "Failed to reach host",
              version: link.version || "Unknown",
              uptime: link.uptime || "0%",
              lastChecked: new Date().toLocaleTimeString()
            }
          }));
        }
      } else {
        setServerStatuses(prev => ({
          ...prev,
          [link.id]: { 
            status: "failed", 
            error: "HTTP " + response.status,
            version: link.version || "Unknown",
            uptime: link.uptime || "0%",
            lastChecked: new Date().toLocaleTimeString()
          }
        }));
      }
    } catch (e: any) {
      setServerStatuses(prev => ({
        ...prev,
        [link.id]: { 
          status: "failed", 
          error: e.message || "Network Timeout",
          version: link.version || "Unknown",
          uptime: link.uptime || "0%",
          lastChecked: new Date().toLocaleTimeString()
        }
      }));
    } finally {
      setTestingServerId(null);
    }
  };

  // Run System-Wide Health Verification checks on mount & startup
  useEffect(() => {
    const activeAutoLinks = (localPrefs.serverLinks || []).filter((l: any) => l.enabled && l.autoReconnect !== false);
    activeAutoLinks.forEach((link: any) => {
      handleTestConnection(link);
    });

    const updateInterval = setInterval(() => {
      const linksToPoll = (localPrefs.serverLinks || []).filter((l: any) => l.enabled && l.autoUpdate !== false);
      linksToPoll.forEach((link: any) => {
        handleTestConnection(link);
      });
    }, 45000);

    return () => clearInterval(updateInterval);
  }, []);

  const handleSystemWideUpdateCheck = async () => {
    const links = localPrefs.serverLinks || [];
    if (links.length === 0) return;
    for (const link of links) {
      if (link.enabled) {
        await handleTestConnection(link);
      }
    }
  };

  const handleSaveHubService = async () => {
    if (!newHubName.trim() || !newHubUrl.trim()) return;

    setVerifyingServer(true);
    setHubFormError(null);
    const tempId = editingHubId || Date.now().toString();

    let defaultVersion = "v1.0.0 (Latest)";
    if (newHubType === "mcp") defaultVersion = "v1.1.2 (Active)";
    else if (newHubType === "websocket") defaultVersion = "v3.0.5 (Stable)";
    else if (newHubType === "api" || newHubType === "custom") defaultVersion = "v2.4.9 (Stable)";

    const existingLink = (localPrefs.serverLinks || []).find((l: any) => l.id === tempId);
    const addedTime = existingLink?.addedTime || new Date().toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true
    });

    const newLink = {
      id: tempId,
      name: newHubName.trim(),
      url: newHubUrl.trim(),
      type: newHubType,
      autoReconnect: newHubAutoReconnect,
      autoUpdate: newHubAutoUpdate,
      enabled: true,
      version: defaultVersion,
      uptime: "99.9%",
      addedTime: addedTime
    };

    let connectionLatency = "15ms";
    let isConnected: "connected" | "failed" = "connected";
    let pingError: string | undefined = undefined;

    try {
      const response = await fetch("/api/server-link/ping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: newHubUrl.trim(), type: newHubType })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.status === "connected") {
          connectionLatency = data.latency || "18ms";
          isConnected = "connected";
        } else {
          isConnected = "failed";
          pingError = data.error || "Host Unreachable";
        }
      } else {
        isConnected = "failed";
        pingError = "HTTP " + response.status;
      }
    } catch (e: any) {
      isConnected = "failed";
      pingError = e.message || "Network timeout check";
    }

    setServerStatuses(prev => ({
      ...prev,
      [tempId]: {
        status: isConnected,
        latency: connectionLatency,
        version: defaultVersion,
        uptime: isConnected === "connected" ? "99.9%" : "0%",
        lastChecked: new Date().toLocaleTimeString(),
        error: pingError
      }
    }));

    if (isConnected === "failed") {
      setHubFormError(`Ping failed for "${newHubName.trim()}": ${pingError || "Host Unreachable"}.`);
    }

    let updatedLinks = [];
    if (editingHubId) {
      updatedLinks = (localPrefs.serverLinks || []).map((link: any) => 
        link.id === editingHubId ? newLink : link
      );
    } else {
      updatedLinks = [...(localPrefs.serverLinks || []), newLink];
    }

    const updated = {
      ...localPrefs,
      serverLinks: updatedLinks,
    };

    setLocalPrefs(updated);
    if (onSave) {
      onSave(updated);
    }

    setNewHubName("");
    setNewHubUrl("");
    setNewHubType("api");
    setNewHubAutoReconnect(true);
    setNewHubAutoUpdate(true);
    setEditingHubId(null);
    setVerifyingServer(false);
  };

  const handleEditHubService = (link: any) => {
    setNewHubName(link.name);
    setNewHubUrl(link.url);
    setNewHubType(link.type || "api");
    setNewHubAutoReconnect(link.autoReconnect !== false);
    setNewHubAutoUpdate(link.autoUpdate !== false);
    setEditingHubId(link.id);
    setHubFormError(null);
  };

  const handleDeleteHubService = (id: string) => {
    const updatedLinks = (localPrefs.serverLinks || []).filter((link: any) => link.id !== id);
    const updated = {
      ...localPrefs,
      serverLinks: updatedLinks,
    };
    setLocalPrefs(updated);
    if (onSave) {
      onSave(updated);
    }
  };

  const handleToggleHubEnabled = (link: any) => {
    const updatedLinks = (localPrefs.serverLinks || []).map((l: any) => 
      l.id === link.id ? { ...l, enabled: !l.enabled } : l
    );
    const updated = {
      ...localPrefs,
      serverLinks: updatedLinks,
    };
    setLocalPrefs(updated);
    if (onSave) {
      onSave(updated);
    }
  };

  const handleTraitChange = (key: string, value: number) => {
    setLocalPrefs((prev: any) => ({
      ...prev,
      traits: { ...prev.traits, [key]: value },
    }));
  };

  const handleGeneralChange = (key: string, value: any) => {
    setLocalPrefs((prev: any) => ({ ...prev, [key]: value }));
  };

  const handleWorkspaceChange = (key: string, value: any) => {
    setLocalPrefs((prev: any) => ({
      ...prev,
      workspace: { ...(prev.workspace || {}), [key]: value },
    }));
  };

  // Custom Inline Premium Toggle Switch component (3D Tactile Design)
  const PremiumToggle = ({ enabled, onClick, colorTheme = "cyan" }: { enabled: boolean; onClick: () => void; colorTheme?: string }) => {
    const isRedTheme = colorTheme === "red" || colorTheme === "rose";
    const isOrangeTheme = colorTheme === "orange" || colorTheme === "amber" || colorTheme === "yellow";
    const isGreenTheme = colorTheme === "green" || colorTheme === "emerald" || colorTheme === "teal";
    const isPurpleTheme = colorTheme === "purple" || colorTheme === "violet" || colorTheme === "fuchsia";
    
    // Choose active glow and track color based on the selected theme
    const activeBgClass = isRedTheme ? "bg-rose-500 shadow-[inset_0_2px_6px_rgba(0,0,0,0.9),_0_0_12px_rgba(244,63,94,0.6)] border-rose-400/20" 
                        : isOrangeTheme ? "bg-amber-500 shadow-[inset_0_2px_6px_rgba(0,0,0,0.9),_0_0_12px_rgba(245,158,11,0.6)] border-amber-400/20"
                        : isGreenTheme ? "bg-emerald-500 shadow-[inset_0_2px_6px_rgba(0,0,0,0.9),_0_0_12px_rgba(16,185,129,0.6)] border-emerald-400/20"
                        : isPurpleTheme ? "bg-violet-500 shadow-[inset_0_2px_6px_rgba(0,0,0,0.9),_0_0_12px_rgba(139,92,246,0.6)] border-violet-400/20"
                        : "bg-cyan-500 shadow-[inset_0_2px_6px_rgba(0,0,0,0.9),_0_0_12px_rgba(34,211,238,0.6)] border-cyan-400/20";
    
    const ledGlowClass = isRedTheme ? "bg-rose-400 shadow-[0_0_8px_rgba(244,63,94,0.9),0_0_3px_rgba(244,63,94,0.9)]" 
                       : isOrangeTheme ? "bg-amber-400 shadow-[0_0_8px_rgba(245,158,11,0.9),0_0_3px_rgba(245,158,11,0.9)]"
                       : isGreenTheme ? "bg-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.9),0_0_3px_rgba(16,185,129,0.9)]"
                       : isPurpleTheme ? "bg-violet-400 shadow-[0_0_8px_rgba(139,92,246,0.9),0_0_3px_rgba(139,92,246,0.9)]"
                       : "bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.9),0_0_3px_rgba(34,211,238,0.9)]";

    return (
      <button
        onClick={onClick}
        type="button"
        className={`relative w-12 h-6 rounded-full p-[2px] select-none cursor-pointer transition-all duration-300 outline-none flex items-center ${
          enabled 
            ? activeBgClass 
            : "bg-[#08080c] shadow-[inset_0_2px_6px_rgba(0,0,0,0.95)] border border-white/[0.03]"
        }`}
        style={{ perspective: "500px" }}
      >
        {/* 3D Tactile Sliding Handle */}
        <div
          className={`absolute top-0.5 bottom-0.5 w-5 rounded-full transition-all duration-300 ease-out flex items-center justify-center ${
            enabled 
              ? "left-[25px] bg-gradient-to-b from-neutral-50 via-neutral-200 to-neutral-400 shadow-[0_3px_6px_rgba(0,0,0,0.7),_inset_0_1px_1.5px_rgba(255,255,255,0.9)]" 
              : "left-[3px] bg-gradient-to-b from-neutral-700 via-neutral-800 to-neutral-900 shadow-[0_2px_4px_rgba(0,0,0,0.8),_inset_0_1px_1px_rgba(255,255,255,0.1)] border border-neutral-600/20"
          }`}
        >
          {/* Ridge-grip lines inside toggle button handle for tactile grip aesthetic */}
          <div className="flex gap-px">
            <span className={`w-[1px] h-2.5 rounded-full ${enabled ? "bg-neutral-300" : "bg-neutral-600"}`} />
            <span className={`w-[1px] h-2.5 rounded-full ${enabled ? "bg-neutral-300" : "bg-neutral-600"}`} />
          </div>
        </div>

        {/* Micro-LED glowing indication light */}
        <div 
          className={`absolute top-1/2 -translate-y-1/2 w-1 h-1 rounded-full text-[0px] transition-all duration-300 ${
            enabled ? `${ledGlowClass} left-2` : "bg-red-900/50 shadow-[0_0_1px_rgba(239,68,68,0.2)] left-8"
          }`}
        />
      </button>
    );
  };

  if (isCompactChat) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md"
        style={{ perspective: "1500px" }}
      >
        <motion.div
          initial={{ scale: 0.95, y: 15 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 15 }}
          className="w-full max-w-md h-[620px] bg-[#030306]/95 border border-cyan-500/40 rounded-[2rem] overflow-hidden shadow-[0_15px_60px_rgba(6,182,212,0.15)] flex flex-col backdrop-blur-2xl transition-all duration-300 ease-out"
          style={{
            transformStyle: "preserve-3d",
            transform: `rotateX(${tilt3D.x}deg) rotateY(${tilt3D.y}deg) translateZ(10px)`,
          }}
          onMouseMove={handleMouseMove3D}
          onMouseLeave={handleMouseLeave3D}
        >
          {/* COMPACT CHAT BOT CONTROLLER VIEW */}
          <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#030306]">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-white/5 bg-black/40 shrink-0">
              <div className="flex items-center gap-2.5">
                <Cpu className="text-pink-400 animate-pulse" size={16} />
                <div>
                  <h2 className="text-xs font-black tracking-tight text-white gap-1 flex items-center">
                    Mimi Companion Bot
                  </h2>
                  <p className="text-[8px] uppercase tracking-widest text-pink-400 font-mono font-bold">
                    NEURAL CONVERSATION ACTIVE
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Switch to Advanced settings button */}
                <button
                  onClick={() => setIsCompactChat(false)}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 text-cyan-300 rounded-xl text-[9px] uppercase font-bold transition-all cursor-pointer"
                  title="Open Advanced Settings"
                >
                  <Settings size={11} />
                  <span>Advanced</span>
                </button>

                <button
                  onClick={onClose}
                  className="p-1.5 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
                  title="Close Dialog"
                >
                  <X size={15} />
                </button>
              </div>
            </div>

            {/* Session Switcher Bar */}
            <div className="px-4 py-2 border-b border-white/[0.03] bg-[#07070d]/60 flex items-center justify-between gap-3 text-xs shrink-0">
              <div className="flex items-center gap-1.5 min-w-0 flex-1">
                <span className="text-[8.5px] font-mono text-white/30 uppercase font-bold shrink-0">Session:</span>
                <select
                  value={currentConversationId || ""}
                  onChange={(e) => onSelectConversation?.(e.target.value)}
                  className="bg-neutral-900/60 border border-white/5 rounded-lg px-2 py-1 text-[10px] font-bold text-cyan-300 outline-none cursor-pointer min-w-0 max-w-[160px] truncate"
                >
                  {conversations.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.lastMessage ? (c.lastMessage.substring(0, 24) + "...") : "Dialog Session"}
                    </option>
                  ))}
                </select>
              </div>
              {onStartNewConversation && (
                <button
                  onClick={onStartNewConversation}
                  className="px-2.5 py-1 bg-violet-600/20 hover:bg-violet-600/30 border border-violet-500/25 text-violet-300 rounded-lg text-[9px] uppercase font-mono font-bold transition-all cursor-pointer shrink-0"
                >
                  + New
                </button>
              )}
            </div>

            {/* Chat Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5 custom-scrollbar bg-black/20 flex flex-col">
              {messages.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-xs text-white/35 space-y-2 my-auto">
                  <Brain size={28} className="text-pink-500/70 animate-bounce" />
                  <p className="font-bold text-white/70">Mimi Neural Core Ready</p>
                  <p className="text-[10px] max-w-[200px]">Send a message below to start your conversation with Mimi!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((msg, index) => {
                    const isUser = msg.sender === "user";
                    const msgId = msg.id || `compact-msg-${index}`;
                    const msgComments = comments[msgId] || [];

                    return (
                      <div key={msgId} className={`flex flex-col space-y-1 ${isUser ? "items-end" : "items-start"}`}>
                        <div className="flex items-center gap-1.5 text-[8px] font-mono text-white/30 px-1">
                          {isUser ? (
                            <>
                              <span>You</span>
                              <User size={8} className="text-violet-400" />
                            </>
                          ) : (
                            <>
                              <Cpu size={8} className="text-pink-400 animate-pulse" />
                              <span className="text-pink-400">Mimi</span>
                            </>
                          )}
                        </div>

                        <div className={`p-3 rounded-2xl max-w-[85%] text-xs shadow-md leading-relaxed ${
                          isUser 
                            ? "bg-gradient-to-br from-violet-950/95 to-indigo-950/95 border border-violet-500/30 text-violet-100 shadow-[0_4px_12px_rgba(139,92,246,0.12)] rounded-tr-none" 
                            : "bg-gradient-to-br from-fuchsia-950/95 to-pink-950/95 border border-pink-500/30 text-pink-100 shadow-[0_4px_12px_rgba(236,72,153,0.12)] rounded-tl-none"
                        }`}>
                          <p className="whitespace-pre-wrap selection:bg-pink-500/30">{msg.text}</p>
                        </div>

                        {/* Mini Comments and Replies block */}
                        <div className="w-[85%] mt-1">
                          <div className="bg-[#050508]/60 border border-white/[0.03] p-2 rounded-xl space-y-1.5">
                            {msgComments.length > 0 && (
                              <div className="space-y-1.5 max-h-[80px] overflow-y-auto custom-scrollbar pr-0.5">
                                {msgComments.map((com, cIdx) => (
                                  <div key={cIdx} className="text-[9px] border-l border-white/10 pl-1.5 py-0.5 space-y-0.5">
                                    <p className="text-white/80 font-medium">📝 {com.comment}</p>
                                    <p className="text-pink-400/90 italic font-mono font-bold leading-tight">🤖 {com.answer}</p>
                                  </div>
                                ))}
                              </div>
                            )}
                            {/* Comment Entry Input */}
                            <div className="flex gap-1 pt-1 border-t border-white/[0.02]">
                              <input
                                type="text"
                                placeholder="Add custom comment..."
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    const val = e.currentTarget.value;
                                    if (val.trim()) {
                                      handleAddComment(msgId, val);
                                      e.currentTarget.value = "";
                                    }
                                  }
                                }}
                                className="flex-1 bg-black/50 border border-white/5 rounded-lg px-2 py-1 text-[9px] font-medium text-white placeholder-white/20 outline-none"
                              />
                              <button
                                onClick={(e) => {
                                  const input = e.currentTarget.previousElementSibling as HTMLInputElement;
                                  if (input.value.trim()) {
                                    handleAddComment(msgId, input.value);
                                    input.value = "";
                                  }
                                }}
                                className="px-2 py-1 bg-white/5 hover:bg-cyan-500/20 text-white/50 hover:text-cyan-300 rounded-lg text-[9px] font-mono transition-all cursor-pointer"
                              >
                                REPLY
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Typing indicator */}
              {(appState === "processing" || appState === "speaking") && (
                <div className="flex flex-col items-start space-y-1 mt-2 animate-pulse shrink-0">
                  <div className="flex items-center gap-1.5 text-[8px] font-mono text-pink-400 px-1">
                    <Cpu size={8} className="animate-spin" />
                    <span>Mimi is thinking...</span>
                  </div>
                  <div className="p-3 bg-pink-500/10 border border-pink-500/20 text-pink-300 rounded-2xl rounded-tl-none flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}

              <div ref={compactChatEndRef} />
            </div>

            {/* Suggestions Quick Reply Bar */}
            {appState !== "processing" && appState !== "speaking" && (
              <div className="px-4 py-2 bg-[#05050a]/90 border-t border-white/[0.03] flex flex-wrap gap-1.5 items-center justify-start shrink-0">
                <span className="text-[8px] font-mono text-pink-400 uppercase font-bold tracking-wider mr-1 shrink-0">Suggestions:</span>
                {getQuickReplies().map((reply, rIdx) => (
                  <button
                    key={rIdx}
                    type="button"
                    onClick={async () => {
                      if (onSendChatMessage) {
                        await onSendChatMessage(reply);
                      }
                    }}
                    className="px-2.5 py-1 bg-[#0d0d18] hover:bg-pink-500/10 border border-pink-500/20 hover:border-pink-500/45 text-neutral-300 hover:text-white rounded-xl text-[9px] font-medium transition-all duration-200 active:scale-95 cursor-pointer flex items-center gap-1 shadow-sm hover:shadow-[0_0_8px_rgba(236,72,153,0.12)]"
                  >
                    <span>💬</span>
                    <span>{reply}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Input Bar */}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!inputText.trim() || !onSendChatMessage) return;
                const txt = inputText;
                setInputText("");
                await onSendChatMessage(txt);
              }}
              className="p-3 bg-black/60 border-t border-white/5 flex gap-2 shrink-0 items-center"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                disabled={appState === "processing"}
                placeholder="Type a message to Mimi..."
                className="flex-1 bg-neutral-900 border border-white/10 rounded-xl px-3 py-2 text-xs font-medium text-white placeholder-white/30 outline-none focus:border-cyan-500/50 transition-all"
              />
              <button
                type="submit"
                disabled={!inputText.trim() || appState === "processing"}
                className="p-2.5 bg-gradient-to-br from-cyan-500 to-indigo-500 text-white rounded-xl transition-all cursor-pointer disabled:opacity-30 flex items-center justify-center shrink-0 shadow-md shadow-cyan-500/10 hover:opacity-90 active:scale-95"
              >
                <Send size={12} />
              </button>
            </form>
          </div>
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md"
      style={{ perspective: "1500px" }}
    >
      <motion.div
        initial={{ scale: 0.95, y: 15 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95, y: 15 }}
        className={`w-full bg-[#030306]/95 border rounded-[2rem] md:rounded-[2.5rem] overflow-hidden shadow-[0_20px_100px_rgba(0,0,0,0.9),_0_0_40px_rgba(6,182,212,0.05)] flex flex-col backdrop-blur-2xl transition-all duration-300 ease-out ${
          isCompactChat 
            ? "max-w-md h-[620px] border-cyan-500/40 shadow-[0_15px_60px_rgba(6,182,212,0.15)]" 
            : "max-w-5xl h-[90vh] md:h-[82vh] md:flex-row border-cyan-500/20"
        }`}
        style={{
          transformStyle: "preserve-3d",
          transform: `rotateX(${tilt3D.x}deg) rotateY(${tilt3D.y}deg) translateZ(10px)`,
        }}
        onMouseMove={handleMouseMove3D}
        onMouseLeave={handleMouseLeave3D}
      >
        {/* LEFT PANEL: Glassmorphism Sidebar */}
        {!isCompactChat && (
          <div className="w-full md:w-80 bg-zinc-950/40 p-6 flex flex-col justify-between border-b md:border-b-0 md:border-r border-white/5 shrink-0">
            <div className="space-y-6">
              {/* Header / Brand identity */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                    <Cpu size={16} className="animate-pulse" />
                  </div>
                  <div>
                    <h2 className="text-sm font-black tracking-tight text-white gap-1 flex items-center">
                      Mimi OS
                      <span className="text-[9px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 px-1.5 py-0.5 rounded font-mono font-bold">
                        v2.4
                      </span>
                    </h2>
                    <p className="text-[8px] uppercase tracking-widest text-white/40 font-mono font-bold">
                      NEURAL DASHBOARD
                    </p>
                  </div>
                </div>

                {/* Status Orb */}
                <div className="flex items-center gap-1.5 bg-black/40 px-2 py-1 rounded-full border border-white/5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.7)] animate-pulse" />
                  <span className="text-[8px] text-emerald-400 font-mono font-bold">LIVE</span>
                </div>
              </div>

              {/* Simulated Live Diagnostic Monitor Widget */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 space-y-2 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-16 h-16 bg-cyan-500/[0.02] blur-xl rounded-full" />
                <div className="flex justify-between items-center text-[9px] font-mono text-cyan-400 font-bold">
                  <span>INTEL STATUS</span>
                  <span>NORMAL</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[9px] font-mono text-white/50 pt-1">
                  <div className="p-1 px-2 rounded bg-black/40 border border-white/5">
                    <span className="text-[8px] text-white/30 block uppercase">Corrections</span>
                    <span className="text-white font-bold">{syncAutoCorrectionCount}</span>
                  </div>
                  <div className="p-1 px-2 rounded bg-black/40 border border-white/5">
                    <span className="text-[8px] text-white/30 block uppercase">Added Nodes</span>
                    <span className="text-white font-bold">{localPrefs.serverLinks?.length || 0}</span>
                  </div>
                </div>
              </div>

              {/* Sidebar Navigation Options */}
              <nav className="space-y-1">
                {[
                  { id: "neural", label: "Neural Engine Core", sub: "9 SOTA models & auto-routing", icon: Brain, color: "text-amber-400", bgGlow: "bg-gradient-to-br from-amber-400 to-orange-500 shadow-[0_2px_10px_rgba(245,158,11,0.4)]" },
                  { id: "api_keys", label: "AI keys & server", sub: "Connect Claude, ChatGPT, Kimi, Gemini", icon: Key, color: "text-violet-400", bgGlow: "bg-gradient-to-br from-violet-500 to-pink-500 shadow-[0_2px_10px_rgba(139,92,246,0.4)]" },
                  { id: "dashboard", label: "Dashboard Control", sub: "Core stats & quick triggers", icon: Cpu, color: "text-cyan-400", bgGlow: "bg-gradient-to-br from-cyan-400 to-blue-500 shadow-[0_2px_10px_rgba(34,211,238,0.4)]" },
                  { id: "personality", label: "Personality Nodes", sub: "Vocal frequency & traits", icon: Sparkles, color: "text-pink-400", bgGlow: "bg-gradient-to-br from-pink-400 to-rose-500 shadow-[0_2px_10px_rgba(236,72,153,0.4)]" },
                  { id: "workspace", label: "Workspace Integration", sub: "Photos, Gmail, Cloud drive", icon: Layers, color: "text-emerald-400", bgGlow: "bg-gradient-to-br from-emerald-400 to-teal-500 shadow-[0_2px_10px_rgba(16,185,129,0.4)]" },
                  { id: "smart_server", label: "Smart Endpoint Hub", sub: "MCP, REST APIs, WebSockets", icon: Server, color: "text-violet-400", bgGlow: "bg-gradient-to-br from-violet-400 to-indigo-500 shadow-[0_2px_10px_rgba(139,92,246,0.4)]" },
                  { id: "memory", label: "Core Memories & Logs", sub: "Learned knowledge history", icon: History, color: "text-[#eab308]", bgGlow: "bg-gradient-to-br from-yellow-400 to-amber-500 shadow-[0_2px_10px_rgba(234,179,8,0.4)]" },
                  { id: "security", label: "System & Privacy", sub: "HUD, priority override toggles", icon: Shield, color: "text-red-400", bgGlow: "bg-gradient-to-br from-red-400 to-rose-600 shadow-[0_2px_10px_rgba(239,68,68,0.4)]" }
                ].map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id as any)}
                      className={`w-full text-left p-3 rounded-2xl transition-all flex items-center gap-3 border pointer-events-auto cursor-pointer ${
                        isActive 
                          ? "bg-gradient-to-r from-cyan-500/10 to-violet-500/10 border-cyan-500/20 text-white font-bold" 
                          : "bg-transparent border-transparent hover:bg-white/5 text-white/60 hover:text-white"
                      }`}
                    >
                      <div className={`p-2 rounded-xl transition-all ${isActive ? `${item.bgGlow} text-white border-transparent scale-110` : `bg-white/5 border border-white/5 ${item.color}`}`}>
                        <Icon size={14} />
                      </div>
                      <div>
                        <p className={`text-xs font-bold leading-tight ${isActive ? "text-white" : ""}`}>{item.label}</p>
                        <p className="text-[9px] text-white/30 font-medium leading-none mt-0.5">{item.sub}</p>
                      </div>
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* User Sign-out indicator */}
            <div className="pt-4 border-t border-white/5">
              {user ? (
                <div className="flex items-center justify-between bg-black/30 p-2.5 rounded-2xl border border-white/5">
                  <div className="min-w-0 pr-2">
                    <span className="text-[8px] bg-cyan-500/10 border border-cyan-500/35 px-1.5 text-cyan-300 font-mono rounded font-bold uppercase">SECURE USER</span>
                    <p className="text-[10px] text-white/70 truncate font-bold mt-1">{user.displayName || "Authorized Node"}</p>
                  </div>
                  <button
                    onClick={onLogout}
                    className="p-2 bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 rounded-xl transition-all cursor-pointer"
                    title="Disconnect account"
                  >
                    <Lock size={12} />
                  </button>
                </div>
              ) : (
                <button
                  onClick={onLogin}
                  className="w-full py-2.5 px-3 bg-gradient-to-r from-cyan-500 to-indigo-500 text-white font-bold text-[10px] uppercase rounded-xl tracking-wider hover:opacity-90 active:scale-95 transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <UserCheck size={12} />
                  Authorize Google
                </button>
              )}
            </div>
          </div>
        )}

        {/* RIGHT PANEL: Scrolled Content Zone */}
        <div className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 md:px-8 py-5 border-b border-white/5 bg-black/40 shrink-0">
            <div>
              <h1 className="text-base font-black text-white capitalize">
                {activeTab === "api_keys" ? "AI keys & server" : activeTab.replace("_", " ")}
              </h1>
              <p className="text-[10px] text-white/40 uppercase tracking-widest font-mono font-bold">
                {activeTab === "neural" ? "9 SOTA ENGINES & ADAPTIVE ROUTING" :
                 activeTab === "api_keys" ? "CONNECT YOUR AI MODELS" :
                 activeTab === "dashboard" ? "OS TELEMETRY & CHIP PREFERENTIAL" : 
                 activeTab === "personality" ? "SYNAPTIC TRAITS & FREQUENCY NODE" : 
                 activeTab === "workspace" ? "CLOUD STORAGE & PRIVATE MAIL STREAMS" : 
                 activeTab === "smart_server" ? "HOT-RECONNECT MCP GATEWAYS" : 
                 activeTab === "memory" ? "BIOGRAPHICAL TRACE INDEXLOG" : "SECURITY CONTROLS"}
              </p>
            </div>

            <button
              onClick={onClose}
              className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
              title="Close Panel"
            >
              <X size={20} />
            </button>
          </div>

          {/* Core Scroll View wrapper */}
          <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 custom-scrollbar select-none text-left">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                className="space-y-6 pb-4"
              >
                
                {/* 1. NEURAL ENGINE CORE TAB */}
                {activeTab === "neural" && (
                  <NeuralDashboard 
                    preferences={localPrefs}
                    onUpdatePreference={handleGeneralChange}
                    onUpgradeSystem={onUpgradeSystem}
                  />
                )}

                {/* 1b. AI KEYS, SERVER CONNECTION & FUSION */}
                {activeTab === "api_keys" && (
                  <ApiKeysPanel
                    preferences={localPrefs}
                    onUpdatePreference={handleGeneralChange}
                  />
                )}

                {/* 2. DASHBOARD OVERVIEW TAB */}
                {activeTab === "dashboard" && (
                  <>
                    {/* Welcome Glowing Header Card */}
                    <div className="relative p-5 rounded-3xl bg-gradient-to-r from-cyan-950/20 via-indigo-950/20 to-zinc-950/20 border border-cyan-500/20 overflow-hidden shadow-lg">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 blur-[50px] rounded-full pointer-events-none" />
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full bg-cyan-400/10 border border-cyan-400/30 flex items-center justify-center text-cyan-300">
                          <Zap size={22} className="animate-bounce" style={{ animationDuration: '3s' }} />
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-[9px] text-cyan-400 font-mono tracking-widest uppercase font-bold">SYSTEM ACTIVE STATE</span>
                          <h3 className="text-base font-black text-white">
                            {localPrefs.name ? `স্বাগতম, ${localPrefs.name}` : "Mimi Neural Active Interface"}
                          </h3>
                          <p className="text-[11px] text-white/50 leading-relaxed font-semibold">
                            মমি আপনার পছন্দ অনুযায়ী স্বয়ংক্রিয়ভাবে চিন্তা করতে শুরু করেছে।
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Advanced Server Control/Upgrade Card */}
                    {onUpgradeSystem && (
                      <div className="relative p-5 rounded-3xl bg-gradient-to-br from-[#12121e]/80 via-[#0a0a0f]/90 to-[#030305]/95 border border-amber-500/35 overflow-hidden shadow-[0_10px_40px_rgba(245,158,11,0.15)] flex flex-col md:flex-row justify-between items-start md:items-center gap-4 group hover:border-amber-400/50 transition-all duration-300" id="advance_upgrade_card">
                        <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/5 via-transparent to-orange-500/5 pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity" />
                        <div className="space-y-1.5 z-10 text-left">
                          <div className="flex items-center gap-1.5 text-amber-400 font-mono text-[9px] font-bold tracking-widest uppercase">
                            <Server size={14} className="animate-pulse" />
                            <span>Advance AI Server Upgrade Panel</span>
                          </div>
                          <h4 className="text-sm font-black text-white tracking-wide">Auto-Coating Server & Neural Upgrades</h4>
                          <p className="text-[11px] text-white/50 leading-relaxed max-w-md font-semibold">
                            আপনার মমি কৃত্রিম বুদ্ধিমত্তা সার্ভারটিকে সম্পূর্ণ সুরক্ষিত এবং সর্বশেষ ৯টি SOTA মডেলে আপডেট করতে নিচের কনসোল ট্রিগার করুন।
                          </p>
                        </div>
                        <button
                          onClick={onUpgradeSystem}
                          className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-650 hover:from-amber-400 hover:to-orange-500 text-white shadow-[0_3px_15px_rgba(245,158,11,0.35)] hover:shadow-[0_4px_20px_rgba(245,158,11,0.55)] border border-amber-400/40 text-xs font-bold font-mono tracking-wider uppercase transition-all cursor-pointer flex items-center justify-center gap-2 select-none active:scale-95 shrink-0 z-10 w-full md:w-auto"
                          id="btn_auto_coat_upgrade"
                        >
                          <Zap size={14} className="text-white animate-bounce" style={{ animationDuration: '2s' }} />
                          <span>Run Server Upgrade</span>
                        </button>
                      </div>
                    )}

                    {/* Home Interface Theme Selector (Classic / Neural 3D / Claude Style) */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/10 space-y-4">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-cyan-400">
                          <LayoutGrid size={16} />
                          <h4 className="text-xs font-black uppercase tracking-wider">Home Page Theme</h4>
                        </div>
                        <span className="text-[10px] font-mono text-white/45">
                          Switches instantly without interrupting voice or chat
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        {[
                          {
                            id: "classic" as const,
                            name: "Classic",
                            desc: "Original cyber orbital HUD",
                            icon: LayoutGrid,
                          },
                          {
                            id: "3d" as const,
                            name: "Neural 3D",
                            desc: "Interactive 3D orb & cards",
                            icon: Orbit,
                          },
                          {
                            id: "claude" as const,
                            name: "Claude Style",
                            desc: "Calm, minimal editorial UI",
                            icon: Feather,
                          },
                        ].map((themeOpt) => {
                          const ThemeIcon = themeOpt.icon;
                          const currentTheme = localPrefs.homeLayoutMode || "3d";
                          const isSelected = currentTheme === themeOpt.id;
                          return (
                            <button
                              key={themeOpt.id}
                              type="button"
                              onClick={() => {
                                const updated = { ...localPrefs, homeLayoutMode: themeOpt.id };
                                handleGeneralChange("homeLayoutMode", themeOpt.id);
                                onSave(updated);
                              }}
                              className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                                isSelected
                                  ? "bg-gradient-to-br from-cyan-500/20 to-violet-500/20 border-cyan-400/60 text-white shadow-lg"
                                  : "bg-black/45 border-white/10 hover:border-white/25 text-white/70 hover:text-white"
                              }`}
                            >
                              <div
                                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                                  isSelected ? "bg-cyan-400/25 text-cyan-300" : "bg-white/5 text-white/55"
                                }`}
                              >
                                <ThemeIcon size={16} />
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-bold leading-tight">{themeOpt.name}</div>
                                <div className="text-[10px] text-white/50 mt-0.5 leading-snug">
                                  {themeOpt.desc}
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      {(localPrefs.homeLayoutMode || "3d") === "claude" && (
                        <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between">
                          <div>
                            <p className="text-xs font-bold text-white">Claude Style Dark Mode</p>
                            <p className="text-[10px] text-white/45">
                              Toggle between warm off-white editorial light mode and warm dark mode
                            </p>
                          </div>
                          <PremiumToggle
                            enabled={Boolean(localPrefs.claudeDarkMode)}
                            onClick={() => {
                              const nextDark = !localPrefs.claudeDarkMode;
                              const updated = { ...localPrefs, claudeDarkMode: nextDark };
                              handleGeneralChange("claudeDarkMode", nextDark);
                              onSave(updated);
                            }}
                            colorTheme="cyan"
                          />
                        </div>
                      )}
                    </div>

                    {/* Choose AI Core (Model Selector) */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-4">
                      <div className="flex items-center gap-2 text-cyan-400">
                        <Cpu size={16} />
                        <h4 className="text-xs font-black uppercase tracking-wider">Choose Primary Neural Engine</h4>
                      </div>
                      
                      <div className="space-y-2">
                        <label className="text-[10px] text-white/40 uppercase font-bold tracking-wider pl-1 font-mono">
                          Select Core Model
                        </label>
                        <div className="relative">
                          <select
                            value={localPrefs.neuralCore || "Gemini"}
                            onChange={(e) => handleGeneralChange("neuralCore", e.target.value)}
                            className="w-full bg-[#09090c] border border-white/10 rounded-2xl px-5 py-3.5 text-sm appearance-none focus:border-cyan-500/50 outline-none transition-all cursor-pointer text-white"
                          >
                            <option value="Gemini" className="bg-[#0e0e12]">Gemini 4 Hydrogen + 3.8 Live (Google Next-Gen Core)</option>
                            <option value="Antigravity" className="bg-[#0e0e12]">Antigravity Agent (Google AI Studio system)</option>
                            <option value="ChatGPT" className="bg-[#0e0e12]">ChatGPT GPT-4.5 Ultra (OpenAI Engine)</option>
                            <option value="Claude" className="bg-[#0e0e12]">Claude 3.7 Sonnet (Anthropic Advanced reasoning)</option>
                            <option value="Grok" className="bg-[#0e0e12]">Grok 3 (xAI Real-time information)</option>
                            <option value="DeepSeek" className="bg-[#0e0e12]">DeepSeek-R1 (Full 671B Chain-of-Thought)</option>
                            <option value="DeepResearch" className="bg-[#0e0e12]">Deep Research (Google Agentic analysis)</option>
                          </select>
                          <SlidersHorizontal size={14} className="absolute right-5 top-1/2 -translate-y-1/2 opacity-45 pointer-events-none text-cyan-400" />
                        </div>
                        <p className="text-[10px] text-white/45 pl-1 leading-snug">
                          Selection triggers a secure neural hand-off. Mimi will safely optimize her computational style for the chosen core engine.
                        </p>
                      </div>
                    </div>

                    {/* 3D Visual Themes & Styling Selection */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-4">
                      <div className="flex items-center gap-2 text-cyan-400">
                        <Palette size={16} />
                        <h4 className="text-xs font-black uppercase tracking-wider">3D Holographic Themes</h4>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                        {[
                          { id: "crimson", name: "Crimson Red", bg: "bg-red-600", dot: "bg-red-500", text: "text-red-300" },
                          { id: "forest", name: "Forest Green", bg: "bg-emerald-600", dot: "bg-emerald-400", text: "text-emerald-300" },
                          { id: "charcoal", name: "Charcoal Black", bg: "bg-zinc-800", dot: "bg-sky-400", text: "text-sky-300" },
                          { id: "violet", name: "Violet Cosmic", bg: "bg-violet-600", dot: "bg-purple-400", text: "text-purple-300" }
                        ].map((t) => {
                          const isSelected = localPrefs.themeColor === t.id;
                          return (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => {
                                handleGeneralChange("themeColor", t.id);
                                handleGeneralChange("moodSyncEnabled", false);
                              }}
                              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
                                isSelected
                                  ? `${t.bg} border-white/40 text-white shadow-lg shadow-black/50 scale-[1.02]`
                                  : "bg-black/50 border-white/10 hover:border-white/20 text-white/70 hover:text-white"
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <span className={`w-2.5 h-2.5 rounded-full ${t.dot} ${isSelected ? 'animate-pulse' : ''}`} />
                                <span className="text-[11px] font-bold font-mono">{t.name}</span>
                              </div>
                              <span className="text-[8px] font-mono text-white/40 leading-none">3D Shading Link</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Mini Comment Section Settings Card */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-4">
                      <div className="flex items-center gap-2 text-pink-400">
                        <MessageSquare size={16} className="animate-pulse" />
                        <h4 className="text-xs font-black uppercase tracking-wider text-left">Mini Comment Section Settings</h4>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* 1. Toggle visibility */}
                        <div className="p-4 rounded-2xl bg-neutral-900/30 border border-white/5 flex items-center justify-between">
                          <div className="space-y-0.5 pr-2 text-left">
                            <p className="text-xs font-bold text-white">Show Comments Thread</p>
                            <p className="text-[9px] text-white/40 leading-snug">Display comments & answers under chats and search logs</p>
                          </div>
                          <PremiumToggle 
                            enabled={localPrefs.showMiniComments !== false} 
                            onClick={() => handleGeneralChange("showMiniComments", localPrefs.showMiniComments === false ? true : false)} 
                            colorTheme="purple" 
                          />
                        </div>

                        {/* 2. Toggle Auto reply */}
                        <div className="p-4 rounded-2xl bg-neutral-900/30 border border-white/5 flex items-center justify-between">
                          <div className="space-y-0.5 pr-2 text-left">
                            <p className="text-xs font-bold text-white">Automated Witty Answers</p>
                            <p className="text-[9px] text-white/40 leading-snug">Mimi responds automatically to your recorded comments</p>
                          </div>
                          <PremiumToggle 
                            enabled={localPrefs.miniCommentAutoReply !== false} 
                            onClick={() => handleGeneralChange("miniCommentAutoReply", localPrefs.miniCommentAutoReply === false ? true : false)} 
                            colorTheme="purple" 
                          />
                        </div>
                      </div>

                      {/* 3. Choose theme */}
                      <div className="space-y-2 text-left">
                        <label className="text-[10px] text-white/40 uppercase font-bold tracking-wider pl-1 font-mono">
                          Comment Thread Theme Layout
                        </label>
                        <div className="relative">
                          <select
                            value={localPrefs.miniCommentTheme || "accent"}
                            onChange={(e) => handleGeneralChange("miniCommentTheme", e.target.value)}
                            className="w-full bg-[#09090c] border border-white/10 rounded-2xl px-5 py-3 text-xs appearance-none focus:border-pink-500/50 outline-none transition-all cursor-pointer text-white"
                          >
                            <option value="accent" className="bg-[#0e0e12]">System Accent Glow (ম্যাচিং থিম)</option>
                            <option value="neon" className="bg-[#0e0e12]">Cyber Neon Pink (ফ্লুরোসেন্ট বেগুনি)</option>
                            <option value="slate" className="bg-[#0e0e12]">Slate Stealth Gray (ক্লাসিক গ্রে)</option>
                            <option value="crimson" className="bg-[#0e0e12]">Crimson Engine Red (লাল থিম)</option>
                          </select>
                          <SlidersHorizontal size={14} className="absolute right-5 top-1/2 -translate-y-1/2 opacity-45 pointer-events-none text-pink-400" />
                        </div>
                        <p className="text-[10px] text-white/45 pl-1 leading-snug">
                          Adjusts border typography, glowing neon drop shadows, and dark transparency of the threads.
                        </p>
                      </div>
                    </div>

                    {/* AI Studio Live-Sync & Telemetry patches */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 text-violet-400 pl-1">
                        <RefreshCw size={14} className="animate-spin-slow" />
                        <h4 className="text-xs font-black uppercase tracking-wider">Live Synchronization Toggles</h4>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        {[
                          { key: "autoSync", title: "Live Model Sync", desc: "Sync latest releases & API structures" },
                          { key: "intelligentAutoCorrection", title: "Intelligent Correction", desc: "Auto-repair logic/token mutations" },
                          { key: "serverHealthMonitoring", title: "Health Telemetry", desc: "Real-time edge server ping check" },
                          { key: "featureGeneration", title: "Feature Synthesis", desc: "Auto-enable newly generated modules" }
                        ].map((cfg) => {
                          const isActive = syncConfig[cfg.key as keyof SyncConfig];
                          return (
                            <div
                              key={cfg.key}
                              className="p-4 rounded-2xl bg-neutral-900/30 border border-white/5 hover:border-violet-500/10 transition-all flex justify-between items-center"
                            >
                              <div className="space-y-0.5">
                                <p className="text-xs font-bold text-white">{cfg.title}</p>
                                <p className="text-[9px] text-white/40 leading-snug">{cfg.desc}</p>
                              </div>
                              <PremiumToggle enabled={isActive} onClick={() => handleToggleSyncConfig(cfg.key as keyof SyncConfig)} colorTheme="violet" />
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Dashboard Homepage Feature Toggles */}
                    <div className="space-y-4 pt-4 border-t border-white/5">
                      <div className="flex items-center gap-2 text-cyan-400 pl-1">
                        <Monitor size={14} />
                        <h4 className="text-xs font-black uppercase tracking-wider">Homepage Layout Controls</h4>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        {[
                          { key: "showSystemMonitor", title: "System Monitor", desc: "Show active system health widget" },
                          { key: "autoGameMode", title: "Game Mode", desc: "Optimize resources for gaming" },
                          { key: "autoCodeMode", title: "Code Mode", desc: "Enable advanced IDE tools" },
                          { key: "autoRecordingMode", title: "Recording Mode", desc: "Enable auto session logging" },
                          { key: "satelliteMode", title: "Satellite Mode", desc: "Enable orbital data tracking" },
                          { key: "remoteControlMode", title: "Remote Control", desc: "Allow external management" }
                        ].map((cfg) => {
                          const isActive = localPrefs[cfg.key];
                          return (
                            <div
                              key={cfg.key}
                              className="p-4 rounded-2xl bg-neutral-900/30 border border-white/5 hover:border-cyan-500/10 transition-all flex justify-between items-center"
                            >
                              <div className="space-y-0.5">
                                <p className="text-xs font-bold text-white">{cfg.title}</p>
                                <p className="text-[9px] text-white/40 leading-snug">{cfg.desc}</p>
                              </div>
                              <PremiumToggle 
                                enabled={isActive} 
                                onClick={() => handleGeneralChange(cfg.key, !isActive)} 
                                colorTheme="cyan" 
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}


                {/* 2. PERSONALITY CORE */}
                {activeTab === "personality" && (
                  <>
                    {/* User Identity Info */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-5">
                      <div className="flex items-center gap-2 text-pink-400">
                        <User size={16} />
                        <h4 className="text-xs font-black uppercase tracking-wider">User Biographical Node</h4>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] text-white/40 uppercase font-bold tracking-wider pl-1 font-mono">Your Name / Alias</label>
                          <input
                            type="text"
                            value={localPrefs.name || ""}
                            onChange={(e) => handleGeneralChange("name", e.target.value)}
                            placeholder="What should Mimi call you?"
                            className="w-full bg-[#09090c] border border-white/10 rounded-2xl px-5 py-3 text-xs focus:border-pink-500/50 outline-none transition-all text-white font-semibold"
                          />
                        </div>
                        
                        <div className="space-y-1.5">
                          <label className="text-[10px] text-white/40 uppercase font-bold tracking-wider pl-1 font-mono">Relationship Dynamic</label>
                          <div className="relative">
                            <select
                              value={localPrefs.relationshipType || "Casual"}
                              onChange={(e) => handleGeneralChange("relationshipType", e.target.value)}
                              className="w-full bg-[#09090c] border border-white/10 rounded-2xl px-5 py-3 text-xs appearance-none focus:border-pink-500/50 outline-none transition-all cursor-pointer text-white font-semibold"
                            >
                              <option value="Casual" className="bg-[#0e0e12]">Casual Assistant (উপকারী সহকারী)</option>
                              <option value="Friend" className="bg-[#0e0e12]">Best Friend (প্রিয় বন্ধু)</option>
                              <option value="Romantic" className="bg-[#0e0e12]">Romantic Girl / Partner (প্রেমিকা)</option>
                            </select>
                            <HeartHandshake size={14} className="absolute right-5 top-1/2 -translate-y-1/2 opacity-45 pointer-events-none text-pink-400" />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Vocal Frequency Selection */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-4">
                      <div className="flex items-center gap-2 text-pink-400">
                        <Radio size={16} />
                        <h4 className="text-xs font-black uppercase tracking-wider">Vocal Synthesis Engine (Mimi Voice)</h4>
                      </div>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-[10px] text-white/40 uppercase font-bold pl-1 font-mono tracking-wider">Vocal Frequency Selection</label>
                          <div className="relative">
                            <select
                              value={localPrefs.voiceId || "Kore"}
                              onChange={(e) => handleGeneralChange("voiceId", e.target.value)}
                              className="w-full bg-[#09090c] border border-white/10 rounded-2xl px-5 py-3.5 text-xs appearance-none focus:border-pink-500/50 outline-none transition-all cursor-pointer text-white font-bold"
                            >
                              {AVAILABLE_VOICES.map((v) => (
                                <option key={v.id} value={v.id} className="bg-[#0e0e12]">{v.name}</option>
                              ))}
                            </select>
                            <Volume2 size={16} className="absolute right-5 top-1/2 -translate-y-1/2 opacity-45 pointer-events-none text-pink-400" />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] text-white/40 uppercase font-bold pl-1 font-mono tracking-wider">Accent & Emotional Profile</label>
                          <div className="relative">
                            <select
                              value={localPrefs.voiceProfile || "Sassy Mimi"}
                              onChange={(e) => handleGeneralChange("voiceProfile", e.target.value)}
                              className="w-full bg-[#09090c] border border-white/10 rounded-2xl px-5 py-3.5 text-xs appearance-none focus:border-pink-500/50 outline-none transition-all cursor-pointer text-white font-bold"
                            >
                              <option value="Sassy Mimi" className="bg-[#0e0e12]">Sassy Mimi (Playful, witty, and slightly teasing)</option>
                              <option value="Formal Manager" className="bg-[#0e0e12]">Formal Manager (Professional, structured, and authoritative)</option>
                              <option value="Playful Friend" className="bg-[#0e0e12]">Playful Friend (Warm, enthusiastic, and cheerful)</option>
                            </select>
                            <Sparkles size={16} className="absolute right-5 top-1/2 -translate-y-1/2 opacity-45 pointer-events-none text-pink-400" />
                          </div>
                        </div>

                        <p className="text-[10px] text-white/40 italic pl-1 leading-snug">
                          Language packs and speech patterns optimized automatically for English, Hindi, and Bengali vocal interactions.
                        </p>
                      </div>
                    </div>

                    {/* Advanced Synaptic Traits sliders */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-5">
                      <div className="flex items-center gap-2 text-pink-400">
                        <Sparkles size={16} />
                        <h4 className="text-xs font-black uppercase tracking-wider">Interactive Trait Modules</h4>
                      </div>

                      <div className="space-y-5">
                        {[
                          { key: "sassiness", min: "0", max: "100", label: "Sassiness & Playfulness", color: "text-orange-400", accent: "accent-orange-500", bg: "bg-orange-500/10" },
                          { key: "wit", min: "0", max: "100", label: "Wit Intensity & Humor", color: "text-cyan-400", accent: "accent-cyan-500", bg: "bg-cyan-500/10" },
                          { key: "emotionality", min: "0", max: "100", label: "Expressiveness & Empathy", color: "text-pink-400", accent: "accent-pink-500", bg: "bg-pink-500/10" }
                        ].map((trait) => (
                          <div key={trait.key} className="space-y-2">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-bold text-white/85">{trait.label}</span>
                              <span className={`font-mono text-[10px] font-bold ${trait.color} ${trait.bg} px-2.5 py-0.5 rounded-full`}>
                                {localPrefs.traits[trait.key as "sassiness" | "wit" | "emotionality"]}%
                              </span>
                            </div>
                            <input
                              type="range"
                              min={trait.min}
                              max={trait.max}
                              value={localPrefs.traits[trait.key as "sassiness" | "wit" | "emotionality"]}
                              onChange={(e) => handleTraitChange(trait.key, parseInt(e.target.value))}
                              className={`w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer ${trait.accent}`}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}


                {/* 3. WORKSPACE HUBS */}
                {activeTab === "workspace" && (
                  <>
                    {/* Status Alert */}
                    <div className="p-4 rounded-2xl bg-zinc-950/40 border border-emerald-500/20 text-xs flex justify-between items-center">
                      <div className="flex items-center gap-2.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                        <span className="text-white/80 font-bold">Secure Google Service Interface</span>
                      </div>
                      <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase">Ready</span>
                    </div>

                    {/* Redesigned grid with neon style and hover animations */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      {/* 1. PHOTO HUB */}
                      <div className="p-5 rounded-3xl bg-neutral-900/40 border border-orange-500/10 hover:border-orange-500/30 transition-all duration-300 space-y-4 shadow-lg group relative">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-orange-500/[0.01] blur-xl rounded-full" />
                        <div className="flex items-center gap-3 text-orange-400">
                          <div className="p-2 bg-orange-500/10 border border-orange-500/20 rounded-xl">
                            <ImageIcon size={16} />
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider">Photo Hub</h4>
                            <p className="text-[9px] text-white/30 font-semibold uppercase font-mono">ফটো সেটিং</p>
                          </div>
                        </div>

                        <div className="space-y-3 pt-1">
                          <div className="flex flex-col gap-1">
                            <label className="text-[9px] text-white/40 uppercase font-bold tracking-wider font-mono">Default View Filter</label>
                            <select
                              value={localPrefs.workspace?.photoCategory || "all"}
                              onChange={(e) => handleWorkspaceChange("photoCategory", e.target.value)}
                              className="w-full bg-[#09090c] border border-white/5 rounded-xl px-3 py-2 text-xs text-white"
                            >
                              <option value="all" className="bg-[#0e0e12]">All Moments (সব ছবি)</option>
                              <option value="cat" className="bg-[#0e0e12]">Cats & Pets (পোষা বিড়াল)</option>
                              <option value="nature" className="bg-[#0e0e12]">Nature Highlights (প্রকৃতি)</option>
                              <option value="people" className="bg-[#0e0e12]">Friends & Family (পরিবার ও বন্ধু)</option>
                              <option value="uploaded" className="bg-[#0e0e12]">My Uploads (আমদানি করা ছবি)</option>
                            </select>
                          </div>

                          <div className="flex justify-between items-center pt-2 border-t border-white/5">
                            <div>
                              <p className="text-[11px] font-bold text-white/90">Topic Auto-Match</p>
                              <p className="text-[8px] text-white/45">Visualizes spoken memories</p>
                            </div>
                            <PremiumToggle 
                              enabled={!!localPrefs.workspace?.photoAutoMatch} 
                              onClick={() => handleWorkspaceChange("photoAutoMatch", !localPrefs.workspace?.photoAutoMatch)} 
                              colorTheme="orange"
                            />
                          </div>
                        </div>
                      </div>

                      {/* 2. GMAIL CLIENT */}
                      <div className="p-5 rounded-3xl bg-neutral-900/40 border border-rose-500/10 hover:border-rose-500/30 transition-all duration-300 space-y-4 shadow-lg group relative">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-rose-500/[0.01] blur-xl rounded-full" />
                        <div className="flex items-center gap-3 text-rose-400">
                          <div className="p-2 bg-rose-500/10 border border-rose-500/20 rounded-xl">
                            <Mail size={16} />
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider">Gmail Streams</h4>
                            <p className="text-[9px] text-white/30 font-semibold uppercase font-mono">জিমেইল সেটিং</p>
                          </div>
                        </div>

                        <div className="space-y-3 pt-1">
                          <div className="space-y-1">
                            <div className="flex justify-between text-[9px] font-mono tracking-wider text-white/40 font-bold uppercase">
                              <span>Max mail sync limit</span>
                              <span className="text-rose-400 font-bold">{localPrefs.workspace?.gmailLimit || 15} msg</span>
                            </div>
                            <input
                              type="range"
                              min="5"
                              max="50"
                              step="5"
                              value={localPrefs.workspace?.gmailLimit || 15}
                              onChange={(e) => handleWorkspaceChange("gmailLimit", parseInt(e.target.value))}
                              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-rose-500"
                            />
                          </div>

                          <div className="flex justify-between items-center pt-2 border-t border-white/5">
                            <div>
                              <p className="text-[11px] font-bold text-white/90">Instant Mark-As-Read</p>
                              <p className="text-[8px] text-white/45">Read state on opening inside Mimi</p>
                            </div>
                            <PremiumToggle 
                              enabled={!!localPrefs.workspace?.gmailAutoRead} 
                              onClick={() => handleWorkspaceChange("gmailAutoRead", !localPrefs.workspace?.gmailAutoRead)} 
                              colorTheme="rose"
                            />
                          </div>
                        </div>
                      </div>

                      {/* 3. GOOGLE DRIVE */}
                      <div className="p-5 rounded-3xl bg-neutral-900/40 border border-emerald-500/10 hover:border-emerald-500/30 transition-all duration-300 space-y-4 shadow-lg group relative">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/[0.01] blur-xl rounded-full" />
                        <div className="flex items-center gap-3 text-emerald-400">
                          <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                            <HardDrive size={16} />
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider">Google Drive</h4>
                            <p className="text-[9px] text-white/30 font-semibold uppercase font-mono">ড্রাইভ সেটিং</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 pt-1">
                          <div className="space-y-1">
                            <label className="text-[8px] text-white/40 uppercase font-black font-mono">Storage Filter</label>
                            <select
                              value={localPrefs.workspace?.driveListFilter || "all"}
                              onChange={(e) => handleWorkspaceChange("driveListFilter", e.target.value)}
                              className="w-full bg-[#09090c] border border-white/5 rounded-xl px-2.5 py-1.5 text-[11px] text-white"
                            >
                              <option value="all" className="bg-[#0e0e12]">All files</option>
                              <option value="docs" className="bg-[#0e0e12]">Documents</option>
                              <option value="images" className="bg-[#0e0e12]">Images & pets</option>
                              <option value="code" className="bg-[#0e0e12]">Code files</option>
                            </select>
                          </div>

                          <div className="space-y-1">
                            <label className="text-[8px] text-white/40 uppercase font-black font-mono">Safety Ceiling</label>
                            <select
                              value={localPrefs.workspace?.driveSafetyLimit || 10}
                              onChange={(e) => handleWorkspaceChange("driveSafetyLimit", parseInt(e.target.value))}
                              className="w-full bg-[#09090c] border border-white/5 rounded-xl px-2.5 py-1.5 text-[11px] text-white"
                            >
                              <option value="5" className="bg-[#0e0e12]">5 MB Safe</option>
                              <option value="10" className="bg-[#0e0e12]">10 MB Default</option>
                              <option value="25" className="bg-[#0e0e12]">25 MB High</option>
                              <option value="50" className="bg-[#0e0e12]">50 MB Bandwidth</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      {/* 4. GOOGLE CHAT */}
                      <div className="p-5 rounded-3xl bg-neutral-900/40 border border-sky-500/10 hover:border-sky-500/30 transition-all duration-300 space-y-4 shadow-lg group relative">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-sky-500/[0.01] blur-xl rounded-full" />
                        <div className="flex items-center gap-3 text-sky-400">
                          <div className="p-2 bg-sky-500/10 border border-sky-500/20 rounded-xl">
                            <MessageSquare size={16} />
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider">Google Chat</h4>
                            <p className="text-[9px] text-white/30 font-semibold uppercase font-mono">গুগল চ্যাট</p>
                          </div>
                        </div>

                        <div className="flex justify-between items-center pt-3 border-t border-white/5">
                          <div>
                            <p className="text-[11px] font-bold text-white/90">Auto-Dispatch Assist</p>
                            <p className="text-[8px] text-white/45">AI prompt ideas for new messages</p>
                          </div>
                          <PremiumToggle 
                            enabled={!!localPrefs.workspace?.chatAutoResponse} 
                            onClick={() => handleWorkspaceChange("chatAutoResponse", !localPrefs.workspace?.chatAutoResponse)} 
                            colorTheme="cyan"
                          />
                        </div>
                      </div>

                      {/* 5. GOOGLE TASKS */}
                      <div className="p-5 rounded-3xl bg-neutral-900/40 border border-[#eab308]/10 hover:border-[#eab308]/30 transition-all duration-300 space-y-4 shadow-lg group relative">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-yellow-500/[0.01] blur-xl rounded-full" />
                        <div className="flex items-center gap-3 text-yellow-500">
                          <div className="p-2 bg-yellow-500/10 border border-yellow-500/20 rounded-xl">
                            <CheckSquare size={16} />
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider">Google Tasks</h4>
                            <p className="text-[9px] text-white/30 font-semibold uppercase font-mono">গুগল টাস্ক সেটিং</p>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[8px] text-white/40 uppercase font-bold pl-0.5 font-mono">Sorting Logic</label>
                          <select
                            value={localPrefs.workspace?.tasksSortStyle || "dateCreated"}
                            onChange={(e) => handleWorkspaceChange("tasksSortStyle", e.target.value)}
                            className="w-full bg-[#09090c] border border-white/5 rounded-xl px-3 py-2 text-xs text-white"
                          >
                            <option value="dateCreated" className="bg-[#0e0e12]">Created Date (সৃষ্টির তারিখ)</option>
                            <option value="dueDate" className="bg-[#0e0e12]">Due Date threshold (শেষ সময়)</option>
                            <option value="alphabet" className="bg-[#0e0e12]">Alphabetical (অক্ষরানুসারে)</option>
                          </select>
                        </div>
                      </div>

                      {/* 6. ADVANCED CONTACTS */}
                      <div className="p-5 rounded-3xl bg-neutral-900/40 border border-teal-500/10 hover:border-teal-500/30 transition-all duration-300 space-y-4 shadow-lg group relative">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-teal-500/[0.01] blur-xl rounded-full" />
                        <div className="flex items-center gap-3 text-teal-400">
                          <div className="p-2 bg-teal-500/10 border border-teal-500/20 rounded-xl">
                            <Users size={16} />
                          </div>
                          <div>
                            <h4 className="text-xs font-black uppercase tracking-wider">Contacts Sync</h4>
                            <p className="text-[9px] text-white/30 font-semibold uppercase font-mono">কন্টাক্ট সেটিং</p>
                          </div>
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[8px] text-white/40 uppercase font-bold pl-0.5 font-mono">Sorting Index</label>
                          <select
                            value={localPrefs.workspace?.contactsSortStyle || "first"}
                            onChange={(e) => handleWorkspaceChange("contactsSortStyle", e.target.value)}
                            className="w-full bg-[#09090c] border border-white/5 rounded-xl px-3 py-2 text-xs text-white"
                          >
                            <option value="first" className="bg-[#0e0e12]">First Name (নামের প্রথম অংশ)</option>
                            <option value="last" className="bg-[#0e0e12]">Last Name (নামের পদবী)</option>
                          </select>
                        </div>
                      </div>

                    </div>
                  </>
                )}


                {/* 4. SMART ENDPOINT HUB (REST / MCP / WEBSOCKETS) */}
                {activeTab === "smart_server" && (
                  <>
                    {/* Glowing 3D Server Core Cover */}
                    <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-black/40 shadow-2xl p-4 sm:p-5 flex flex-col md:flex-row gap-5 items-center select-none">
                      <div className="relative w-full md:w-36 h-36 md:h-28 rounded-2xl overflow-hidden shrink-0 border border-white/10 shadow-[0_4px_24px_rgba(139,92,246,0.15)] bg-neutral-950">
                        <img 
                          src="/src/assets/images/colorful_3d_core_1782217293823.jpg" 
                          alt="Quantum Endpoint Server Core" 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover transition-all duration-700 hover:scale-110 hover:rotate-1"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                        <div className="absolute top-2 left-2 flex items-center gap-1 bg-violet-500/30 backdrop-blur-md border border-violet-400/40 px-2 py-0.5 rounded-full shadow-[0_0_8px_rgba(139,92,246,0.3)]">
                          <span className="text-[7.5px] font-mono text-violet-200 font-extrabold tracking-wider uppercase">MCP GATEWAY v3</span>
                        </div>
                      </div>
                      
                      <div className="flex-1 w-full text-center md:text-left space-y-1">
                        <div className="flex items-center justify-center md:justify-start gap-2 flex-wrap">
                          <h4 className="text-sm font-black text-white tracking-wide uppercase">Smart Endpoint & Gateway Hub</h4>
                          <span className="text-[8px] font-mono tracking-wider font-extrabold px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">REST CORES OK</span>
                        </div>
                        <p className="text-[11px] text-white/50 leading-relaxed max-w-xl">
                          Unify and register REST endpoints, custom WebSockets, dynamic model endpoints, and website references. The Advanced Server validates their response rates automatically.
                        </p>
                      </div>
                    </div>

                    {/* Registration form */}
                    <div className="p-5 rounded-3xl bg-neutral-900/40 border border-white/5 space-y-4">
                      <h4 className="text-xs font-bold text-white/90 uppercase tracking-wide">
                        {editingHubId ? "Edit Endpoint Node State" : "Register and Index New Hub Endpoint"}
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        <div className="space-y-1.5">
                          <label className="text-[9px] text-white/40 uppercase font-black tracking-wider pl-1 font-mono">Service Name</label>
                          <input
                            type="text"
                            value={newHubName}
                            onChange={(e) => setNewHubName(e.target.value)}
                            placeholder="e.g., Code Runner, Search Module"
                            className="w-full bg-[#09090c] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[9px] text-white/40 uppercase font-black tracking-wider pl-1 font-mono">Category / Protocol</label>
                          <select
                            value={newHubType}
                            onChange={(e) => setNewHubType(e.target.value as any)}
                            className="w-full bg-[#09090c] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white cursor-pointer"
                          >
                            <option value="api">REST API Client / End-point</option>
                            <option value="mcp">Model Context Protocol (MCP)</option>
                            <option value="websocket">Websocket Gateway Gateway (ws://)</option>
                            <option value="custom">Custom NodeJS API Server</option>
                            <option value="search">Search Engine / Site Indexed URL</option>
                            <option value="website">Documentation / Website Link</option>
                          </select>
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[9px] text-white/40 uppercase font-black tracking-wider pl-1 font-mono">Protocol URL Address</label>
                        <input
                          type="text"
                          value={newHubUrl}
                          onChange={(e) => setNewHubUrl(e.target.value)}
                          placeholder="e.g., http://localhost:8080/api or ws://127.0.0.1:3001"
                          className="w-full bg-[#09090c] border border-white/10 rounded-xl px-4 py-2.5 text-xs text-cyan-300 font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        <div className="p-3 bg-black/40 rounded-xl border border-white/5 flex items-center justify-between">
                          <div className="space-y-0.5 pr-2">
                            <span className="text-[11px] font-bold text-white/90">Auto Reconnect</span>
                            <span className="text-[8px] text-white/40 block leading-tight">Verifies health on assistant load</span>
                          </div>
                          <PremiumToggle enabled={newHubAutoReconnect} onClick={() => setNewHubAutoReconnect(!newHubAutoReconnect)} colorTheme="violet" />
                        </div>

                        <div className="p-3 bg-black/40 rounded-xl border border-white/5 flex items-center justify-between">
                          <div className="space-y-0.5 pr-2">
                            <span className="text-[11px] font-bold text-white/90">Background Diagnostics</span>
                            <span className="text-[8px] text-white/40 block leading-tight">Keeps connection streams alive</span>
                          </div>
                          <PremiumToggle enabled={newHubAutoUpdate} onClick={() => setNewHubAutoUpdate(!newHubAutoUpdate)} colorTheme="violet" />
                        </div>
                      </div>

                      {hubFormError && (
                        <div className="p-3 bg-red-950/25 border border-red-900/35 rounded-2xl text-xs text-red-300 font-mono flex items-start gap-2">
                          <AlertCircle size={14} className="mt-0.5 shrink-0 text-red-400 animate-pulse" />
                          <p>{hubFormError}</p>
                        </div>
                      )}

                      <div className="flex gap-2">
                        {editingHubId && (
                          <button
                            onClick={() => {
                              setNewHubName("");
                              setNewHubUrl("");
                              setNewHubType("api");
                              setNewHubAutoReconnect(true);
                              setNewHubAutoUpdate(true);
                              setEditingHubId(null);
                            }}
                            className="flex-1 py-2.5 bg-neutral-800 text-white/70 hover:bg-neutral-700 text-xs font-bold rounded-xl pointer-events-auto transition-all cursor-pointer"
                          >
                            Cancel
                          </button>
                        )}
                        <button
                          onClick={handleSaveHubService}
                          disabled={verifyingServer || !newHubName.trim() || !newHubUrl.trim()}
                          className="flex-[2] py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:opacity-90 disabled:opacity-50 text-white text-xs font-bold rounded-xl pointer-events-auto transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          {verifyingServer ? (
                            <RefreshCw size={12} className="animate-spin" />
                          ) : (
                            <Plus size={14} />
                          )}
                          <span>{editingHubId ? "Update Endpoint" : "Save and Sync Endpoint"}</span>
                        </button>
                      </div>
                    </div>

                    {/* Trigger Global Maintenance */}
                    {localPrefs.serverLinks && localPrefs.serverLinks.length > 0 && (
                      <div className="p-4 bg-zinc-950/30 border border-violet-500/20 rounded-2xl flex justify-between items-center text-xs">
                        <div>
                          <p className="font-bold text-white">Interactive Diagnostics</p>
                          <p className="text-[9px] text-white/40">Tests and indexes all added servers instantaneously</p>
                        </div>
                        <button
                          onClick={handleSystemWideUpdateCheck}
                          className="px-4 py-2 bg-violet-600 hover:bg-violet-500 rounded-xl text-white font-mono text-[10px] font-extrabold flex items-center gap-1.5 cursor-pointer"
                        >
                          <RefreshCw size={11} className={testingServerId ? "animate-spin" : ""} />
                          Run Diagnostic Check
                        </button>
                      </div>
                    )}

                    {/* Directory list of saved items */}
                    {localPrefs.serverLinks && localPrefs.serverLinks.length > 0 && (
                      <div className="space-y-3">
                        <span className="text-[9px] text-white/40 font-mono uppercase tracking-widest block pl-1 font-bold">DIRECTORY ARCHIVE</span>
                        
                        <div className="space-y-3.5">
                          {localPrefs.serverLinks.map((link: any) => {
                            const statusObj = serverStatuses[link.id] || { status: "disconnected" };
                            return (
                              <div
                                key={link.id}
                                className="p-4 rounded-3xl bg-neutral-900/30 border border-white/5 space-y-3"
                              >
                                <div className="flex justify-between items-start">
                                  <div className="space-y-1">
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <p className="text-white text-xs font-bold leading-none">{link.name}</p>
                                      <span className="text-[8px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider bg-violet-500/15 border border-violet-500/20 text-violet-300 font-mono">
                                        {link.type?.toUpperCase() || "API"}
                                      </span>
                                    </div>
                                    <p className="text-[10px] font-mono text-cyan-400 select-all font-semibold leading-relaxed truncate max-w-[280px]">
                                      {link.url}
                                    </p>
                                  </div>

                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[8px] font-mono tracking-widest text-white/30 uppercase">
                                      {link.enabled ? "Online" : "Paused"}
                                    </span>
                                    <PremiumToggle enabled={!!link.enabled} onClick={() => handleToggleHubEnabled(link)} colorTheme="violet" />
                                  </div>
                                </div>

                                <div className="p-3 bg-black/40 rounded-2xl border border-white/5 text-[10px] font-mono text-white/50 space-y-1">
                                  <div className="flex justify-between">
                                    <span>Added Time:</span>
                                    <span className="text-violet-400">{link.addedTime || "Standard node"}</span>
                                  </div>
                                  <div className="flex justify-between">
                                    <span>Verified Uptime:</span>
                                    <span className="text-emerald-400 font-bold">{statusObj.uptime || link.uptime || "99.9%"}</span>
                                  </div>
                                  <div className="flex justify-between items-center">
                                    <span>State:</span>
                                    {statusObj.status === "connecting" ? (
                                      <span className="text-orange-400 animate-pulse font-bold">Testing...</span>
                                    ) : statusObj.status === "connected" ? (
                                      <span className="text-emerald-400 font-bold">CONNECTED ({statusObj.latency || "14ms"})</span>
                                    ) : statusObj.status === "failed" ? (
                                      <span className="text-red-400 font-bold">DISCONNECTED</span>
                                    ) : (
                                      <span className="text-white/30">IDLE</span>
                                    )}
                                  </div>
                                </div>

                                <div className="grid grid-cols-3 gap-2 text-[9px] font-bold uppercase tracking-wider font-sans">
                                  <button
                                    onClick={() => handleTestConnection(link)}
                                    className="py-1.5 rounded-lg bg-white/5 text-white/80 hover:bg-white/10 text-center transition-all cursor-pointer border border-white/5"
                                  >
                                    Test Connection
                                  </button>
                                  <button
                                    onClick={() => handleEditHubService(link)}
                                    className="py-1.5 rounded-lg bg-neutral-800 text-white/85 hover:bg-neutral-700 text-center transition-all cursor-pointer border border-white/5"
                                  >
                                    Edit
                                  </button>
                                  <button
                                    onClick={() => handleDeleteHubService(link.id)}
                                    className="py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-center transition-all cursor-pointer border border-red-500/10"
                                  >
                                    Delete
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </>
                )}


                {/* 5. AI CORE MEMORIES & RECORDS */}
                {activeTab === "memory" && (
                  <>
                    <div className="flex flex-wrap md:flex-nowrap rounded-2xl bg-[#09090c] p-1 border border-white/5 gap-1 select-none">
                      {[
                        { id: "conversations", label: "Sessions", count: conversations?.length || 0, icon: MessageSquare },
                        { id: "memories", label: "Core Facts", count: memories?.length || 0, icon: Brain },
                        { id: "searches", label: "Searches", count: searchHistory?.length || 0, icon: Search },
                        { id: "commands", label: "Commands", count: commandLogs?.length || 0, icon: Activity },
                        { id: "voice", label: "Voice activity", count: voiceLogs?.length || 0, icon: Mic }
                      ].map((sub) => {
                        const SubIcon = sub.icon;
                        const isSubActive = historySubTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            onClick={() => setHistorySubTab(sub.id as any)}
                            className={`flex-1 py-2 px-1 text-[9px] uppercase font-bold tracking-widest rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer md:whitespace-nowrap ${
                              isSubActive 
                                ? "bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-md font-black" 
                                : "text-white/40 hover:text-white/85"
                            }`}
                          >
                            <SubIcon size={10} />
                            <span>{sub.label} ({sub.count})</span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Chat Sessions list view */}
                    {historySubTab === "conversations" && (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/50 pl-1 font-bold">Active Chat Conversations</span>
                          {onStartNewConversation && (
                            <button
                              onClick={onStartNewConversation}
                              className="px-3 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 text-cyan-300 rounded-xl text-[10px] uppercase font-bold transition-all cursor-pointer"
                            >
                              + Start New Session
                            </button>
                          )}
                        </div>

                        {!user && (
                          <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-2xl text-[10px] text-cyan-300 font-semibold flex items-center gap-2">
                            <Info size={12} className="shrink-0 animate-pulse" />
                            <span>Guest Mode: Chat histories are saved securely on this local browser session. Authorize Google above to sync across devices.</span>
                          </div>
                        )}

                        {conversations?.length === 0 ? (
                          <div className="p-8 text-center bg-white/[0.02] border border-white/5 rounded-3xl text-sm text-white/35 font-medium">
                            No chats logged. Close settings and say hello to Mimi.
                          </div>
                        ) : (
                          <div className="space-y-2 max-h-[420px] overflow-y-auto custom-scrollbar pr-1">
                            {conversations.map((c) => {
                              const isActive = c.id === currentConversationId;
                              return (
                                <div
                                  key={c.id}
                                  className={`flex flex-col p-3.5 rounded-2xl border transition-all text-xs ${
                                    isActive 
                                      ? "bg-gradient-to-b from-[#09090c] to-neutral-950/60 border-cyan-500/20 shadow-lg" 
                                      : "bg-neutral-900/40 border-white/5 hover:border-white/10"
                                  }`}
                                >
                                  <div className="flex items-center justify-between w-full">
                                    <button
                                      onClick={() => onSelectConversation?.(c.id)}
                                      className="flex-1 text-left min-w-0 pr-3 cursor-pointer"
                                    >
                                      <p className={`truncate text-white/80 ${isActive ? "text-cyan-300 font-bold" : ""}`}>
                                        {c.lastMessage || "Empty dialog session"}
                                      </p>
                                      <span className="text-[8.5px] font-mono text-white/30 block mt-0.5">
                                        {c.createdAt?.seconds 
                                          ? new Date(c.createdAt.seconds * 1000).toLocaleString("en-IN", { hour: "numeric", minute: "numeric", day: "numeric", month: "short" })
                                          : "Active Now"}
                                      </span>
                                    </button>

                                    <div className="flex items-center gap-2">
                                      {isActive && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />}
                                      <button
                                        onClick={() => onDeleteConversation?.(c.id)}
                                        className="p-1.5 bg-[#000]/10 text-white/40 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all"
                                        title="Delete conversation"
                                      >
                                        <Trash2 size={12} />
                                      </button>
                                    </div>
                                  </div>

                                  {/* Render individual messages with Mini Comment Sections */}
                                  {isActive && messages && messages.length > 0 && (
                                    <div className="mt-3 pt-3 border-t border-white/5 space-y-3 pl-1 text-left">
                                      <span className="text-[9px] font-mono uppercase tracking-[0.2em] text-cyan-400 font-black block">Active Chat Messages & Comments</span>
                                      <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar pr-1 pl-1">
                                        {messages.map((msg, idx) => {
                                          const msgId = msg.id || `msg-${c.id}-${idx}`;
                                          const msgComments = comments[msgId] || [];
                                          return (
                                            <div key={msgId} className="p-3 bg-black/40 border border-white/5 rounded-xl space-y-2.5 text-xs">
                                              <div className="flex justify-between items-center">
                                                <span className={`text-[9px] font-mono uppercase font-black tracking-wider ${msg.sender === "user" ? "text-violet-400" : "text-pink-400 animate-pulse"}`}>
                                                  {msg.sender === "user" ? "You (User Typings)" : "Mimi"}
                                                </span>
                                                <span className="text-[8px] text-white/20 font-mono">Chat Data</span>
                                              </div>
                                              <p className="text-white/80 select-text leading-relaxed font-sans">{msg.text}</p>
                                              
                                              {/* Mini Comment Section */}
                                              {preferences.showMiniComments !== false && (
                                                <div className={`mt-2 p-2.5 rounded-xl border ${
                                                  preferences.miniCommentTheme === "neon" ? "bg-fuchsia-950/15 border-fuchsia-500/20 shadow-[0_0_8px_rgba(244,114,182,0.1)]" :
                                                  preferences.miniCommentTheme === "slate" ? "bg-zinc-900 border-zinc-700/30" :
                                                  preferences.miniCommentTheme === "crimson" ? "bg-red-950/15 border-red-500/20 shadow-[0_0_8px_rgba(239,68,68,0.1)]" :
                                                  "bg-cyan-950/10 border-cyan-500/10"
                                                }`}>
                                                  {/* Comments Thread */}
                                                  {msgComments.map((com, comIdx) => (
                                                    <div key={comIdx} className="space-y-1 pb-1.5 border-b border-white/5 mb-1.5 last:border-0 last:pb-0 last:mb-0">
                                                      <div className="flex justify-between text-[8px] font-mono text-white/30">
                                                        <span>User Note:</span>
                                                        <span>{com.timestamp}</span>
                                                      </div>
                                                      <p className="text-white/70 italic text-[10px]">"{com.comment}"</p>
                                                      <div className="flex gap-1.5 items-start mt-1 bg-black/30 p-1.5 rounded-lg border border-white/5">
                                                        <span className="text-[8px] font-mono text-cyan-400 font-black uppercase shrink-0">Mimi Answer:</span>
                                                        <p className="text-white/90 text-[10px] leading-tight font-sans">{com.answer}</p>
                                                      </div>
                                                    </div>
                                                  ))}
                                                  
                                                  {/* Add Comment Input */}
                                                  <div className="flex gap-1.5 mt-2">
                                                    <input
                                                      type="text"
                                                      placeholder="Add comment..."
                                                      id={`input-${msgId}`}
                                                      onKeyDown={(e) => {
                                                        if (e.key === 'Enter') {
                                                          const val = (e.target as HTMLInputElement).value;
                                                          if (val.trim()) {
                                                            handleAddComment(msgId, val);
                                                            (e.target as HTMLInputElement).value = '';
                                                          }
                                                        }
                                                      }}
                                                      className="flex-1 bg-black/60 border border-white/10 rounded-lg px-2 py-1 text-[10px] text-white outline-none focus:border-cyan-400"
                                                    />
                                                    <button
                                                      onClick={() => {
                                                        const el = document.getElementById(`input-${msgId}`) as HTMLInputElement;
                                                        if (el && el.value.trim()) {
                                                          handleAddComment(msgId, el.value);
                                                          el.value = '';
                                                        }
                                                      }}
                                                      className="px-2 py-1 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/20 rounded-lg text-[9px] font-bold uppercase transition-all"
                                                    >
                                                      Add
                                                    </button>
                                                  </div>
                                                </div>
                                              )}
                                            </div>
                                          );
                                        })}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Learned biographical details facts */}
                    {historySubTab === "memories" && (
                      <div className="space-y-4">
                        <span className="text-xs text-white/50 block pl-1 font-bold">Mimi's Long-term Learnt Knowledge Base</span>

                        {!user && (
                          <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-2xl text-[10px] text-cyan-300 font-semibold flex items-center gap-2">
                            <Info size={12} className="shrink-0 animate-pulse" />
                            <span>Guest Mode: Learned facts are stored securely on this local device. Authorize Google above to synchronize your biographical memories.</span>
                          </div>
                        )}

                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={newMemoryText}
                            onChange={(e) => setNewMemoryText(e.target.value)}
                            placeholder="Add custom biographical detail: Shona is learning React..."
                            className="flex-1 bg-[#09090c] border border-white/10 rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none placeholder:text-white/20"
                            onKeyDown={(e) => {
                              if (e.key === "Enter" && newMemoryText.trim()) {
                                onAddMemory?.(newMemoryText.trim());
                                setNewMemoryText("");
                              }
                            }}
                          />
                          <button
                            onClick={() => {
                              if (newMemoryText.trim()) {
                                onAddMemory?.(newMemoryText.trim());
                                setNewMemoryText("");
                              }
                            }}
                            className="px-5 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-2xl transition-all shrink-0 cursor-pointer"
                          >
                            Add Fact
                          </button>
                        </div>

                        {memories?.length === 0 ? (
                          <div className="p-8 text-center bg-white/[0.02] border border-white/5 rounded-3xl text-xs text-white/35">
                            Mimi hasn't auto-extracted any permanent memories yet. Chat with her more to expand memory nodes!
                          </div>
                        ) : (
                          <div className="space-y-1.5 max-h-[220px] overflow-y-auto custom-scrollbar pr-1">
                            {memories.map((m) => {
                              const isAuto = m.category === "auto-extracted";
                              return (
                                <div
                                  key={m.id}
                                  className="p-3 bg-[#09090c]/40 border border-white/5 rounded-2xl flex items-center justify-between text-xs"
                                >
                                  <div className="min-w-0 flex-1 pr-3">
                                    <p className="text-white/80 leading-relaxed font-semibold">{m.fact}</p>
                                    <span className={`text-[8px] uppercase tracking-wider px-2 py-0.5 mt-1 inline-block rounded font-bold font-mono ${isAuto ? "bg-pink-500/10 border border-pink-500/15 text-pink-400" : "bg-teal-500/10 border border-teal-500/15 text-teal-400"}`}>
                                      {isAuto ? "AI Automated Extracted" : "Manual Core"}
                                    </span>
                                  </div>
                                  <button
                                    onClick={() => onDeleteMemory?.(m.id)}
                                    className="p-1.5 hover:text-red-400 rounded-lg bg-[#000]/10 hover:bg-red-500/10 transition-colors shrink-0"
                                    title="Format/Forget fact memory"
                                  >
                                    <Trash2 size={12} />
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}


                    {/* Searches database log */}
                    {historySubTab === "searches" && (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/50 pl-1 font-bold">Search History</span>
                          {searchHistory?.length > 0 && (
                            <button
                              onClick={() => {
                                if (confirm("Clear search database records?")) onClearSearches?.();
                              }}
                              className="text-[10px] text-zinc-500 hover:text-red-400 uppercase font-bold tracking-wider cursor-pointer"
                            >
                              Clear searches
                            </button>
                          )}
                        </div>

                        {!user && (
                          <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-2xl text-[10px] text-cyan-300 font-semibold flex items-center gap-2">
                            <Info size={12} className="shrink-0 animate-pulse" />
                            <span>Guest Mode: Searches are saved on this device. Authorize Google above to sync search histories to the Cloud.</span>
                          </div>
                        )}

                        {searchHistory?.length === 0 ? (
                          <div className="p-8 text-center bg-white/[0.02] border border-white/5 rounded-3xl text-sm text-white/35 font-medium">
                            No web searches performed. Ask Mimi to find live information!
                          </div>
                        ) : (
                          <div className="space-y-1.5 max-h-[220px] overflow-y-auto custom-scrollbar pr-1">
                            {searchHistory.map((s) => {
                              const sId = s.id || `search-${s.query}`;
                              const sComments = comments[sId] || [];
                              return (
                                <div
                                  key={sId}
                                  className="p-3 bg-[#09090c]/40 border border-white/5 rounded-2xl space-y-2.5 text-xs text-left"
                                >
                                  <div className="flex justify-between items-center font-mono">
                                    <span className="text-white/80 truncate pr-2 font-semibold">{s.query}</span>
                                    <span className="text-[9px] text-white/20 select-none">
                                      {s.timestamp?.seconds 
                                        ? new Date(s.timestamp.seconds * 1000).toLocaleTimeString("en-IN", { hour: "numeric", minute: "numeric" })
                                        : "Recorded"}
                                    </span>
                                  </div>

                                  {/* Mini Comment Section for Search */}
                                  {preferences.showMiniComments !== false && (
                                    <div className={`p-2.5 rounded-xl border ${
                                      preferences.miniCommentTheme === "neon" ? "bg-fuchsia-950/15 border-fuchsia-500/20 shadow-[0_0_8px_rgba(244,114,182,0.1)]" :
                                      preferences.miniCommentTheme === "slate" ? "bg-zinc-900 border-zinc-700/30" :
                                      preferences.miniCommentTheme === "crimson" ? "bg-red-950/15 border-red-500/20 shadow-[0_0_8px_rgba(239,68,68,0.1)]" :
                                      "bg-cyan-950/10 border-cyan-500/10"
                                    }`}>
                                      {/* Comments Thread */}
                                      {sComments.map((com, comIdx) => (
                                        <div key={comIdx} className="space-y-1 pb-1.5 border-b border-white/5 mb-1.5 last:border-0 last:pb-0 last:mb-0 font-sans">
                                          <div className="flex justify-between text-[8px] font-mono text-white/30">
                                            <span>User Note:</span>
                                            <span>{com.timestamp}</span>
                                          </div>
                                          <p className="text-white/70 italic text-[10px]">"{com.comment}"</p>
                                          <div className="flex gap-1.5 items-start mt-1 bg-black/30 p-1.5 rounded-lg border border-white/5">
                                            <span className="text-[8px] font-mono text-cyan-400 font-black uppercase shrink-0">Mimi Answer:</span>
                                            <p className="text-white/90 text-[10px] leading-tight">{com.answer}</p>
                                          </div>
                                        </div>
                                      ))}

                                      {/* Add Comment Input */}
                                      <div className="flex gap-1.5 mt-2 font-sans">
                                        <input
                                          type="text"
                                          placeholder="Add comment..."
                                          id={`input-${sId}`}
                                          onKeyDown={(e) => {
                                            if (e.key === 'Enter') {
                                              const val = (e.target as HTMLInputElement).value;
                                              if (val.trim()) {
                                                handleAddComment(sId, val);
                                                (e.target as HTMLInputElement).value = '';
                                              }
                                            }
                                          }}
                                          className="flex-1 bg-black/60 border border-white/10 rounded-lg px-2 py-1 text-[10px] text-white outline-none focus:border-cyan-400"
                                        />
                                        <button
                                          onClick={() => {
                                            const el = document.getElementById(`input-${sId}`) as HTMLInputElement;
                                            if (el && el.value.trim()) {
                                              handleAddComment(sId, el.value);
                                              el.value = '';
                                            }
                                          }}
                                          className="px-2 py-1 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/20 rounded-lg text-[9px] font-bold uppercase transition-all"
                                        >
                                          Add
                                        </button>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Command actions logs */}
                    {historySubTab === "commands" && (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/50 pl-1 font-bold">Device & Browser Commands Executes</span>
                          {commandLogs?.length > 0 && (
                            <button
                              onClick={() => {
                                if (confirm("Format command activity logs?")) onClearCommandLogs?.();
                              }}
                              className="text-[10px] text-zinc-500 hover:text-red-400 uppercase font-bold tracking-wider cursor-pointer"
                            >
                              Clear Commands
                            </button>
                          )}
                        </div>

                        {!user && (
                          <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-2xl text-[10px] text-cyan-300 font-semibold flex items-center gap-2">
                            <Info size={12} className="shrink-0 animate-pulse" />
                            <span>Guest Mode: Commands are saved on this local device. Authorize Google above to sync command histories to the Cloud.</span>
                          </div>
                        )}

                        {commandLogs?.length === 0 ? (
                          <div className="p-8 text-center bg-white/[0.02] border border-white/5 rounded-3xl text-sm text-white/35">
                            No commands executes captured. Use Mimi controls.
                          </div>
                        ) : (
                          <div className="space-y-2.5 max-h-[240px] overflow-y-auto custom-scrollbar pr-1">
                            {commandLogs.map((log) => (
                              <div
                                key={log.id}
                                className="p-3 bg-neutral-900/40 border border-white/5 rounded-2xl text-xs font-mono space-y-1.5"
                              >
                                <div className="flex justify-between items-center text-[9px] text-white/30">
                                  <span className="uppercase font-bold text-violet-400 bg-violet-400/5 border border-violet-400/10 px-1.5 py-0.5 rounded">
                                    {log.appName || "Device System"}
                                  </span>
                                  <span>{log.timestamp?.seconds ? new Date(log.timestamp.seconds * 1000).toLocaleTimeString("en-IN", { hour: "numeric", minute: "numeric" }) : ""}</span>
                                </div>
                                <div className="space-y-1 border-l border-white/10 pl-2 text-[11px]">
                                  <div><span className="text-zinc-500 font-bold">CMD:</span> <span className="text-white/80">{log.command}</span></div>
                                  <div><span className="text-zinc-500 font-bold">OUT:</span> <span className="text-teal-400 font-medium">{log.response}</span></div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Voice records database log */}
                    {historySubTab === "voice" && (
                      <div className="space-y-3">
                        <div className="flex justify-between items-center text-xs">
                          <span className="text-white/50 pl-1 font-bold">Vocal interaction trace history</span>
                          {voiceLogs?.length > 0 && (
                            <button
                              onClick={() => {
                                if (confirm("Clear vocal transcript logs permanently?")) onClearVoiceLogs?.();
                              }}
                              className="text-[10px] text-zinc-500 hover:text-red-400 uppercase font-bold tracking-wider cursor-pointer"
                            >
                              Clear vocal trace
                            </button>
                          )}
                        </div>

                        {!user && (
                          <div className="p-3 bg-cyan-950/20 border border-cyan-500/20 rounded-2xl text-[10px] text-cyan-300 font-semibold flex items-center gap-2">
                            <Info size={12} className="shrink-0 animate-pulse" />
                            <span>Guest Mode: Vocal recordings and audio logs are saved on this local device. Authorize Google above to sync to the Cloud.</span>
                          </div>
                        )}

                        {voiceLogs?.length === 0 ? (
                          <div className="p-8 text-center bg-white/[0.02] border border-white/5 rounded-3xl text-sm text-white/35 font-medium">
                            No vocal records registered. Tap mic button to begin.
                          </div>
                        ) : (
                          <div className="space-y-2 max-h-[220px] overflow-y-auto custom-scrollbar pr-1">
                            {voiceLogs.map((v) => (
                              <div
                                key={v.id}
                                className="p-3 bg-[#09090c]/40 border border-white/5 rounded-2xl flex justify-between items-center text-xs font-mono"
                              >
                                <div className="min-w-0 pr-2">
                                  <span className="text-[8px] bg-indigo-500/5 border border-indigo-500/10 px-1.5 py-0.5 text-indigo-400 rounded font-bold uppercase">{v.event}</span>
                                  {v.text && <p className="text-white/80 font-mono mt-1 leading-normal">"{v.text}"</p>}
                                </div>
                                <span className="text-[9px] text-white/20 select-none shrink-0 font-bold">
                                  {v.timestamp?.seconds 
                                    ? new Date(v.timestamp.seconds * 1000).toLocaleTimeString("en-IN", { hour: "numeric", minute: "numeric" })
                                    : ""}
                                </span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </>
                )}


                {/* 6. SECURITY, HUD, & SYSTEM LAWS */}
                {activeTab === "security" && (
                  <>
                    {/* Advanced Server Core Card (Main 3D colourful render showcase) */}
                    <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-black/40 shadow-2xl p-4 sm:p-5 flex flex-col md:flex-row gap-5 items-center select-none">
                      <div className="relative w-full md:w-36 h-36 md:h-28 rounded-2xl overflow-hidden shrink-0 border border-white/10 shadow-[0_4px_24px_rgba(6,182,212,0.2)] bg-neutral-950">
                        <img 
                          src="/src/assets/images/colorful_3d_core_1782217293823.jpg" 
                          alt="Advanced Quantum Cyber Server" 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover transition-all duration-700 hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                        <div className="absolute bottom-2 left-2 flex items-center gap-1.5 bg-black/60 backdrop-blur-md border border-cyan-500/30 px-2 py-0.5 rounded-full shadow-[0_0_8px_rgba(6,182,212,0.3)]">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_6px_#22d3ee]" />
                          <span className="text-[7.5px] font-mono text-cyan-200 font-extrabold tracking-wider uppercase">ONLINE CONTROL</span>
                        </div>
                      </div>
                      
                      <div className="flex-1 w-full text-center md:text-left space-y-1">
                        <div className="flex items-center justify-center md:justify-start gap-2 flex-wrap">
                          <h4 className="text-sm font-black text-white tracking-wide uppercase">Realme 3D Core Advanced Server</h4>
                          <span className="text-[8px] font-mono tracking-wider font-extrabold px-2 py-0.5 rounded bg-violet-500/10 border border-violet-500/20 text-violet-400">ACTIVE PROT 6.2</span>
                        </div>
                        <p className="text-[11px] text-white/50 leading-relaxed max-w-xl">
                          Your smart assistant is synchronized with the premium Realme Core system. Fine-tune diagnostic parameters, overlays, haptic channels, and network socket loops.
                        </p>
                        
                        {/* Mini server details */}
                        <div className="flex items-center justify-center md:justify-start gap-4 text-[10px] font-mono text-white/30 pt-1 flex-wrap">
                          <div className="flex items-center gap-1">
                            <Cpu size={10} className="text-cyan-400" />
                            <span>Core Load: <span className="text-cyan-400 font-bold">14.3%</span></span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Activity size={10} className="text-emerald-400" />
                            <span>Haptics Sync: <span className="text-emerald-400 font-bold">LIT</span></span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Satellite size={10} className="text-fuchsia-400" />
                            <span>Clock Latency: <span className="text-fuchsia-400 font-bold">4.2ms</span></span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      
                      {[
                        { 
                          key: "autoGameMode", 
                          title: "Game Overlays", 
                          icon: Gamepad2, 
                          activeColor: "border-emerald-500/40 text-emerald-300 shadow-[0_0_25px_rgba(16,185,129,0.15)]", 
                          color: "text-[#22c55e]", 
                          ledColor: "bg-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.8)]", 
                          theme: "emerald", 
                          desc: "Monitors screen load for game launch triggers",
                          iconBg: "from-emerald-500/20 via-emerald-600/10 to-transparent",
                          iconBorder: "border-emerald-500/40",
                          iconGrad: "from-emerald-400 via-green-500 to-teal-400 font-extrabold",
                          glowColor: "rgba(16,185,129,0.4)"
                        },
                        { 
                          key: "autoCodeMode", 
                          title: "Auto-Assistant Override", 
                          icon: Code2, 
                          activeColor: "border-blue-500/40 text-blue-300 shadow-[0_0_25px_rgba(59,130,246,0.15)]", 
                          color: "text-blue-400", 
                          ledColor: "bg-blue-400 shadow-[0_0_10px_rgba(59,130,246,0.8)]", 
                          theme: "cyan", 
                          desc: "Analyzes inputs for programming suggestions",
                          iconBg: "from-blue-500/20 via-indigo-600/10 to-transparent",
                          iconBorder: "border-blue-500/40",
                          iconGrad: "from-blue-400 via-indigo-500 to-cyan-400 font-extrabold",
                          glowColor: "rgba(59,130,246,0.4)"
                        },
                        { 
                          key: "autoRecordingMode", 
                          title: "Instant vocal recorder", 
                          icon: Radio, 
                          activeColor: "border-amber-500/40 text-amber-300 shadow-[0_0_25px_rgba(245,158,11,0.15)]", 
                          color: "text-amber-500", 
                          ledColor: "bg-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.8)]", 
                          theme: "amber", 
                          desc: "Buffers microphone stream on speech load",
                          iconBg: "from-amber-500/21 via-orange-600/10 to-transparent",
                          iconBorder: "border-amber-500/40",
                          iconGrad: "from-amber-400 via-orange-500 to-red-400 font-extrabold",
                          glowColor: "rgba(245,158,11,0.4)"
                        },
                        { 
                          key: "satelliteMode", 
                          title: "Orbit Satellite Connect", 
                          icon: Satellite, 
                          activeColor: "border-fuchsia-500/40 text-fuchsia-300 shadow-[0_0_25px_rgba(217,70,239,0.15)]", 
                          color: "text-fuchsia-400", 
                          ledColor: "bg-fuchsia-400 shadow-[0_0_10px_rgba(217,70,239,0.8)]", 
                          theme: "fuchsia", 
                          desc: "Links clock reference globally",
                          iconBg: "from-fuchsia-500/20 via-purple-600/10 to-transparent",
                          iconBorder: "border-fuchsia-500/40",
                          iconGrad: "from-fuchsia-400 via-purple-500 to-pink-500 font-extrabold",
                          glowColor: "rgba(217,70,239,0.4)"
                        },
                        { 
                          key: "remoteControlMode", 
                          title: "Override commands link", 
                          icon: MousePointer2, 
                          activeColor: "border-cyan-500/40 text-cyan-300 shadow-[0_0_25px_rgba(6,182,212,0.15)]", 
                          color: "text-cyan-400", 
                          ledColor: "bg-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.8)]", 
                          theme: "cyan", 
                          desc: "Allows secure external socket handshakes",
                          iconBg: "from-cyan-500/20 via-teal-600/10 to-transparent",
                          iconBorder: "border-cyan-500/40",
                          iconGrad: "from-cyan-400 via-teal-500 to-emerald-400 font-extrabold",
                          glowColor: "rgba(6,182,212,0.4)"
                        },
                        { 
                          key: "showSystemMonitor", 
                          title: "Live Diagnostic HUD", 
                          icon: Activity, 
                          activeColor: "border-rose-500/40 text-rose-300 shadow-[0_0_25px_rgba(244,63,94,0.15)]", 
                          color: "text-rose-400", 
                          ledColor: "bg-rose-400 shadow-[0_0_10px_rgba(244,63,94,0.8)]", 
                          theme: "red", 
                          desc: "Docks real-time CPU monitor overlay to screen",
                          iconBg: "from-rose-500/20 via-pink-600/10 to-transparent",
                          iconBorder: "border-rose-500/40",
                          iconGrad: "from-rose-400 via-pink-500 to-red-500 font-extrabold",
                          glowColor: "rgba(244,63,94,0.4)"
                        }
                      ].map((ovr) => {
                        const OvrIcon = ovr.icon;
                        const ovrActive = !!localPrefs[ovr.key as keyof typeof localPrefs];
                        return (
                          <div
                            key={ovr.key}
                            className={`p-4 rounded-[24px] bg-[#0c0d10]/90 border transition-all duration-300 flex justify-between items-center group relative overflow-hidden select-none hover:translate-y-[-2px] ${
                              ovrActive 
                                ? `${ovr.activeColor} border-white/10` 
                                : "border-white/5 text-white/55 hover:border-white/10 hover:bg-neutral-900/30"
                            }`}
                          >
                            {/* Rich, colorful liquid 3D back-glow on active toggles */}
                            {ovrActive && (
                              <div 
                                className="absolute -inset-1 opacity-20 pointer-events-none blur-lg bg-gradient-to-tr transition-all duration-500" 
                                style={{
                                  backgroundImage: `radial-gradient(circle at 50% 50%, ${ovr.glowColor}, transparent 65%)`
                                }}
                              />
                            )}
                            
                            {/* Colorful Left Edge Accent Ribbons */}
                            <span 
                              className={`absolute left-0 top-[15%] h-[70%] w-[4px] rounded-r-full transition-all duration-300 ${
                                ovrActive 
                                  ? `bg-gradient-to-b ${ovr.iconGrad} opacity-100 scale-y-100` 
                                  : "bg-transparent opacity-0 scale-y-50"
                              }`} 
                            />
                            
                            <div className="flex gap-4 items-center text-left z-10">
                              {/* 3D Glassmorphic, Richly Coloured Circular / Boxy Icon Cover */}
                              <div className={`relative p-3 rounded-[18px] border transition-all duration-300 flex items-center justify-center shrink-0 ${
                                ovrActive 
                                  ? `${ovr.iconBorder} bg-black/50 shadow-[0_8px_16px_rgba(0,0,0,0.4)] scale-105` 
                                  : "border-white/10 bg-[#060608]/80 text-white/70"
                              }`}>
                                {/* Infinite radial glowing layer */}
                                <div className={`absolute inset-0 rounded-[18px] bg-gradient-to-tr ${ovr.iconBg} opacity-100`} />
                                {/* Glow element at corner */}
                                <div className={`absolute -right-1 -bottom-1 w-6 h-6 rounded-full bg-gradient-to-br ${ovr.iconGrad} opacity-30 blur-sm pointer-events-none`} />
                                
                                <OvrIcon 
                                  size={19} 
                                  className={`relative z-10 transition-transform duration-300 group-hover:scale-110`} 
                                  style={{
                                    color: 'white',
                                    filter: ovrActive ? `drop-shadow(0 2px 6px ${ovr.glowColor})` : `drop-shadow(0 1px 3px rgba(255,255,255,0.2))`
                                  }}
                                />
                              </div>

                              <div className="space-y-0.5">
                                <div className="flex items-center gap-1.5">
                                  <span className={`w-1.5 h-1.5 rounded-full ${ovrActive ? ovr.ledColor : "bg-neutral-600 shadow-none animate-none"}`} />
                                  <p className={`text-xs font-black tracking-wide leading-none ${ovrActive ? "text-white" : "text-white/80"}`}>{ovr.title}</p>
                                </div>
                                <p className="text-[9.5px] text-white/45 font-medium leading-snug">{ovr.desc}</p>
                              </div>
                            </div>
                            
                            <div className="shrink-0 z-10 pl-2">
                              <PremiumToggle 
                                enabled={ovrActive} 
                                onClick={() => handleGeneralChange(ovr.key, !ovrActive)} 
                                colorTheme={ovr.theme}
                              />
                            </div>
                          </div>
                        );
                      })}

                    </div>

                    {/* Dangerous Maintenance area */}
                    <div className="p-5 border border-red-500/20 bg-red-950/10 rounded-3xl space-y-4">
                      <div className="flex items-center gap-2 text-red-400">
                        <AlertCircle size={16} />
                        <h4 className="text-xs font-black uppercase tracking-wider">Destructive maintenance</h4>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-1">
                        <button
                          onClick={() => handleGeneralChange("isMuted", !localPrefs.isMuted)}
                          className={`py-3 rounded-2xl text-xs font-bold border flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
                            localPrefs.isMuted 
                              ? "bg-red-500/15 border-red-500/30 text-red-400" 
                              : "bg-white/5 border-white/10 text-white/70 hover:bg-white/10"
                          }`}
                        >
                          {localPrefs.isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
                          <span>{localPrefs.isMuted ? "Sound Off" : "Sound On"}</span>
                        </button>

                        <button
                          onClick={() => {
                            if (confirm("Reset neural databases? Mimi will forget biographical facts completely.")) {
                              onClearHistory();
                              onClose();
                            }
                          }}
                          className="py-3 rounded-2xl text-xs font-bold bg-white/5 border border-white/10 text-white/70 hover:bg-red-500/10 hover:border-red-500/30 hover:text-red-400 transition-all flex items-center justify-center gap-2.5 cursor-pointer"
                        >
                          <Trash2 size={15} />
                          <span>Wipe Neural Memory</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}

              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer containing Save/Sync or Cancel triggers */}
          <div className="p-6 bg-black/40 border-t border-white/5 flex gap-3 shrink-0 justify-end">
            <button
              onClick={onClose}
              className="px-6 py-3.5 rounded-2xl bg-neutral-900 border border-white/10 hover:bg-neutral-800 text-xs font-black uppercase tracking-wider text-white/80 transition-all cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={() => {
                onSave(localPrefs);
                onClose();
              }}
              className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-violet-500 text-white text-xs font-black uppercase tracking-widest hover:opacity-90 shadow-md shadow-cyan-500/15 cursor-pointer flex items-center gap-1.5"
            >
              <CheckCircle2 size={14} className="text-white" />
              Save & Sync Mimi
            </button>
          </div>
        </div>

      </motion.div>
    </motion.div>
  );
}
